package utilities;

import java.io.File;

import base.baseConfig;
import io.restassured.specification.RequestSpecification;

public class sslSetup extends baseConfig {

	public void setSSL(RequestSpecification rspec) {

		rspec.keyStore(new File(jksPath), jksPassword);
		rspec.trustStore(new File(jksPath), jksPassword);
	}

	public void setProxy(RequestSpecification rspec) {

		rspec.proxy(proxyHost, proxyPort);

	}

	public void setProxyCustom(RequestSpecification rspec) {

		rspec.proxy(proxyAUB, portAUB);

	}

}
