package utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class soapXMLParser {

	public static String getTestEndpoint(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = null;
		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";
		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();
		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getChildNodes().item(ia).getAttributes()
										.getNamedItem("service").toString();

							}

						}
					}
				}

			}
		}

		return output;

	}

	public static ArrayList<Integer> isPresentLocalName(Node g, String localName) {

		ArrayList<Integer> a = new ArrayList<Integer>();

		try {

			for (int i = 0; i <= g.getChildNodes().getLength() - 1; i++) {

				if (g.getChildNodes().item(i).getLocalName() != null) {

					if (g.getChildNodes().item(i).getLocalName().contains(localName)) {

						a.add(i);

					}

				}

			}
		} catch (Exception e) {

		}

		return a;

	}

	public static String getTestMethod(String TestSuiteName, String TestCaseName, String TestStepName, String xmlPath) {

		String output = null;

		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";
		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();
		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getChildNodes().item(ia).getAttributes()
										.getNamedItem("methodName").toString();

							}

						}
					}
				}

			}
		}

		return output;

	}

	public static String getResourcePath(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = null;

		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();
		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getChildNodes().item(ia).getAttributes()
										.getNamedItem("resourcePath").toString();
							}

						}
					}
				}

			}
		}

		return output;

	}

	public static String getSamplePayload(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = null;

		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								Integer x = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)).getChildNodes().item(ia), "restRequest")
												.get(0);

								Integer z = isPresentLocalName(
										pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
												.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(x),
										"request").get(0);

								output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(x)
										.getChildNodes().item(z).getTextContent();

								break;

							}
						}
					}
				}
			}
		}

		return output.toString();

	}

	public static Map<String, String> getHeaderMap(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		Map<String, String> output = new HashMap<String, String>();
		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";
		// String modTCasename = "name=" + "\"" + TestCaseName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								Integer id = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)).getChildNodes().item(ia), "rest").get(0);

								Integer x = isPresentLocalName(
										pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
												.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(id),
										"parameters").get(0);

								ArrayList<Integer> r = new ArrayList<Integer>();
								r = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)).getChildNodes().item(ia).getChildNodes()
										.item(id).getChildNodes().item(x), "entry");

								for (int ii = 0; ii <= r.size() - 1; ii++) {

									String key = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
											.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(id)
											.getChildNodes().item(x).getChildNodes().item(r.get(ii)).getAttributes()
											.item(0).toString().replace("\"", "").replace("key=", "").trim();
									String value = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
											.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(id)
											.getChildNodes().item(x).getChildNodes().item(r.get(ii)).getAttributes()
											.item(1).toString().replace("\"", "").replace("value=", "").trim();

									output.put(key, value);

								}

								break;

							}
						}
					}

				}
			}
		}

		return output;

	}

	public static Map<String, String> getPropertiesTestSuite(String TestSuiteName, String TestCaseName,
			String TestStepName, String xmlPath) throws ParseException {

		Map<String, String> output = new HashMap<String, String>();
		Document doc = null;

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "properties");

		pNode = doc.getDocumentElement().getChildNodes();
		ArrayList<Integer> r = new ArrayList<Integer>();

		r = isPresentLocalName(pNode.item(a.get(0)), "property");

		for (int ii = 0; ii <= r.size() - 1; ii++) {

			String key = pNode.item(a.get(0)).getChildNodes().item(r.get(ii)).getChildNodes().item(0).getTextContent()
					.trim();
			String value = pNode.item(a.get(0)).getChildNodes().item(r.get(ii)).getChildNodes().item(1).getTextContent()
					.trim();

			output.put(key, value);

		}

		return output;

	}

	public static Map<String, String> getPropertiesTestCase(String TestSuiteName, String TestCaseName,
			String TestStepName, String xmlPath) throws ParseException {

		Map<String, String> output = new HashMap<String, String>();
		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();

		ArrayList<Integer> abc = new ArrayList<Integer>();
		ArrayList<Integer> abcd = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				abc = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				abcd = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(abc.get(0)), "properties");

				ArrayList<Integer> r = new ArrayList<Integer>();

				r = isPresentLocalName(
						pNode.item(a.get(i)).getChildNodes().item(abc.get(0)).getChildNodes().item(abcd.get(0)),
						"property");

				for (int ii = 0; ii <= r.size() - 1; ii++) {

					String key = pNode.item(a.get(i)).getChildNodes().item(abc.get(0)).getChildNodes().item(abcd.get(0))
							.getChildNodes().item(r.get(ii)).getChildNodes().item(0).getTextContent();
					String value = pNode.item(a.get(i)).getChildNodes().item(abc.get(0)).getChildNodes()
							.item(abcd.get(0)).getChildNodes().item(r.get(ii)).getChildNodes().item(1).getTextContent();
					output.put(key, value);

				}

				break;
			}
		}

		return output;

	}

	public static String getPayloadType(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = null;

		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								Integer ik = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)).getChildNodes().item(ia), "restRequest")
												.get(0);

								output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(ik)
										.getAttributes().item(1).toString();

								break;

							}
						}
					}
				}

			}
		}

		return output.toString();

	}

	@SuppressWarnings("null")
	public static String returnTestStepType(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = "";
		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";
		String modTCasename = TestCaseName;

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contains(modTCasename)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getAttributes().item(2).toString();

								break;
							}

						}

						break;

					}
				}
			}
		}

		return output;

	}

	@SuppressWarnings("null")
	public static ArrayList<String> returnDependentSteps(String TestSuiteName, String TestCaseName, String xmlPath) {

		ArrayList<String> output = new ArrayList<String>();
		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";
		String modTCasename = TestCaseName;

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(modTCasename)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							output.add(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
									.item(abc.get(y)).getAttributes().item(1).toString().replace("name=\"", "")
									.replace("\"", ""));

						}

					}

				}
			}
		}

		return output;

	}

	public static String returnGroovyAssertion(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = "";

		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								Integer rr = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)).getChildNodes().item(ia), "restRequest")
												.get(0);

								ArrayList<Integer> alpha = new ArrayList<Integer>();
								alpha = isPresentLocalName(
										pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
												.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(rr),
										"assertion");

								if (alpha.size() > 0) {

									Integer ib = alpha.get(0);

									if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
											.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(rr)
											.getChildNodes().item(ib).getAttributes().item(1).toString()
											.contains("Script Assertion")) {

										output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
												.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(rr)
												.getChildNodes().item(ib).getTextContent().toString();

										break;
									}
								} else {
									output = "";
								}
							}

						}
					}
				}

			}
		}

		return output;

	}

	public static boolean onlyDigits(String str) {
		String num = "0123456789-";
		boolean flag = false;

		for (int i = 0; i <= str.length() - 1; i++) {

			char t = str.charAt(i);

			for (int j = 0; j <= num.length() - 1; j++) {

				if (t == num.charAt(j)) {

					flag = true;
					break;

				}
			}
		}

		return flag;
	}

//Change	
	public static String getEndpoint(String TestSuiteName, String TestCaseName, String TestStepName, String xmlPath) {

		String output = null;

		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								Integer x = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)).getChildNodes().item(ia), "restRequest")
												.get(0);

								Integer p = isPresentLocalName(
										pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
												.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(x),
										"endpoint").get(0);

								output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(x)
										.getChildNodes().item(p).getTextContent();

								break;

							}
						}
					}
				}
			}
		}

		return output.toString();

	}

	@SuppressWarnings("null")
	public static String returnGroovyScript(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = "";
		String attribute = "";
		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";
		String modTCasename = TestCaseName;

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contains(modTCasename)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								attribute = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
										.item(abc.get(y)).getAttributes().item(2).toString();

								if (attribute.contains("groovy")) {

									Integer xa = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
											.getChildNodes().item(abc.get(y)).getChildNodes().item(1), "script").get(0);

									output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
											.item(abc.get(y)).getChildNodes().item(1).getChildNodes().item(xa)
											.getTextContent().toString();

								}
								break;
							}

						}

						break;

					}
				}
			}
		}

		return output;

	}

	public static String returnGroovyStepAssertion(String TestSuiteName, String TestCaseName, String TestStepName,
			String xmlPath) {

		String output = "";

		Document doc = null;
		String modTSuitename = "name=" + "\"" + TestSuiteName + "\"";

		try {
			doc = xmlparser.getDocument(xmlPath);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		ArrayList<Integer> a = new ArrayList<Integer>();
		ArrayList<Integer> ab = new ArrayList<Integer>();
		ArrayList<Integer> abc = new ArrayList<Integer>();

		NodeList pNode;

		a = isPresentLocalName(doc.getDocumentElement(), "testSuite");

		for (int i = 0; i <= a.size() - 1; i++) {

			pNode = doc.getDocumentElement().getChildNodes();

			if (pNode.item(a.get(i)).getAttributes().item(1).toString().contentEquals(modTSuitename)) {

				ab = isPresentLocalName(pNode.item(a.get(i)), "testCase");

				for (int j = 0; j <= ab.size() - 1; j++) {

					if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getAttributes().item(9).getTextContent()
							.toString().contentEquals(TestCaseName)) {

						abc = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j)), "testStep");

						for (int y = 0; y <= abc.size() - 1; y++) {

							if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes().item(abc.get(y))
									.getAttributes().item(1).getTextContent().toString().contentEquals(TestStepName)) {

								Integer ia = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)), "config").get(0);

								Integer rr = isPresentLocalName(pNode.item(a.get(i)).getChildNodes().item(ab.get(j))
										.getChildNodes().item(abc.get(y)).getChildNodes().item(ia), "restRequest")
												.get(0);

								ArrayList<Integer> alpha = new ArrayList<Integer>();
								alpha = isPresentLocalName(
										pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
												.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(rr),
										"assertion");

								if (alpha.size() > 0) {

									Integer ib = alpha.get(0);

									if (pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
											.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(rr)
											.getChildNodes().item(ib).getAttributes().item(1).toString()
											.contains("Script Assertion")) {

										output = pNode.item(a.get(i)).getChildNodes().item(ab.get(j)).getChildNodes()
												.item(abc.get(y)).getChildNodes().item(ia).getChildNodes().item(rr)
												.getChildNodes().item(ib).getTextContent().toString();

										break;
									}
								} else {
									output = "";
								}
							}

						}
					}
				}

			}
		}

		return output;

	}
}
