package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class PropertiesReader {
	FileInputStream fis = null;
	FileInputStream userfis = null;
	FileInputStream specfis = null;
	Properties pro = null;
	Properties userPro = null;
	Properties specPro = null;
	String filepath = System.getProperty("user.dir") + "/src/test/resources/properties/Endpoint.properties";
	String userProp = System.getProperty("user.dir") + "/src/test/resources/properties/config.properties";
	String specProp = System.getProperty("user.dir") + "/src/test/resources/properties/spec.properties";
	FileWriter fw = null;

	public PropertiesReader() {
		try {

			fis = new FileInputStream(filepath);
			pro = new Properties();
			pro.load(fis);

			specfis = new FileInputStream(specProp);
			specPro = new Properties();
			specPro.load(specfis);

		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public void userPropertiesReader() {
		try {

			userfis = new FileInputStream(userProp);
			userPro = new Properties();
			userPro.load(userfis);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public void specPropertiesReader() {
		try {

			specfis = new FileInputStream(specProp);
			specPro = new Properties();
			specPro.load(specfis);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public String getPropValue(String keyvalue) {
		return pro.getProperty(keyvalue);
	}

	public String getUserPropValue(String keyvalue) {
		try {

			userfis = new FileInputStream(userProp);
			userPro = new Properties();
			userPro.load(userfis);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		return userPro.getProperty(keyvalue);
	}

	public void setPropValue(String key, String value) throws IOException {
		try {
			fw = new FileWriter(filepath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pro.setProperty(key, value);
		// pro.store(fw, "Property added");
		pro.store(fw, "");
		// return pro.put(key,value);

	}

	public String getspecPropValue(String keyvalue) {
		try {

			specfis = new FileInputStream(specProp);
			specPro = new Properties();
			specPro.load(specfis);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		return specPro.getProperty(keyvalue);
	}

	public void setspecPropValue(String key, String value) throws IOException {
		try {
			fw = new FileWriter(specProp);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		specPro.setProperty(key, value);
		// pro.store(fw, "Property added");
		specPro.store(fw, "");
		// return pro.put(key,value);

	}

}
