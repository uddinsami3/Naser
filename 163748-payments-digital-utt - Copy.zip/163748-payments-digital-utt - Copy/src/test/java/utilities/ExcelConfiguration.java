package utilities;

import java.util.Objects;

public class ExcelConfiguration {

	public String getFileName() {
		return fileName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public String getSheetName() {
		return sheetName;
	}

	public int getIndex() {
		return index;
	}

	private final String fileName;
	private final String fileLocation;
	private final String sheetName;
	private int index = -1;

	private ExcelConfiguration(String fileName, String fileLocation, String sheetName, int index) {

		this.fileLocation = fileLocation;
		this.fileName = fileName;
		this.sheetName = sheetName;
		this.index = index;

	}

	public static class ExcelConfigurationBuiler {

		private String fileName;
		private String fileLocation;
		private String sheetName;
		private int index = -1;

		public ExcelConfigurationBuiler setFileName(String fileName) {

			this.fileName = fileName;

			return this;
		}

		public ExcelConfigurationBuiler setFileLocation(String fileLocation) {

			this.fileLocation = fileLocation;

			return this;
		}

		public ExcelConfigurationBuiler setSheetName(String sheetName) {

			this.sheetName = sheetName;

			return this;
		}

		public ExcelConfigurationBuiler setIndex(int index) {

			this.index = index;

			return this;
		}

		public ExcelConfiguration build() {

			Objects.requireNonNull(fileName);
			Objects.requireNonNull(fileLocation);
			Objects.requireNonNull(sheetName);
			Objects.requireNonNull(index);

			return new ExcelConfiguration(fileName, fileLocation, sheetName, index);
		}

	}

}
