package utilities;

public class JSONSuccessResponse {

	public String SuccessCode;

	public String Message;

}
