package utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import io.cucumber.java.Scenario;
import stepdef.StepDef;

public class Lib {

	public static PropertiesReader pr = new PropertiesReader();

	public static String htmltable;
	public static Map<String, Object> getData;

	public static String getPayloadwithData(Map<String, String> king, String payloadExcelRequestHeader)
			throws ParseException {

		ArrayList<String> keyAtt = new ArrayList();
		ArrayList<String> valAtt = new ArrayList();

		ArrayList<String> lisAtt = new ArrayList();
		ArrayList<String> lisvalAtt = new ArrayList();

		ArrayList<Integer> k = new ArrayList<>();
		ArrayList<Integer> keyindex = new ArrayList<>();
		String jstringhCopy = null;

		try {

			int index = 0;
			String TestCase_payload = king.get(payloadExcelRequestHeader);

			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(TestCase_payload);
			String jstringh = json.toString();
			jstringhCopy = json.toString();
			String substring = "${#TestCase#";

			List<Integer> indices = new ArrayList<>();
			while ((index = jstringh.indexOf(substring, index)) != -1) {
				indices.add(index);
				index++;
			}

			int key = 0;
			for (int i = 0; i < indices.size(); i++) {

				key = returnKey(indices.get(i), jstringh);
				keyindex.add(key);
			}

			for (int i = 0; i < indices.size(); i++) {

				int g = returnLen(indices.get(i), jstringh);

				k.add(g);

				keyAtt.add(jstringh.substring((keyindex.get(i)), indices.get(i) - 3));
				valAtt.add(jstringh.substring((indices.get(i) + substring.length()), Integer.valueOf(g)));

			}

			for (int i = 0; i < keyAtt.size(); i++) {
				for (int j = i; j < valAtt.size(); j++) {

					if (StepDef.exceptionProp.containsKey(keyAtt.get(i))) {

						lisAtt.add(valAtt.get(i));
						lisvalAtt.add(StepDef.exceptionProp.get(valAtt.get(i)));
						break;
					} else {

						lisAtt.add(valAtt.get(i));
						lisvalAtt.add(king.get(valAtt.get(i)));
						break;
					}

				}
			}

			for (int i = 0; i < indices.size(); i++) {

				try {
					String f = jstringh.substring(indices.get(i), k.get(i)) + "}";
					String ok = jstringh.substring(indices.get(i) + substring.length(), k.get(i));
					for (int l = 0; l < lisAtt.size(); l++) {
						if (lisAtt.get(l).contentEquals(ok)) {
							String val = lisvalAtt.get(l);
							jstringhCopy = jstringhCopy.replace(f, val);
							break;
						}
					}

				} catch (Exception e) {

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return jstringhCopy;

	}

	public static String getjsonPayloadwithData(Map<String, String> king, String TestSuiteName, String testStepName)
			throws ParseException {

		ArrayList<String> keyAtt = new ArrayList();
		ArrayList<String> valAtt = new ArrayList();

		ArrayList<String> lisAtt = new ArrayList();
		ArrayList<String> lisvalAtt = new ArrayList();

		ArrayList<Integer> k = new ArrayList<>();
		ArrayList<Integer> keyindex = new ArrayList<>();
		String jstringhCopy = null;
		String TestCase_payload = "";
		try {

			int index = 0;
			JSONParser parser = new JSONParser();

			String path = "src/test/resources/requestPayloadJson/" + TestSuiteName + "/" + testStepName + ".json";
			try (FileReader reader = new FileReader(path)) {

				Object obj = parser.parse(reader);

				TestCase_payload = obj.toString();
			} catch (FileNotFoundException e) {

			}
			JSONObject json = (JSONObject) parser.parse(TestCase_payload);
			String jstringh = json.toString();
			jstringhCopy = json.toString();
			String substring = "${#TestCase#";

			List<Integer> indices = new ArrayList<>();
			while ((index = jstringh.indexOf(substring, index)) != -1) {
				indices.add(index);
				index++;
			}

			int key = 0;
			for (int i = 0; i < indices.size(); i++) {

				key = returnKey(indices.get(i), jstringh);
				keyindex.add(key);
			}

			for (int i = 0; i < indices.size(); i++) {

				int g = returnLen(indices.get(i), jstringh);

				k.add(g);

				keyAtt.add(jstringh.substring((keyindex.get(i)), indices.get(i) - 3));
				valAtt.add(jstringh.substring((indices.get(i) + substring.length()), Integer.valueOf(g)));

			}

			for (int i = 0; i < keyAtt.size(); i++) {
				for (int j = i; j < valAtt.size(); j++) {

					if (StepDef.exceptionProp.containsKey(keyAtt.get(i))) {

						lisAtt.add(valAtt.get(i));
						lisvalAtt.add(StepDef.exceptionProp.get(valAtt.get(i)));
						break;
					}
//					else if(E2E.extraTestCaseP.containsKey(keyAtt.get(i))) {
//						lisAtt.add(valAtt.get(i));
//						lisvalAtt.add(E2E.extraTestCaseP.get(valAtt.get(i)));
//						break;	
//					}
					else {

						lisAtt.add(valAtt.get(i));
						lisvalAtt.add(king.get(valAtt.get(i)));
						break;
					}

				}
			}

			for (int i = 0; i < indices.size(); i++) {

				try {
					String f = jstringh.substring(indices.get(i), k.get(i)) + "}";
					String ok = jstringh.substring(indices.get(i) + substring.length(), k.get(i));
					for (int l = 0; l < lisAtt.size(); l++) {
						if (lisAtt.get(l).contentEquals(ok)) {
							String val = lisvalAtt.get(l);
							jstringhCopy = jstringhCopy.replace(f, val);
							break;
						}
					}

				} catch (Exception e) {

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return jstringhCopy;

	}

	public static String propPayload(String payload) {

		ArrayList<String> keyAtt = new ArrayList();
		ArrayList<String> valAtt = new ArrayList();

		ArrayList<String> lisAtt = new ArrayList();
		ArrayList<String> lisvalAtt = new ArrayList();

		ArrayList<Integer> k = new ArrayList<>();
		ArrayList<Integer> keyindex = new ArrayList<>();
		String jstringhCopy = null;
		int index = 0;
		JSONParser parser = new JSONParser();

		JSONObject json = null;
		try {
			json = (JSONObject) parser.parse(payload);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String jstringh = json.toString();
		jstringhCopy = json.toString();
		String substring = "${#TestCase#";

		List<Integer> indices = new ArrayList<>();
		while ((index = jstringh.indexOf(substring, index)) != -1) {
			indices.add(index);
			index++;
		}

		int key = 0;
		for (int i = 0; i < indices.size(); i++) {

			key = returnKey(indices.get(i), jstringh);
			keyindex.add(key);
		}

		for (int i = 0; i < indices.size(); i++) {

			int g = returnLen(indices.get(i), jstringh);

			k.add(g);

			keyAtt.add(jstringh.substring((keyindex.get(i)), indices.get(i) - 3));
			valAtt.add(jstringh.substring((indices.get(i) + substring.length()), Integer.valueOf(g)));

		}

		for (int i = 0; i < keyAtt.size(); i++) {
			for (int j = i; j < valAtt.size(); j++) {

				if (StepDef.extraTestCaseP.containsKey(keyAtt.get(i))) {

					lisAtt.add(valAtt.get(i));
					lisvalAtt.add(StepDef.extraTestCaseP.get(valAtt.get(i)));
					break;
				}

			}
		}

		for (int i = 0; i < indices.size(); i++) {

			try {
				String f = jstringh.substring(indices.get(i), k.get(i)) + "}";
				String ok = jstringh.substring(indices.get(i) + substring.length(), k.get(i));
				for (int l = 0; l < lisAtt.size(); l++) {
					if (lisAtt.get(l).contentEquals(ok)) {
						String val = lisvalAtt.get(l);
						jstringhCopy = jstringhCopy.replace(f, val);
						break;
					}
				}

			} catch (Exception e) {

			}

		}

		return jstringhCopy;

	}

	public static int returnLen(int startIndex, String input) {

		int h = 0;
		for (int i = startIndex; i <= input.length() - 1; i++) {

			if (input.charAt(i) == '}') {

				h = i;
				break;
			}

		}

		return h;
	}

	public static int returnKey(int startIndex, String input) {

		int h = 0;
		int start = 0;
		for (int i = startIndex; i <= input.length() - 1; i--) {

			if (input.charAt(i) == ':') {
				start = i;
				break;
			}
		}
		for (int j = start - 2; j <= input.length() - 1; j--) {

			if (input.charAt(j) == '"') {
				h = j;
				break;
			}
		}

		return h + 1;
	}

	public static void softassert(String fieldName, Object actual, String expected) {

		SoftAssert sa = new SoftAssert();

		boolean condition = actual.equals(expected);

		if (condition) {

			sa.assertEquals(actual, expected);

			StepDef.allValidation = 1;

		} else {

			sa.assertEquals(actual, expected);

			StepDef.allValidation = -1;

		}
		sa.assertAll();

	}

	public static void htmltable(String FieldName, Object ActualValue, String ExpectedValue, String Status,
			boolean condition) {

		if (condition) {
			htmltable = "<html>" + "<body>" + " <table border ='1'>" + "<tr>" + "<th>" + FieldName + "</th>"

					+ "<th>" + ActualValue + "</th>" + "<th>" + ExpectedValue + "</th> " + "<th>Status</th> "
					+ "</tr> ";

		} else {

			if (Status.equals("FAIL")) {

				htmltable = htmltable + "<tr>" + "<td>" + FieldName + "</td>" + "<td>" + ActualValue + "</td> " + "<td>"
						+ ExpectedValue + "</td> " + "<td bgcolor=\"red\">" + Status + "</td> " + "</tr> ";

			} else {

				htmltable = htmltable + "<tr>" + "<td>" + FieldName + "</td>" + "<td>" + ActualValue + "</td> " + "<td>"
						+ ExpectedValue + "</td> " + "<td>" + Status + "</td> " + "</tr> ";
			}
		}

	}

	public static void htmlwrite(Scenario scenario) {

		String htmltablewrite = htmltable + "</table>" + "</body>" + "</html>";
		scenario.log(htmltablewrite);
		scenario.attach(htmltablewrite.toString(), "text/html", "");

	}

	public static Map<String, String> getExcelColoumnHeaderMap(String excelPath, String sheet, String workBook,
			String tcid) {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();
		ExcelConfiguration config = new ExcelConfiguration.ExcelConfigurationBuiler().setFileName(workBook)
				.setFileLocation(excelPath).setSheetName(sheet).build();
		ExcelDataReader excelObj = new ExcelDataReader(config);

		int param = 1;
		for (int js = 0; js <= excelObj.getAllRows().size() - 1; js++) {
			if (excelObj.getAllRows().get(js).get("TestCase_ID").contentEquals(tcid)) {
				param = js;
				break;
			}
		}

		excelHeaderValueMap = excelObj.getAllRows().get(param);

		return excelHeaderValueMap;
	}

	public static Map<String, Object> getDatavalue() {

		return getData;

	}

	public static void take_screenshot(WebDriver driver, int castAscii, String name) throws IOException {

		String pat = pr.getUserPropValue("uilogPath");

		File Log_path = new File(pat);

		DateFormat dateFormat = new SimpleDateFormat(String.valueOf("yyyy_MM_dd"));
		DateFormat TimeFormat = new SimpleDateFormat(String.valueOf("HH_mm_ss"));
		Date date = new Date();

		// File Log_path = new File(GenerateFeatureFile.logPath.getAbsolutePath());

		if (!Log_path.isDirectory()) {
			Log_path.mkdirs();
		}

		// Taking Screenshot

		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File(Log_path.getAbsolutePath() + Character.toString((char) castAscii) + ".png");
		FileUtils.copyFile(SrcFile, DestFile);

	}
}
