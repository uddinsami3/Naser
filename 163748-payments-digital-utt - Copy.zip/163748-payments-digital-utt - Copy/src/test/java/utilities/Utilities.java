package utilities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import io.cucumber.java.Scenario;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Utilities {

	public static Scenario scenario;

	public static JsonPath rawToJson(Response response) {
		JsonPath js = new JsonPath(response.body().asString());
		return js;
	}

	public static JsonPath rawToJsonpath(String reqBody) {
		JsonPath js = new JsonPath(reqBody);
		return js;
	}

	public static String date()

	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		return dateFormat.format(date);

	}

	public static String Time() {
		DateFormat dateFormat = new SimpleDateFormat("HH-mm-ss");
		Date date = new Date();
		return dateFormat.format(date);
	}

	public static String headerValue(Response response, String header) {
		String headerVal = response.getHeader(header);
		return headerVal;
	}

}
