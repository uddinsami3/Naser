package base;

import java.io.BufferedWriter;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import io.cucumber.java.Scenario;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import stepdef.StepDef;

public class CrudOperation extends baseConfig {

	public static Response response;
	BufferedWriter bwt;
	String txtReportPath;
	public static Gson gson;
	static String prettyRequest;
	static JsonElement je;
	String resHeader;
	public static String isDebugTrue;

	public CrudOperation() {

	}

	public CrudOperation(Scenario scenario) {

		StepDef.scenario = scenario;
	}

	public Response performCrudCall(String method, String apiName, RequestSpecification rspec, Object Objpload,
			String endpoint, Scenario scenario) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		isDebugTrue = StepDef.pr.getUserPropValue("isDebugTrue");
		StepDef.scenario = scenario;

		if (method.contentEquals("POST")) {

			try {
				rspec.body(Objpload);
				response = rspec.post(apiName);
				printLogCucumber(method, rspec, Objpload, scenario);
				printLog(method, rspec, Objpload);

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (method.contentEquals("PUT")) {

			try {
				rspec.body(Objpload);
				response = rspec.put(apiName);
				printLogCucumber(method, rspec, Objpload, scenario);
				printLog(method, rspec, Objpload);

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (method.contentEquals("GET")) {

			try {
				response = rspec.get(apiName);
				printLogCucumber(method, rspec, Objpload, scenario);
				printLog(method, rspec, Objpload);

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (method.contentEquals("DELETE")) {
			response = rspec.delete(apiName);
			printLogCucumber(method, rspec, Objpload, scenario);
			printLog(method, rspec, Objpload);

		} else {

		}

		return response;

	}

	public Response performCrudCall(String method, String apiName, RequestSpecification rspec, String endpoint,
			Scenario scenario) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException,
			KeyStoreException, CertificateException, IOException {

		isDebugTrue = StepDef.pr.getUserPropValue("isDebugTrue");
		StepDef.scenario = scenario;

		if (method.contentEquals("POST")) {

			try {
				response = rspec.post(apiName);
				printLogCucumber(method, rspec, scenario);
				printLog(method, rspec);

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (method.contentEquals("PUT")) {

			try {
				response = rspec.put(apiName);
				printLogCucumber(method, rspec, scenario);
				printLog(method, rspec);

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (method.contentEquals("GET")) {

			try {
				response = rspec.get(apiName);
				printLogCucumber(method, rspec, scenario);
				printLog(method, rspec);

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (method.contentEquals("DELETE")) {
			response = rspec.delete(apiName);
			printLogCucumber(method, rspec, scenario);
			printLog(method, rspec);

		} else {

		}

		return response;

	}

	public static void printLog(String method, RequestSpecification rspec, Object Objpload) {

		FilterableRequestSpecification spec = (FilterableRequestSpecification) rspec;

		if (method.contains("POST") || method.contains("PUT")) {

			gson = new GsonBuilder().setPrettyPrinting().create();
			je = JsonParser.parseString(Objpload.toString());
			prettyRequest = gson.toJson(je);

			try {

				StepDef.fwt.append("\r\n"

						+ "\r\n" + "***********************Step Start****************" + "\r\n"
						+ "***********************Request*******************" + "\r\n" + spec.getMethod() + " " + method
						+ " " + spec.getURI() + "\r\n" + spec.getHeaders().toString() + "\r\n" + "\r\n" + prettyRequest
						+ "\r\n" + "\r\n" + "***********************Response*******************" + "\r\n"
						+ response.getStatusCode() + "\r\n" + response.getHeaders() + "\r\n" + response.asString()
						+ "\r\n" + "\r\n" + "***********************Step End*******************" + "\r\n");

				if (isDebugTrue.contentEquals("true")) {
					System.out.println("*****URI*****");
					System.out.println(method + " " + spec.getURI());
					System.out.println("*****Request Header*****");
					System.out.println(spec.getHeaders().toString());
					System.out.println("*****Request Body*****");
					System.out.println(prettyRequest);
					System.out.println("*****Response Header*****");
					System.out.println(response.getHeaders());
					System.out.println("*****Response Body*****");
					System.out.println(response.asString());
					System.out.println("*****Status Code*****");
					System.out.println(response.getStatusCode());
				}
				StepDef.fwt.flush();

			} catch (IOException e) {
				e.printStackTrace();
			}

		} else if (method.contains("GET") || method.contains("DELETE")) {

			try {
				StepDef.fwt.append("\r\n"

						+ "\r\n" + "***********************Step Start****************" + "\r\n"
						+ "***********************Request*******************" + "\r\n" + spec.getMethod() + " " + method
						+ " " + spec.getURI() + "\r\n" + spec.getHeaders().toString() + "\r\n" + "\r\n"
						+ "***********************Response*******************" + "\r\n" + response.getStatusCode()
						+ "\r\n" + response.getHeaders() + "\r\n" + response.asString() + "\r\n" + "\r\n"
						+ "***********************Step End*******************" + "\r\n");

				if (isDebugTrue.contentEquals("true")) {
					System.out.println("*****URI*****");
					System.out.println(method + " " + spec.getURI());
					System.out.println("*****Request Header*****");
					System.out.println(spec.getHeaders().toString());
					System.out.println("*****Response Header*****");
					System.out.println(response.getHeaders());
					System.out.println("*****Response Body*****");
					System.out.println(response.asString());
					System.out.println("*****Status Code*****");
					System.out.println(response.getStatusCode());

				}

				StepDef.fwt.flush();

			} catch (IOException e) {
			}
		}
	}

	public static void printLog(String method, RequestSpecification rspec) {

		FilterableRequestSpecification spec = (FilterableRequestSpecification) rspec;

		if (method.contains("POST") || method.contains("PUT")) {
			gson = new GsonBuilder().setPrettyPrinting().create();

			try {
				StepDef.fwt.append("\r\n"

						+ "\r\n" + "***********************Step Start****************" + "\r\n"
						+ "***********************Request*******************" + "\r\n" + spec.getMethod() + " " + method
						+ " " + spec.getURI() + "\r\n" + spec.getHeaders().toString() + "\r\n" + "\r\n"
						+ spec.getFormParams().toString() + "\r\n" + "\r\n"
						+ "***********************Response*******************" + "\r\n" + response.getStatusCode()
						+ "\r\n" + response.getHeaders() + "\r\n" + response.asString() + "\r\n" + "\r\n"
						+ "***********************Step End*******************" + "\r\n");

				if (isDebugTrue.contentEquals("true")) {
					System.out.println("*****URI*****");
					System.out.println(method + " " + spec.getURI());
					System.out.println("*****Request Header*****");
					System.out.println(spec.getHeaders().toString());
					System.out.println("*****Request Form *****");
					System.out.println(spec.getFormParams().toString());
					System.out.println("*****Response Header*****");
					System.out.println(response.getHeaders());
					System.out.println("*****Response Body*****");
					System.out.println(response.asString());
					System.out.println("*****Status Code*****");
					System.out.println(response.getStatusCode());
				}
				StepDef.fwt.flush();

			} catch (IOException e) {
				e.printStackTrace();
			}

		} else if (method.contains("GET") || method.contains("DELETE")) {

			try {
				StepDef.fwt.append("\r\n"

						+ "\r\n" + "***********************Step Start****************" + "\r\n"
						+ "***********************Request*******************" + "\r\n" + spec.getMethod() + " " + method
						+ " " + spec.getURI() + "\r\n" + spec.getHeaders().toString() + "\r\n" + "\r\n"
						+ "***********************Response*******************" + "\r\n" + response.getStatusCode()
						+ "\r\n" + response.getHeaders() + "\r\n" + response.asString() + "\r\n" + "\r\n"
						+ "***********************Step End*******************" + "\r\n");

				if (isDebugTrue.contentEquals("true")) {
					System.out.println("*****URI*****");
					System.out.println(method + " " + spec.getURI());
					System.out.println("*****Request Headers*****");
					System.out.println(spec.getHeaders().toString());
					System.out.println("*****Response Header*****");
					System.out.println(response.getHeaders());
					System.out.println("*****Response Body*****");
					System.out.println(response.asString());
					System.out.println("*****Status Code*****");
					System.out.println(response.getStatusCode());
				}
				StepDef.fwt.flush();

			} catch (IOException e) {
			}
		}
	}

	public static void printLogCucumber(String method, RequestSpecification rspec, Object Objpload, Scenario scenario) {

		FilterableRequestSpecification spec = (FilterableRequestSpecification) rspec;

		if (method.contains("POST") || method.contains("PUT")) {
			gson = new GsonBuilder().setPrettyPrinting().create();
			je = JsonParser.parseString(Objpload.toString());
			prettyRequest = gson.toJson(je);
			scenario.attach(method + " " + spec.getURI().toString(), "application/json", "URI");
			scenario.attach(spec.getHeaders().toString(), "application/json", "Request Header");
			scenario.attach(prettyRequest.toString(), "application/json", "Request Body");
			scenario.attach(response.getHeaders().toString(), "application/json", "Response Header");
			scenario.attach(response.asString(), "application/json", "Response Body");

		} else if (method.contains("GET")) {
			scenario.attach(method + " " + spec.getURI().toString(), "application/json", "URI");
			scenario.attach(spec.getHeaders().toString(), "application/json", "Request Header");
			scenario.attach(response.getHeaders().toString(), "application/json", "Response Header");
			scenario.attach(response.asString(), "application/json", "Response Body");
		}
	}

	public static void printLogCucumber(String method, RequestSpecification rspec, Scenario scenario) {

		FilterableRequestSpecification spec = (FilterableRequestSpecification) rspec;

		if (method.contains("POST") || method.contains("PUT")) {
			gson = new GsonBuilder().setPrettyPrinting().create();
			scenario.attach(method + " " + spec.getURI().toString(), "application/json", "URI");
			scenario.attach(spec.getHeaders().toString(), "application/json", "Request Header");
			scenario.attach(spec.getFormParams().toString(), "application/json", "Form Params");
			scenario.attach(response.getHeaders().toString(), "application/json", "Response Header");
			scenario.attach(response.asString(), "application/json", "Response Body");
		} else if (method.contains("GET")) {
			scenario.attach(method + " " + spec.getURI().toString(), "application/json", "URI");
			scenario.attach(spec.getHeaders().toString(), "application/json", "Request Header");
			scenario.attach(response.getHeaders().toString(), "application/json", "Response Header");
			scenario.attach(response.asString(), "application/json", "Response Body");
		}
	}
}
