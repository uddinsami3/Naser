package base;

public class baseConfig {

	protected static final String jksPath = "src/test/resources/certificate/uat2normalmediationself.enterprise.citigroup.net.ca1.jks";
	protected static final String jksPassword = "cip1234";
	protected static final String proxyHost = "proxy.citicorp.com";
	protected static final int proxyPort = 8080;
	protected static final String proxyAUB = "sgproxy-app.nopers.wlb4.apac.nsroot.net";
	protected static final int portAUB = 7777;
}
