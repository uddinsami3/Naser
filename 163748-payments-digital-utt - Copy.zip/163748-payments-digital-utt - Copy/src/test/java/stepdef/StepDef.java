package stepdef;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringWriter;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.logging.Logger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.DocumentContext;

import base.CrudOperation;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.DataTableType;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import utilities.ExcelConfiguration;
import utilities.ExcelDataReader;
import utilities.IDataReader;
import utilities.InsecureTrustManager;
import utilities.Lib;
import utilities.PropertiesReader;
import utilities.Utilities;
import utilities.sslSetup;

public class StepDef extends CrudOperation {

	public static Response response;
	public static Map<String, String> extraTestCaseP = new HashMap<String, String>();
	public static Map<String, String> exceptionProp = new HashMap<String, String>();
	public static Logger logger;
	public static StringWriter writer;
	public static PrintStream captor;
	public static Scenario scenario;
	static String sheet;
	static String workBook;
	static String excelPath;
	public static WebDriver driver = null;
	public static FileWriter fwt;
	public static String featureName;
	public static PropertiesReader pr = new PropertiesReader();
	public static Gson gson;
	public static SoftAssert softassert = new SoftAssert();
	public static String payLoad;
	public static String excelpayLoad;
	public static JsonPath js;
	public static String headerVal;
	public static List<Map<String, String>> data;
	public static RequestSpecification rspec;
	public static String Req;
	public static sslSetup s = new sslSetup();
	public static String logFolder;
	public static String destLogPath;
	public static String sourceLogPath;
	public static String renameFileName;

	public static int allValidation = 0;

	public StepDef() {

	}

	@After
	public void setDown(Scenario scenario) throws IOException {

		String pfail = "";

		if (allValidation == 1) {

			pfail = "PASS";

		} else if (allValidation == -1) {

			pfail = "FAIL";

		} else {

		}

		fwt.flush();
		fwt.close();
		destLogPath = destLogPath.replace("\\", "/");

		String[] arraysourcePath = destLogPath.split("/");

//		sourceLogPath = destLogPath.replace(arraysourcePath[arraysourcePath.length - 1],
//				arraysourcePath[arraysourcePath.length - 1].split(".txt")[0] + "__" + pfail + ".txt");

		sourceLogPath = destLogPath.replace(arraysourcePath[arraysourcePath.length - 1],
				pfail + "__" + arraysourcePath[arraysourcePath.length - 1]);

		File source = new File(destLogPath);
		File dest = new File(sourceLogPath);

		source.renameTo(dest);
	}

	@Before
	public void setUp(Scenario scenario) {

		StepDef.scenario = scenario;
		String scenarioId = scenario.getId();

		int start = scenarioId.indexOf("features");
		int end = scenarioId.indexOf(".feature");

		String[] featureNameRes = scenarioId.substring(start, end).split("features/");

		featureName = featureNameRes[1];

		logFolder = "src/test/resources/logs/" + featureName + "_" + Utilities.date();

		File dir = new File(logFolder);

		if (!dir.exists()) {
			dir.mkdirs();
		}

		renameFileName = scenario.getName() + Utilities.Time() + ".txt";

		destLogPath = logFolder + "/" + scenario.getName() + Utilities.Time() + ".txt";

		try {
			fwt = new FileWriter(destLogPath);
		} catch (IOException e) {
			e.printStackTrace();
		}

		gson = new GsonBuilder().setPrettyPrinting().create();
	}

	public StepDef(Scenario scenario) throws SecurityException, IOException {

	}

	/* Step definition to relax proxy and set the proxy as default */
	@Then("relax proxy")
	public void relaxproxy() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException,
			KeyStoreException, CertificateException, IOException {

		rspec.proxy("127.0.0.1", 8080);
	}

	/* Initialise rest assured object */
	@When("initialize rest assured object")
	public void initialize() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException,
			KeyStoreException, CertificateException, IOException {
		TrustStrategy ts = (X509Certificate[] chain, String authType) -> true;
		SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, ts).build();
		//SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
		//sslContext.init(null, new TrustManager[] { new InsecureTrustManager() }, new java.security.SecureRandom());
		
		//RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation("PKIX"));
		//rspec = RestAssured.given().config(RestAssured.config().
			//				sslConfig(new SSLConfig().relaxedHTTPSValidation("PKIX")));
		javax.net.ssl.SSLSocketFactory sc = sslContext.getSocketFactory();
		SSLSocketFactory sf = new SSLSocketFactory(sslContext);
		System.setProperty("https.protocols", "TLSv1.1,TLSv1.2");
		//RestAssured.config = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslConfig().ssl)
		rspec = RestAssured.given();
		rspec.config(RestAssuredConfig.newConfig().sslConfig(new SSLConfig().with().sslSocketFactory(sf)));
		
		
		
		
	}

	/*
	 * Couple or link excel sheet with framework providng workbook path, sheet name
	 */
	@Then("Couple Excel {string} in sheet {string}")
	public void inputExcel(String workbook, String sheetName) {

		sheet = sheetName;
		workBook = workbook;
		excelPath = pr.getUserPropValue("Datasheetpath") + "/" + workBook;
	}

	/* Set ssl and proxy ssl is default mediation ssl and proxy is citicorp proxy */
	@Then("setssl and proxy")
	public void setsslandproxy() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException,
			KeyStoreException, CertificateException, IOException {

		sslSetup s = new sslSetup();
		s.setSSL(rspec);
		s.setProxy(rspec);
	}

	/*
	 * Set custom ssl and proxy ssl is default mediation ssl and proxy is citicorp
	 * proxy
	 */
	@Then("setssl and proxy customise")
	public void setsslandproxycustom() throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		sslSetup s = new sslSetup();
		s.setSSL(rspec);
		s.setProxyCustom(rspec);
	}

	/*
	 * Step def take input key value pair and store the property from the response
	 * to map and spec properties file
	 */
	@Then("retrieve property {string} {string} value")
	public void retrieveProp(String key, String value) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		js = Utilities.rawToJson(response);
		pr.setspecPropValue(key, js.getString(value));
		extraTestCaseP.put(key, js.getString(value));
	}

	/*
	 * Step def take input key value pair and store the property from the response
	 * to map and spec properties file
	 */
	@Then("retrieve property {string} {string} value from property")
	public void retrievePropFromproperties(String key, String value) throws KeyManagementException,
			UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		String v = pr.getspecPropValue(key).toString();
		extraTestCaseP.put(key, v);
	}

	/*
	 * Step def take input key value pair and store the property from the response
	 * to map and spec properties file
	 */
	@Then("retrieve property {string} {string} value in temprory properties")
	public void retrievePropA(String key, String value) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		pr.setspecPropValue(key, value);
		extraTestCaseP.put(key, value);
	}

	/*
	 * Step def take input as key value pair and store the property from response
	 * header in map and spec properties file
	 */
	@Then("retrieve header property {string} {string} value")
	public void retrieveHeaderProp(String key, String value) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		headerVal = Utilities.headerValue(response, value);
		pr.setspecPropValue(key, headerVal);
		extraTestCaseP.put(key, headerVal);
	}

	/*
	 * Step def specific for project A it take input as key value pair and store the
	 * property from response header in map and spec properties file
	 */
	@Then("retrieve exception property {string} {string} value")
	public void expretrieveProp(String key, String value) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		js = Utilities.rawToJsonpath(payLoad);
		exceptionProp.put(key, js.getString(value));
		pr.setspecPropValue(key, js.getString(value));
	}

	/*
	 * Step definition take input as key value pair and a matchhing key , this type
	 * is specically use for responses with same header with multiple enteries.
	 */
	@Then("retrieve property {string} {string} value from header with key {string}")
	public void retrievePropHeaderwithkey(String key, String value, String keysearch) throws KeyManagementException,
			UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		Headers headData = response.getHeaders();
		Iterator<Header> itr = headData.iterator();

		while (itr.hasNext()) {

			Header pair = itr.next();
			String headDataKey = pair.getName().toString();
			String headDataValue = pair.getValue().toString();

			if (headDataKey.contains(key)) {

				if (headDataValue.contains(keysearch)) {

					if (key.contains("access_token")) {

						pr.setspecPropValue("Authorization", "Bearer " + pair.getValue().toString());
						extraTestCaseP.put("Authorization", pair.getValue().toString());
					}
					pr.setspecPropValue(key, headDataValue);
					extraTestCaseP.put(key, headDataValue);
				}
			}
		}
	}

	/* Step definition use to apply wait between two feature steps */
	@Then("Apply wait for {string}")
	public void applywait(String wait)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException, NumberFormatException, InterruptedException {

		Thread.sleep(Integer.valueOf(wait));
	}

	/* Step def to load excel data private step def internally used */
	@Given("Load excel data")
	public void loadexceldata(IDataReader datatable) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		data = datatable.getAllRows();
	}

	/*
	 * Step def to handle payload with form url encoded and link with test data by
	 * using TC_ID as primary key
	 */
	@When("user provides Payload OF TC_ID {string} with type application x-www-form-urlencoded value {string}")
	public void payloadForm(String tcid, String j) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, ParseException {

		Map<String, String> excelHeaderMap = new HashMap<String, String>();
		ExcelConfiguration config = new ExcelConfiguration.ExcelConfigurationBuiler().setFileName(workBook)
				.setFileLocation(excelPath).setSheetName(sheet).build();
		ExcelDataReader excelObj = new ExcelDataReader(config);

		int param = 1;
		for (int js = 0; js <= excelObj.getAllRows().size() - 1; js++) {
			if (excelObj.getAllRows().get(js).get("TestCase_ID").contentEquals(tcid)) {
				param = js;
				break;
			}
		}

		excelHeaderMap = excelObj.getAllRows().get(param);

		String[] a = j.split("&");
		String temp;

		for (int i = 0; i <= a.length - 1; i++) {

			if (!a[i].isEmpty()) {
				String[] k = a[i].split("=");
				System.out.println(a[i]);

				if (k[1].contains("${#TestCase#")) {
					do {

						temp = excelHeaderMap.get(k[1].replace("${#TestCase#", "").replace("}", "").trim());

					} while (excelHeaderMap.containsKey(temp));

					if (temp != null) {
						if (temp.contains("${#TestCase#")) {

							if (extraTestCaseP.containsKey(k[0])) {
								rspec.formParam(k[0].toString(), extraTestCaseP.get(k[0]).toString());
							}
						} else {
							rspec.formParam(k[0].toString(), temp);
						}

					} else if (extraTestCaseP.containsKey(k[0])) {
						rspec.formParam(k[0].toString(), extraTestCaseP.get(k[0]).toString());

					}
				}

				else {
					rspec.formParam(k[0], k[1]);
				}

			}
		}

	}

	/*
	 * Step def to handle payload with application/json encoded and link with test
	 * data by using TC_ID as primary key location of json payload will be excel
	 * coloumns
	 */
	@SuppressWarnings("unchecked")
	@When("user provides Payload OF TC_ID {string} with type application json head as {string}")
	public void payload(String tcid, String payloadExcelRequestHeader)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException, ParseException {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(excelPath, sheet, workBook, tcid);

		Req = Lib.getPayloadwithData(excelHeaderValueMap, payloadExcelRequestHeader);

		if (Req.contains("$")) {
			payLoad = Lib.propPayload(Req);
		} else {
			payLoad = Req;
		}

	}

	/*
	 * Step def to handle payload with application/json encoded and link with test
	 * data by using TC_ID as primary key location of payload in this case is json
	 * folder in workspace
	 */
	@SuppressWarnings("unchecked")
	@When("user provides Payload OF TC_ID {string} with type application json for {string} API in {string}")

	public void payload(String tcid, String testStepName, String TestSuiteName)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException, ParseException {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(excelPath, sheet, workBook, tcid);

		Req = Lib.getjsonPayloadwithData(excelHeaderValueMap, TestSuiteName, testStepName);

		if (Req.contains("$")) {

			payLoad = Lib.propPayload(Req);
		} else {
			payLoad = Req;
		}

	}

	/* Step def to handle template header of the request */
	@When("user provides {string} Headers OF TC_ID {string}")
	public void headerForm(String type, String tcid, DataTable table)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException, ParseException {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(excelPath, sheet, workBook, tcid);

		List<Map<String, String>> rows = table.asMaps(String.class, String.class);
		Iterator<Entry<String, String>> featureheader = rows.get(0).entrySet().iterator();
		featureheader = rows.get(0).entrySet().iterator();
		String temp = "";

		while (featureheader.hasNext()) {

			@SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry) featureheader.next();

			if (pair.getValue() != null) {

				if ((pair.getValue().toString().length() > 0)) {

					try {

						if (pair.getValue().toString().contains("Bearer")) {
							rspec.header(pair.getKey().toString(),
									"Bearer " + extraTestCaseP.get(pair.getKey().toString()));
						} else if (pair.getKey().toString().contains("uuid")) {
							rspec.header(pair.getKey().toString(), UUID.randomUUID());
						} else if (pair.getKey().toString().contains("x-fapi-interaction-id")) {
							rspec.header(pair.getKey().toString(), UUID.randomUUID() + "-API");

						} else if (pair.getValue().toString().contains("${#TestCase#")) {

							do {

								temp = excelHeaderValueMap.get(pair.getValue().toString().replace("${#TestCase#", "")
										.replace("}", "").replace("Bearer", "").trim());

							} while (excelHeaderValueMap.containsKey(temp));

							if (temp != null) {

								if (temp.contains("${#TestCase#")) {

									if (temp.contains("Bearer")) {
										rspec.header(pair.getKey().toString(),
												"Bearer " + extraTestCaseP.get(temp.replace("${#TestCase#", "")
														.replace("}", "").replace("Bearer", "").trim()));

									} else if (extraTestCaseP.containsKey(pair.getKey().toString().trim())) {
										rspec.header(pair.getKey().toString(),
												extraTestCaseP.get(pair.getKey().toString().trim()));
									}

								} else {
									rspec.header(pair.getKey().toString().trim(),
											excelHeaderValueMap.get(pair.getKey().toString()));

								}
							} else {

								if (pair.getValue().toString().contains("Bearer")) {
									rspec.header(pair.getKey().toString(),
											"Bearer " + extraTestCaseP.get(pair.getKey().toString()));

								} else if (extraTestCaseP.containsKey(pair.getKey().toString())) {
									rspec.header(pair.getKey().toString(),
											extraTestCaseP.get(pair.getKey().toString()));

								} else {
								}
							}
						}

						else {
							rspec.header(pair.getKey().toString(), pair.getValue().toString());
						}
					} catch (Exception e) {

					}
				}
			}
		}

		if (type.contains("form")) {
			rspec.header("Content-Type", "application/x-www-form-urlencoded ");
		} else {
			rspec.header("Content-Type", "application/json");
		}
	}

	/* Step def to handle query header of the request */
	@When("user provides Headers OF TC_ID  {string} type query")
	public void headerFormquery(String tcid, DataTable table) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, ParseException {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(excelPath, sheet, workBook, tcid);

		List<Map<String, String>> rows = table.asMaps(String.class, String.class);
		Iterator<Entry<String, String>> featureheader = rows.get(0).entrySet().iterator();
		featureheader = rows.get(0).entrySet().iterator();
		String temp;

		while (featureheader.hasNext()) {

			@SuppressWarnings("rawtypes")
			Map.Entry pair = (Map.Entry) featureheader.next();

			if (pair.getValue() != null) {
				if ((pair.getValue().toString().length() > 0)) {

					try {
						if (pair.getValue().toString().contains("Bearer")) {
							rspec.queryParam(pair.getKey().toString(),
									"Bearer " + extraTestCaseP.get(pair.getKey().toString()));
						} else if (pair.getKey().toString().contains("uuid")) {
							rspec.queryParam(pair.getKey().toString(), UUID.randomUUID());
						} else if (pair.getValue().toString().contains("${#TestCase#")) {
							boolean flg = true;
							do {

								temp = excelHeaderValueMap
										.get(pair.getValue().toString().replace("${#TestCase#", "").replace("}", ""));

							} while (excelHeaderValueMap.containsKey(temp));

							if (temp == null) {
								flg = false;
								temp = pair.getValue().toString();
							}

							if (temp.contains("${#TestCase#") || flg == false) {
								temp = pair.getValue().toString().replace("${#TestCase#", "").replace("}", "");
								if (extraTestCaseP.containsKey(temp)) {
									rspec.queryParam(pair.getKey().toString(), extraTestCaseP.get(temp));
								}

							} else {
								rspec.queryParam(pair.getKey().toString(), excelHeaderValueMap
										.get(pair.getValue().toString().replace("${#TestCase#", "").replace("}", "")));
							}

						} else {
							rspec.queryParam(pair.getKey().toString(), pair.getValue().toString());

						}
					} catch (Exception e) {

					}
				}
			}
		}
	}

	/*
	 * Step def to submit request to given resorce and endpoint with request as json
	 */
	@When("user submit a  methodName={string} with type {string} for resourcePath={string} in {string} OF TC_ID {string}")
	public void submitFromself(String methodName, String bodyType, String resourcePath, String endpointuri, String tcid)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(excelPath, sheet, workBook, tcid);

		String endpoint = pr.getPropValue(endpointuri);
		rspec.baseUri(endpoint);
		
		String temp = "";

		int index = resourcePath.indexOf("{");

		while (index >= 0) {
			String d = "";
			for (int i = index + 1; i <= resourcePath.length() - 1; i++) {

				if (String.valueOf(resourcePath.charAt(i)).contentEquals("}")) {
					break;
				} else {
					d = d + String.valueOf(resourcePath.charAt(i));
				}
			}

			if (excelHeaderValueMap.get(d) == null) {
				if (extraTestCaseP.get(d) == null) {
					rspec.pathParam(d, "");
				} else {
					rspec.pathParam(d, extraTestCaseP.get(d));
				}

			} else {

				if (excelHeaderValueMap.get(d).contains("${#TestCase#")) {

					do {

						temp = excelHeaderValueMap.get(d.replace("${#TestCase#", "").replace("}", ""));

					} while (excelHeaderValueMap.containsKey(temp));

				}

				if (temp.contains("${#TestCase#")) {
					rspec.pathParam(d, extraTestCaseP.get(d.replace("${#TestCase#", "").replace("}", "")));
				} else {
					rspec.pathParam(d, excelHeaderValueMap.get(d));
				}

			}

			index = resourcePath.indexOf("{", index + 1);
			
		}
FilterableRequestSpecification spec = (FilterableRequestSpecification) rspec;
		
		System.out.println("uri is: " + endpoint);
		System.out.println("payload is: " + payLoad);
		//System.out.println(spec.);
		System.out.println(spec.getURI());
		System.out.println(spec.getHeaders());

		if (bodyType.contentEquals("form")) {

			response = performCrudCall(methodName, resourcePath, rspec, endpoint, scenario);

		} else {

			response = performCrudCall(methodName, resourcePath, rspec, payLoad, endpoint, scenario);
		}

		rspec = RestAssured.given();

	}

	/* Step def to validate status code of the response */
	@Then("validate value of statuscode  is {string}")

	public void validateStatus(String expStatuscode) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {

		if (expStatuscode.contentEquals(String.valueOf(response.statusCode()))) {
			allValidation = 1;

		} else {
			allValidation = -1;
		}

		Assert.assertEquals(expStatuscode, String.valueOf(response.statusCode()));

	}

	/* Step def to validate status code of the response from excel */
	@Then("validate value of statuscode  is {string} of tcid {string}")

	public void validateStatusExcel(String expStatuscode, String tcid)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException, Exception {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();
		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(excelPath, sheet, workBook, tcid);

		if (expStatuscode.contains("${#TestCase#")) {

			expStatuscode = excelHeaderValueMap.get(expStatuscode.replace("${#TestCase#", "").replace("}", "").trim());

		}

		if (expStatuscode.contentEquals(String.valueOf(response.statusCode()))) {
			allValidation = 1;

		} else {
			allValidation = -1;
		}

		Assert.assertEquals(expStatuscode, String.valueOf(response.statusCode()));

	}

	/* Defining datatable of the feature file */
	@DataTableType
	public IDataReader excelToDataTable(Map<String, String> entry) {

		ExcelConfiguration config = new ExcelConfiguration.ExcelConfigurationBuiler().setFileName(entry.get("Excel"))
				.setFileLocation(entry.get("Location")).setSheetName(entry.get("Sheet"))
				.setIndex(Integer.valueOf(entry.getOrDefault("index", "0"))).build();

		return new ExcelDataReader(config);
	}

	@Then("validate the {string} response {string} Schema")

	public void validate_the_response_Schema(String apiName, String format) throws Throwable {
		if (format.equalsIgnoreCase("JSON")) {
			System.out.println(" JSON");

			response.then().assertThat()
					.body(matchesJsonSchemaInClasspath(".\\expetcedJsonSchema\\" + apiName + ".json"));

			if (response.then()
					.body(matchesJsonSchemaInClasspath(".\\expetcedJsonSchema\\" + apiName + ".json")) != null) {

				allValidation = 1;

			} else {

				allValidation = -1;
			}

		}

	}

	@Then("verify the mandatory fields are not null in the {string} response")

	public void verify_the_mandatory_fields_are_not_null_in_the_response(String apiName) throws Throwable {

		Object key;
		Object value = "";
		String body = response.body().asString();
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader("src/test/resources/mandatoryFieldSchema/" + apiName + ".txt"));
		JSONObject jsonObject = (JSONObject) obj;

		Map<String, Object> flattenedJsonMapResponse = JsonFlattener.flattenAsMap(body.toString());
		Map<String, Object> flattenedJsonMapTextFileexpected = JsonFlattener.flattenAsMap(jsonObject.toString());

		for (Entry<String, Object> entry : flattenedJsonMapTextFileexpected.entrySet()) {

			key = entry.getKey();

			if (flattenedJsonMapResponse.containsKey(key)) {

				value = flattenedJsonMapResponse.get(key).toString();
				// if (entry.getKey().equals(key)) {
				if (value.equals(null) || value.equals("")) {
					System.out.println("mandatory field is null  " + key + " and " + value);
					Assert.assertTrue(false);
					allValidation = -1;

				} else {

					// System.out.println("mandatory fields are not null");

				}

			} else {
				System.out.println("Key not present in response   " + key + "  and  " + value);
				Assert.assertTrue(true);
				allValidation = 1;
			}

		}

	}

	@Then("assert the value of field {string} in jsonpath {string} is {string}")
	public void verify_the_response_Details_and_and_in_the_response(String fieldName, String jsonpath,
			String Fieldvalue) {
		Lib.softassert(fieldName, response.jsonPath().getString(jsonpath), Fieldvalue);

	}

	@Then("print payload")
	public void printPayload() {

		ObjectMapper mapper = new ObjectMapper();
		@SuppressWarnings("deprecation")
		JsonFactory factory = mapper.getJsonFactory();
		try {
			@SuppressWarnings("deprecation")
			com.fasterxml.jackson.core.JsonParser parser = factory.createJsonParser(payLoad);
			JsonNode actualObj = mapper.readTree(parser);

			System.out.println(actualObj.toPrettyString());
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
	}

	@Then("verify the {string} field not exist in response")
	public void nonnvalid(String jsonPathtoCheck) {

		String body = response.body().asString();
		Map<String, Object> flattenedJsonMapResponse = JsonFlattener.flattenAsMap(body.toString());

		if (flattenedJsonMapResponse.containsKey(jsonPathtoCheck)) {

			Assert.assertTrue(false);
			allValidation = -1;

		} else {
			Assert.assertTrue(true);
			allValidation = 1;
		}

	}

	@Then("remove key {string} of request payload")
	public void removeRequestTag(String jsonpathtoremove) {

		// Parse JSON from string
		JsonObject jsonObject = new Gson().fromJson(payLoad, JsonObject.class);

		JsonPath js = new JsonPath(payLoad);

		DocumentContext doc = com.jayway.jsonpath.JsonPath.parse(payLoad);

		payLoad = doc.delete("$.applicant").toString();

//		JsonObject positionObject = jsonObject.get("applicant").getAsJsonObject().get("additionalData")
//				.getAsJsonObject();
//
//		JsonArray positionObjectw = jsonObject.get("applicant").getAsJsonObject().get("consentDetails")
//				.getAsJsonArray();
//
//		positionObjectw.get(2).getAsJsonObject().remove("consentType");
//
//		payLoad = jsonObject.toString();

	}

}
