package stepdef;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.pdfbox.util.Hex;
import org.jose4j.jwe.JsonWebEncryption;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.citi.e2e.Encrypt;
import com.citi.esb.rsa.encryption.EncryptRSA;

import base.CrudOperation;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utilities.Lib;
import utilities.Utilities;

public class CustomStepDef extends CrudOperation {

	static String keyEncAlgo = "RSA-OAEP";
	static String contentEncAlgo = "A256GCM";
	public static String JWE = null;
	Properties Props = null;
	FileInputStream fis = null;

	/*
	 * Step def take input key value pair and store the property from the response
	 * to map and spec properties file specic to Qantas servicing
	 */
	@Then("retrieve active payeeID {string}")
	public void retrieveactivepayeeid(String key) throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		boolean flag = false;
		int y = 0;
		StepDef.js = Utilities.rawToJson(response);

		int payeelistcount = Integer.valueOf(StepDef.js.getString("payeeList.size"));

		for (int i = 0; i <= payeelistcount; i++) {

			if (StepDef.js.getString("payeeList[" + i + "].payeeStatus").toString().contentEquals("ACTIVE")) {

				flag = true;
				y = i;
				break;

			}
		}

		if (flag == true) {

			StepDef.pr.setspecPropValue(key, StepDef.js.getString("payeeList[" + y + "].payeeId"));
			StepDef.extraTestCaseP.put(key, StepDef.js.getString("payeeList[" + y + "].payeeId"));

		} else {

			StepDef.pr.setspecPropValue(key, "no active payee present");
			StepDef.extraTestCaseP.put(key, "no active payee present");

		}

	}

	/*
	 * Step Def to generate partnerConsumerOrgCode with String Concatenation along
	 * with country code
	 */
	@Given("generate the partnerConsumerOrgCode for channel {string} countryCode {string} businessCode {string}")
	public void genarateRandompartnerConsumerOrgCode(String partnerChannelId, String partnerCountryCode,
			String partnerBusinessCode) {

		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder sb = new StringBuilder();

		Random random = new Random();

		int length = 6;

		for (int i = 0; i < length; i++) {

			int index = random.nextInt(alphabet.length());

			char randomChar = alphabet.charAt(index);

			sb.append(randomChar);
		}

		String randomString = sb.toString();
		String partnerConsumerOrgCode = partnerChannelId + partnerCountryCode + partnerBusinessCode + randomString;

		StepDef.exceptionProp.put("partnerConsumerOrgCode", partnerConsumerOrgCode);

	}

	/*
	 * Step Def to generate partnerConsumerOrgCode with String Concatenation along
	 * with country code
	 */
	@Given("generate the partnerConsumerOrgCode for countryCode {string} businessCode {string}")
	public void genarateRandomConsumerOrgCode(String partnerCountryCode, String partnerBusinessCode) {

		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder sb = new StringBuilder();

		Random random = new Random();

		int length = 6;

		for (int i = 0; i < length; i++) {

			int index = random.nextInt(alphabet.length());

			char randomChar = alphabet.charAt(index);

			sb.append(randomChar);
		}

		String randomString = sb.toString();
		String partnerConsumerOrgCode = partnerCountryCode + partnerBusinessCode + randomString;

		StepDef.exceptionProp.put("partnerConsumerOrgCode", partnerConsumerOrgCode);

	}

	/* Step def to handle selenium UI script in feature file */
	@Then("call  AUB_selenium_script OF TC_ID {string} for partner {string}")
	public static void sel_call_generateurl(String tcid, String partnerName) throws InterruptedException, IOException {

		String cpath = StepDef.pr.getUserPropValue("chromedriverpath");
		File Log_path = new File(cpath);
		File cdpath = new File(Log_path.getAbsolutePath());

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);

		// Creating the file folder for pasting screenshot
		String name = partnerName;

		int castAscii = 97;

		By xpath_userid_text = null;
		By xpath_userid_con_button = null;
		By xpath_otp_text = null;
		By xpath_otp_con_button = null;
		By xpath_account_active_sel_con_button = null;
		By xpath_first_confrm_con_button = null;
		By xpath_second_confrm_con_button = null;
		By xpath_account_sel_con_button = null;
		By xpath_third_confrm_con_button = null;

		if (partnerName.contentEquals("GCB")) {

			xpath_userid_text = By.xpath("//*[@id='otp']");
			xpath_userid_con_button = By.xpath("//*[@id='LoginForm']/div[2]/citi-column[1]/div/button");
			xpath_otp_text = By.xpath("//*[@id='otp']");
			xpath_otp_con_button = By.xpath("//*[@id='OTPForm']/div[3]/citi-column[1]/div/button");
			xpath_account_active_sel_con_button = By.xpath("//*[@id='##YOUR_UNIQUE_ID_i5Label##']");

			xpath_first_confrm_con_button = By.xpath("//button[@class='btn small btn_continue']");
			xpath_second_confrm_con_button = By.xpath("//button[@class='btn small btn_continue']");
			xpath_third_confrm_con_button = By.xpath("//*[@id='ConfirmationForm']/div/citi-column[1]/div/button");

		} else if (partnerName.contentEquals("CRD")) {

			xpath_userid_text = By.xpath("//*[@id='otp']");
			xpath_userid_con_button = By.xpath("//*[@id='LoginForm']/div[2]/citi-column[1]/div/button");
			xpath_otp_text = By.xpath("//*[@id='otp']");
			xpath_otp_con_button = By.xpath("//*[@id='OTPForm']/div[3]/citi-column[1]/div/button");

			xpath_account_active_sel_con_button = By.xpath("//*[@id='##YOUR_UNIQUE_ID_i5Label##']");

			xpath_first_confrm_con_button = By.xpath("//*[@id='AuthorizeForm']/div[6]/citi-column[1]/div/button");
			xpath_second_confrm_con_button = By
					.xpath("//*[@id='content']/div/ng-component/div/div[7]/div/citi-column[1]/div/button");

			xpath_third_confrm_con_button = By.xpath("//*[@id='ConfirmationForm']/div/citi-column[1]/div/button");

		} else if (partnerName.contentEquals("QCC")) {
			xpath_userid_text = By.xpath("//*[@id='otp']");
			xpath_userid_con_button = By.xpath("//*[@id='LoginForm']/div[2]/citi-column[1]/div/button");
			xpath_otp_text = By.xpath("//*[@id='otp']");
			xpath_otp_con_button = By.xpath("//*[@id='OTPForm']/div[3]/citi-column[1]/div/button");
			xpath_account_sel_con_button = By.xpath("//*[@id='AuthorizeForm']/div[4]/citi-column[1]/div/button");
			xpath_first_confrm_con_button = By
					.xpath("//*[@id='content']/div/ng-component/div/div[6]/div/citi-column[1]/div/button");
			xpath_second_confrm_con_button = By.xpath("//*[@id='ConfirmationForm']/div/citi-column[1]/div/button");

		} else {

			System.out.println("Incorrect Partner name");
		}

		String loginUrl = excelHeaderValueMap.get("loginUrl");
		String client_id = excelHeaderValueMap.get("client_id");
		String state = excelHeaderValueMap.get("state");
		// String request = excelHeaderValueMap.get("request");
		String scope = excelHeaderValueMap.get("scope");
		String request_uri = StepDef.extraTestCaseP.get("request_uri");

		// def authzurl = loginUrl + "&scope="+scope + "&client_id="+client_id +
		// "&state="+state+ "&request="+request

		String authzurl = loginUrl + "&scope=" + scope + "&client_id=" + client_id + "&state=" + state + "&request_uri="
				+ request_uri;

		System.setProperty("webdriver.chrome.driver", cdpath.getCanonicalPath());

		try {
			StepDef.driver = new ChromeDriver();
		} catch (Exception e) {
			e.printStackTrace();
		}

		JavascriptExecutor js = (JavascriptExecutor) StepDef.driver;

		// Launch web
		StepDef.driver.navigate().to(authzurl);

		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("start-maximized");

		// Maximize the browser
		StepDef.driver.manage().window().maximize();
		Thread.sleep(7000);

		// First Screenshot before etnering user id
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		StepDef.driver.findElement(xpath_userid_text).sendKeys(excelHeaderValueMap.get("userName"));

		Thread.sleep(9000);
		castAscii = castAscii + 1;

		Thread.sleep(10000);

		// Second Screenshot after entering user id
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		StepDef.driver.findElement(xpath_userid_con_button).click();
		Thread.sleep(7000);
		castAscii = castAscii + 1;

		// run otp call and fetch
		RequestSpecification rspecotp;
		rspecotp = RestAssured.given();
		rspecotp.queryParam("MOBILENO", excelHeaderValueMap.get("lastFourDigit"));
		rspecotp.baseUri("http://gtgtc-tibla21t.nam.nsroot.net:48484");

		ExtractableResponse<Response> a = rspecotp.get().then().log().all().extract();
		String otp = null;
		String resp = a.response().getBody().asString();

		String[] responseOfStr = resp.split("Kindly");

		for (int i = 0; i <= responseOfStr.length - 1; i++) {

			if (resp.contains("countryCode - AU | BusinessCode - " + partnerName + " | ChannelId - SSA")) {
				String otpExtract = resp.split("for validation")[0].toString();
				int in = otpExtract.indexOf("OTP-") + 4;
				otp = otpExtract.substring(in, in + 6).toString();

				break;
			} else {

			}
		}

		StepDef.pr.setspecPropValue("otp", otp);
		// Store the ID of the original window
		String originalWindow = StepDef.driver.getWindowHandle();

		// Check we don't have other windows open already
		assert StepDef.driver.getWindowHandles().size() == 1;

		StepDef.driver.switchTo().window(originalWindow);
		Thread.sleep(7000);
		StepDef.driver.findElement(xpath_otp_text).sendKeys(otp);
		js.executeScript("window.scrollBy(0,600)");
		Thread.sleep(15000);
		castAscii = castAscii + 1;

		// Fourth screenshot after entering the otp
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		castAscii = castAscii + 1;
		StepDef.driver.findElement(xpath_otp_con_button).click();
		Thread.sleep(18000);
		castAscii = castAscii + 1;

		// Fifth screenshot in Account Selection page
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		StepDef.driver.findElement(xpath_account_active_sel_con_button).click();
		Thread.sleep(10000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,600)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,600)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,600)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		StepDef.driver.findElement(xpath_first_confrm_con_button).click();
		Thread.sleep(12000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		StepDef.driver.findElement(xpath_second_confrm_con_button).click();
		Thread.sleep(15000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		StepDef.driver.findElement(xpath_third_confrm_con_button).click();

		Thread.sleep(8000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		String qStr = StepDef.driver.getCurrentUrl();

		String qStrArr[] = qStr.split("=");

		String code = qStrArr[1].trim();

		if (code.length() > 0) {

			StepDef.extraTestCaseP.put("code", code);

			StepDef.pr.setspecPropValue("code", code);

		}

		StepDef.driver.close();
		StepDef.driver.quit();

	}

	@Then("Encrypt Key OF TC_ID {string} for kogan servicing")
	public void encryptPassword(String tcid) throws Throwable {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);

		String plainPassword = excelHeaderValueMap.get("CBOL_Password");
		String csType = "b";
		String encryptedPassword = "";
		String modulus = StepDef.extraTestCaseP.get("modulus");
		String exponent = StepDef.extraTestCaseP.get("exponent");
		String eventID = StepDef.extraTestCaseP.get("eventID}");
		String countryCode = excelHeaderValueMap.get("CountryCode");

		EncryptRSA rsa = new EncryptRSA();

		if (countryCode.toUpperCase() == "SG") {

			encryptedPassword = rsa.getEncryptedStringSG(modulus, exponent, plainPassword, eventID, csType);
			// encryptedPassword= rsa.getEncryptedStringSG(modulus, exponent,plainPassword,
			// eventID[0], csType )
		} else {

			encryptedPassword = rsa.getEncryptedString(modulus, exponent, plainPassword, eventID, csType);
			// encryptedPassword= rsa.getEncryptedString(modulus, exponent,plainPassword,
			// eventID[0], csType )
		}

		StepDef.pr.setspecPropValue("password", encryptedPassword);

		StepDef.extraTestCaseP.put("password", encryptedPassword);

	}

	@Then("Encrypt Key OF TC_ID {string} for kogan servicing name {string}")
	public void encryptPasswordcustomize(String tcid, String varname) throws Throwable {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);

		String plainPassword = excelHeaderValueMap.get("CBOL_Password");
		String csType = "b";
		String encryptedPassword = "";
		String modulus = StepDef.extraTestCaseP.get("modulus");
		String exponent = StepDef.extraTestCaseP.get("exponent");
		String eventID = StepDef.extraTestCaseP.get("eventID}");
		String otp = StepDef.extraTestCaseP.get("otp}");
		String countryCode = excelHeaderValueMap.get("CountryCode");

		EncryptRSA rsa = new EncryptRSA();

		if (countryCode.toUpperCase() == "SG") {

			encryptedPassword = rsa.getEncryptedStringSG(modulus, exponent, plainPassword, eventID, csType);
			// encryptedPassword= rsa.getEncryptedStringSG(modulus, exponent,plainPassword,
			// eventID[0], csType )
		} else {

			encryptedPassword = rsa.getEncryptedString(modulus, exponent, plainPassword, eventID, csType);
			// encryptedPassword= rsa.getEncryptedString(modulus, exponent,plainPassword,
			// eventID[0], csType )
		}

		encryptedPassword = rsa.getEncryptedString(modulus, exponent, otp, eventID, csType);

		StepDef.pr.setspecPropValue(varname, encryptedPassword);

		StepDef.extraTestCaseP.put(varname, encryptedPassword);

	}

	/* Step def to handle Authorisation respective to Kogan Servicing */
	@Then("Encrypt Password Kogan Servicing")
	public void encryptPassword() throws IOException {

		String j = StepDef.extraTestCaseP.get("Set-Cookie");
		String Authorization1 = j.split("access_token=")[1].split(";Domain=")[0];

		StepDef.extraTestCaseP.put("Authorization", Authorization1);
		StepDef.pr.setspecPropValue("Authorization", Authorization1);

	}

	/* Step def to handle transactionAmount */
	@Then("Apply formula to get data for transactionAmount")

	public void transactionAmount() throws IOException {

		String minimumPointsToRedeem = StepDef.extraTestCaseP.get("minimumPointsToRedeem").replace("[", "").replace("]",
				"");

		String programConversionRate = StepDef.extraTestCaseP.get("programConversionRate").replace("[", "").replace("]",
				"");

		double transactionAmount = Double.valueOf(minimumPointsToRedeem) * Double.valueOf(programConversionRate);

		transactionAmount = Math.round(transactionAmount);

		StepDef.extraTestCaseP.put("transactionAmount", String.valueOf(transactionAmount));

		StepDef.pr.setspecPropValue("transactionAmount", String.valueOf(transactionAmount));

		String currencyCode = StepDef.extraTestCaseP.get("currencyCode").replace("[", "").replace("]", "");

		StepDef.extraTestCaseP.put("currencyCode", currencyCode);

		StepDef.pr.setspecPropValue("currencyCode", currencyCode);

	}

	/* Step def to handle transactionAmount */
	@Then("validate function value OF TC_ID {string} and status code {string}")
	public void validateCardListingFunctions(String tcid, String statuscode) throws IOException {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();
		String len = "";
		StepDef.js = Utilities.rawToJson(response);

		String flag = "";

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);
		String function = excelHeaderValueMap.get("Function");

		if (statuscode.contains("${#TestCase#")) {

			statuscode = excelHeaderValueMap.get(statuscode.replace("${#TestCase#", "").replace("}", "").trim());

		}

		if (statuscode.contentEquals("200")) {

			len = StepDef.js.getString("cardDetails[0].cardFunctionsAllowed.size()");

			if (Integer.valueOf(len) > 0) {

				for (int i = 0; i < Integer.valueOf(len); i++) {

					if (StepDef.js.getString("cardDetails[0].cardFunctionsAllowed[" + i + "].cardFunction")
							.contentEquals(function)) {

						flag = function;

						break;

					}
				}

			}

			Assert.assertEquals(function, flag);

		}

	}

	@Then("Encrypt Key OF TC_ID {string} for Qantas servicing name {string}")
	public void encryptPinQantas(String tcid, String varname) throws Throwable {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);

		String modulus = StepDef.extraTestCaseP.get("modulus");
		String exponent = StepDef.extraTestCaseP.get("exponent");
		String pin = excelHeaderValueMap.get("PIN");

		Encrypt encrypted = new Encrypt();
		String enycripted = encrypted.getEncrypt(pin, modulus, exponent);

		StepDef.pr.setspecPropValue(varname, enycripted);

		StepDef.extraTestCaseP.put(varname, enycripted);

	}

	/* Step def to handle selenium UI script in feature file */
	@Then("call  HK_selenium_script OF TC_ID {string}")
	public static void sel_call_generateurl_hbk(String tcid) throws InterruptedException, IOException {

		String cpath = StepDef.pr.getUserPropValue("chromedriverpath");

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);

		// Creating the file folder for pasting screenshot
		String name = "Nick_Name_Joint_Account";
		String flow = "Login";
		int castAscii = 97;

		By xpath_userid_text = By.xpath("//*[@id='userid_input_mask']");
		By xpath_password_text = By.xpath("//*[@id='password_input']");
		By xpath_signOn_button = By.xpath("//*[@id='submit_login']");
		By xpath_all_account_slection_button = By.xpath("//*[@id='##YOUR_UNIQUE_ID_i5Label##']");
		By xpath_first_confrm_con_button = By.xpath("//button[@class='btn small btn-submit']");
		By xpath_second_confrm_con_button = By.xpath("//button[@class='btn small btn_continue']");
		By xpath_take_me_back_button = By.xpath("//button[@class='btn small btn_continue']");

		String loginUrl = excelHeaderValueMap.get("loginUrl");
		String client_id = excelHeaderValueMap.get("client_id");
		String state = excelHeaderValueMap.get("state");
		// String consentId = excelHeaderValueMap.get("consentId");
		String consentId = StepDef.extraTestCaseP.get("consentId");

		String scope = excelHeaderValueMap.get("scope");
		String redirect_uri = excelHeaderValueMap.get("redirect_uri");
		String ui = excelHeaderValueMap.get("ui");

		String authzurl = loginUrl + "&scope=" + scope + "&client_id=" + client_id + "&state=" + state + "&consentId="
				+ consentId + "&redirect_uri=" + redirect_uri + "&ui=" + ui;

		System.setProperty("webdriver.chrome.driver", cpath);

		try {
			StepDef.driver = new ChromeDriver();
		} catch (Exception e) {
			e.printStackTrace();
		}

		JavascriptExecutor js = (JavascriptExecutor) StepDef.driver;

		// Launch web
		StepDef.driver.navigate().to(authzurl);

		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("start-maximized");

		// Maximize the browser
		StepDef.driver.manage().window().maximize();
		Thread.sleep(7000);

		// First Screenshot before etnering user id
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		StepDef.driver.findElement(xpath_userid_text).sendKeys(excelHeaderValueMap.get("userName"));

		Thread.sleep(9000);
		castAscii = castAscii + 1;

		Thread.sleep(10000);

		// Second Screenshot after entering user id
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		StepDef.driver.findElement(xpath_password_text).sendKeys(excelHeaderValueMap.get("password"));
		Thread.sleep(7000);
		castAscii = castAscii + 1;

		// Third screenshot after entering the password
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		castAscii = castAscii + 1;
		StepDef.driver.findElement(xpath_signOn_button).click();
		Thread.sleep(18000);
		castAscii = castAscii + 1;

		// Fourth screenshot in Account Selection page
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,600)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,600)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		StepDef.driver.findElement(xpath_all_account_slection_button).click();
		Thread.sleep(10000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		StepDef.driver.findElement(xpath_first_confrm_con_button).click();
		Thread.sleep(10000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(4000);
		Lib.take_screenshot(StepDef.driver, castAscii, name);
		castAscii = castAscii + 1;

		// Confirmation in accounts screen
		StepDef.driver.findElement(xpath_second_confrm_con_button).click();
		Thread.sleep(15000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		// Take me back button to get auth code
		StepDef.driver.findElement(xpath_take_me_back_button).click();

		Thread.sleep(8000);
		castAscii = castAscii + 1;
		Lib.take_screenshot(StepDef.driver, castAscii, name);

		String qStr = StepDef.driver.getCurrentUrl();

		String qStrArr[] = qStr.split("code=");

		String code = qStrArr[1].trim();

		if (code.length() > 0) {

			StepDef.extraTestCaseP.put("code", code);

			StepDef.pr.setspecPropValue("code", code);

		}

		StepDef.driver.close();
		StepDef.driver.quit();

	}

	public static RSAPublicKey getPublicKeyFromModAndExpVNGRAB(String mod, String exp)
			throws NoSuchAlgorithmException, InvalidKeySpecException {

		BigInteger modulus = new BigInteger(mod, 10);
		BigInteger pubExponent = new BigInteger(exp, 10);

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(modulus, pubExponent);

		RSAPublicKey publicKeyChannel = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);

		return publicKeyChannel;
	}

	public static String generateJWE(String payload, String keyEncAlgo, String contentEncAlgo, String kid,
			PublicKey pubKey) throws Exception {
		String JWE = "";

		if (payload.isEmpty() || payload == null) {
			System.out.println("generateJWEUsingPublicCert(): The payload for generating JEW is empty");
		}

		JsonWebEncryption jwe = new JsonWebEncryption();

		try {

			jwe.setPayload(payload);
			jwe.setAlgorithmHeaderValue(keyEncAlgo);
			jwe.setEncryptionMethodHeaderParameter(contentEncAlgo);
			jwe.setKeyIdHeaderValue(kid);
			jwe.setKey(pubKey);

		} catch (Exception e) {
			System.out.println("generateJWEUsingPublicCert()" + "Error: " + e.getMessage());
		}
		return jwe.getCompactSerialization();

	}

	@Then("Encrypt Payload OF TC_ID {string} for AUVMA servicing")
	public void encryptPasswordAUVMA(String tcid) throws Throwable {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);

		String excelPayload = excelHeaderValueMap.get("JSONPayload");

		String modulus = StepDef.extraTestCaseP.get("modulus");
		String exponent = StepDef.extraTestCaseP.get("exponent");
		String keyIdentifier = StepDef.extraTestCaseP.get("keyIdentifier");
		String keyEncAlgo = excelHeaderValueMap.get("keyEncAlgo");
		String contentEncAlgo = excelHeaderValueMap.get("contentEncAlgo");

		RSAPublicKey pubKey = getPublicKeyFromModAndExp(modulus, exponent);

		String JWE = generateJWE(excelPayload, keyEncAlgo, contentEncAlgo, keyIdentifier, pubKey);

		StepDef.pr.setspecPropValue("jweSignature", JWE);

		StepDef.extraTestCaseP.put("jweSignature", JWE);

	}

	@Then("encrypt the PIN of TC_ID {string}")
	public void encryptPin(String tcid) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException {

		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);
		String PIN = excelHeaderValueMap.get("PIN");
		String modulus = StepDef.extraTestCaseP.get("modulus");
		String exponent = StepDef.extraTestCaseP.get("exponent");

		com.citi.e2e.Encrypt encrypted = new com.citi.e2e.Encrypt();

		String enycripted = encrypted.getEncrypt(PIN, modulus, exponent);
		StepDef.extraTestCaseP.put("newPin", enycripted);

	}

	@Then("generate encrypted pin for coles servicing")

	public void generatePin() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException,
			KeyStoreException, CertificateException, IOException, InvalidKeySpecException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		String OriginalPIN = "6971FFFFFFFFFFFF";
		// String modInt =
		// "18672182119076902248175210172716680601917558531504853471491719247400421524470821994057794518532603228476858544186575285282936367788118017192482389415524813151838878466531132176226643365287924462987217911445725390227470647418208161077222295298782692323911699070971839829962195239090980701566596686077709480632390423062124136522728162597424614372383835274398188213301500009385055482884069143546124536808920392982519944088419754107802456283870892718766631880715012817288533828791676168978172828525434363535560039295320321652699044546762269734815362193077310690619332600869035595375561322294817694438128313009819513404239";
		// String expoInt = "65537";
		String modInt = StepDef.extraTestCaseP.get("modulus");
		String expoInt = StepDef.extraTestCaseP.get("exponent");

		BigInteger modulus = new BigInteger(modInt, 10);
		BigInteger pubExponent = new BigInteger(expoInt, 10);
		// Generate RSA public key at channel using modulus and public exponent provided
		// by API
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");// KeyFactory.getInstance("RSA");
		RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(modulus, pubExponent);
		RSAPublicKey publicKeyChannel = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);
		// Hex
		// Encrypt using public key generated at channel using mod and expo
		byte[] encryptionData = Hex.decodeHex(OriginalPIN);// .decodeHex(OriginalPIN);//OriginalPIN
		// byte[] encryptionData = OriginalPIN.decodeHex();

		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, publicKeyChannel);
		byte[] encryptedText = cipher.doFinal(encryptionData);
		String encText = org.apache.commons.codec.binary.Hex.encodeHexString(encryptedText);// encryptedText.//.encodeHex();
		String toUpper = encText.toUpperCase();
		StepDef.extraTestCaseP.put("newPin", toUpper);
	}

	/*
	 * Then generate JWE signature with modulus, exponent, keyIdentifier and
	 * "filePath" in "directoryName" directory Author :- SN60943
	 */

	@Then("generate JWE signature with modulus, exponent, keyIdentifier and {string} in {string} directory")

	public void generateJWESingature(String filename, String directory) throws Exception {
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\requestPayloadJson\\" + directory + "\\" + filename;
		System.out.println(path);
		String content = readFile(path, StandardCharsets.UTF_8);
		// Getting public key
		String mod = StepDef.extraTestCaseP.get("modulus");
		String exp = StepDef.extraTestCaseP.get("exponent");
		String kid = StepDef.extraTestCaseP.get("keyIdentifier");
		RSAPublicKey pubKey = getPublicKeyFromModAndExp(mod, exp);
		// JWE Encryption Starts
		JWE = generateJWE(content, keyEncAlgo, contentEncAlgo, kid, pubKey);
		// jweSignature
		StepDef.extraTestCaseP.put("jweSignature", JWE);
		StepDef.pr.setspecPropValue("jweSignature", JWE);
		StepDef.extraTestCaseP.put("JWESignature", JWE);
		StepDef.pr.setspecPropValue("JWESignature", JWE);

		System.out.println("signature is: " + JWE);

	}

//Then add properties "hktvmall.properties" from the directory "input"

	@Then("add properties {string} from the directory {string}")

	public void addProperties(String filename, String directory) {
		String filepath = System.getProperty("user.dir") + "/" + directory + "/" + filename;
		try {

			fis = new FileInputStream(filepath);
			Props = new Properties();
			Props.load(fis);
			for (final String name : Props.stringPropertyNames()) {
				StepDef.extraTestCaseP.put(name, Props.getProperty(name));
			}
			System.out.println("keys are: " + StepDef.extraTestCaseP.toString());
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

//Then retrieve otp from the response

	@Then("retrieve otp from the response")

	public void retrieveOtp() {
		String body = StepDef.response.getBody().asString();
		String OTP = body.substring(body.indexOf('-') + 1, 26);
		StepDef.extraTestCaseP.put("linkageConfirmationCode", OTP);

		StepDef.extraTestCaseP.put("otp", OTP);

	}

//Then get the encrypted string with the modulus exponent and eventid

	@Then("get the encrypted string with the modulus exponent and eventid")

	public void getEncString() throws Throwable {
		System.out.println("Keys are: " + StepDef.extraTestCaseP.toString());
		String encryptedString = (new EncryptRSA()).getEncryptedString(StepDef.extraTestCaseP.get("modulus"),
				StepDef.extraTestCaseP.get("exponent"), StepDef.extraTestCaseP.get("otp"),
				StepDef.extraTestCaseP.get("Eventid"), "b");
		StepDef.extraTestCaseP.put("encryptedString", encryptedString);
		// otpToken
		StepDef.extraTestCaseP.put("otpToken", encryptedString);
		System.out.println("keys are:" + StepDef.extraTestCaseP.toString());
	}

	public static RSAPublicKey getPublicKeyFromModAndExp(String mod, String exp)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		BigInteger modulus = new BigInteger(mod, 10);
		BigInteger pubExponent = new BigInteger(exp, 10);

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(modulus, pubExponent);

		RSAPublicKey publicKeyChannel = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);

		return publicKeyChannel;
	}

	// Getting the Algorithm

	// JWE Encryption Starts

	// String JWE = generateJWE(data, keyEncAlgo, contentEncAlgo,kid, pubKey);

	public static String generateJWEVNGRAB(String payload, String keyEncAlgo, String contentEncAlgo, String kid,
			PublicKey pubKey) throws Exception {
		String JWE = "";

		if (payload.isEmpty() || payload == null) {
			System.out.println("generateJWEUsingPublicCert(): The payload for generating JEW is empty");
		}

		JsonWebEncryption jwe = new JsonWebEncryption();

		try {

			jwe.setPayload(payload);
			jwe.setAlgorithmHeaderValue(keyEncAlgo);
			jwe.setEncryptionMethodHeaderParameter(contentEncAlgo);
			jwe.setKeyIdHeaderValue(kid);
			jwe.setKey(pubKey);

		} catch (Exception e) {
			System.out.println("generateJWEUsingPublicCert()" + "Error: " + e.getMessage());
		}
		return jwe.getCompactSerialization();

	}

	static String readFile(String path, Charset encoding) throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded, encoding);
	}

	/*
	 * This step def to get property value of PointTransferPartner API with given
	 * partnerCategoryName and given partner name Author :- AM48355
	 */

	@Then("retrieve property value of PointTransferPartner API with partnerCategoryName {string} and partnerName {string}")
	public void retrievePropWithPartnerName(String partnerCategoryName, String partnerName)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException {

		boolean flag = false;
		int partnerDetailsCount = 0;
		int y = 0, j = 0;
		StepDef.js = Utilities.rawToJson(response);

		if (partnerCategoryName.contentEquals("airlines")) {
			partnerDetailsCount = Integer.valueOf(StepDef.js.getString("partnerCategory[0].partnerDetails.size()"));
			j = 0;
		} else {
			partnerDetailsCount = Integer.valueOf(StepDef.js.getString("partnerCategory[1].partnerDetails.size()"));
			j = 1;
		}

		for (int i = 0; i <= partnerDetailsCount; i++) {
			if (StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + i + "].partnerName").toString()
					.contentEquals(partnerName)) {
				flag = true;
				y = i;
				break;
			}
		}

		System.out.println(
				"Fee Obj: " + StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee"));

		if (StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee").contentEquals("[:]")) {
			StepDef.pr.setspecPropValue("affinityPartnerId",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].affinityPartnerId"));
			StepDef.extraTestCaseP.put("affinityPartnerId",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].affinityPartnerId"));// js.getString(value)
																													// ->
																													// response
																													// value
																													// in
																													// form
																													// of
																													// xpath

			StepDef.pr.setspecPropValue("minimumPointsToTransfer", StepDef.js
					.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].minimumPointsToTransfer"));
			StepDef.extraTestCaseP.put("minimumPointsToTransfer", StepDef.js
					.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].minimumPointsToTransfer"));

			StepDef.pr.setspecPropValue("programConversionRate",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].programConversionRate"));
			StepDef.extraTestCaseP.put("programConversionRate",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].programConversionRate"));

			StepDef.pr.setspecPropValue("feeType", "");
			StepDef.extraTestCaseP.put("feeType", "");

			StepDef.pr.setspecPropValue("feeAmount", "");
			StepDef.extraTestCaseP.put("feeAmount", "");

			StepDef.pr.setspecPropValue("feeCurrencyCode", "");
			StepDef.extraTestCaseP.put("feeCurrencyCode", "");

		} else {
			StepDef.pr.setspecPropValue("affinityPartnerId",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].affinityPartnerId"));
			StepDef.extraTestCaseP.put("affinityPartnerId",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].affinityPartnerId"));// js.getString(value)
																													// ->
																													// response
																													// value
																													// in
																													// form
																													// of
																													// xpath

			StepDef.pr.setspecPropValue("minimumPointsToTransfer", StepDef.js
					.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].minimumPointsToTransfer"));
			StepDef.extraTestCaseP.put("minimumPointsToTransfer", StepDef.js
					.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].minimumPointsToTransfer"));

			StepDef.pr.setspecPropValue("programConversionRate",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].programConversionRate"));
			StepDef.extraTestCaseP.put("programConversionRate",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].programConversionRate"));

			StepDef.pr.setspecPropValue("feeType",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee.feeType"));
			StepDef.extraTestCaseP.put("feeType",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee.feeType"));

			StepDef.pr.setspecPropValue("feeAmount",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee.feeAmount"));
			StepDef.extraTestCaseP.put("feeAmount",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee.feeAmount"));

			StepDef.pr.setspecPropValue("feeCurrencyCode",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee.feeCurrencyCode"));
			StepDef.extraTestCaseP.put("feeCurrencyCode",
					StepDef.js.getString("partnerCategory[" + j + "].partnerDetails[" + y + "].fee.feeCurrencyCode"));

		}

	}

	/*
	 * This step def to get cardId using displayCardNumber from excel Author :-
	 * AM48355
	 */
	@Then("Fetch cardID value in {string} from Array with displayCardNumber {string} with TC_ID {string}")
	public void getcardIDvaluefromArray(String cardId, String displayCardNumber, String tcid) throws IOException {

		// removing [] from extracted string
		Map<String, String> excelHeaderValueMap = new HashMap<String, String>();

		excelHeaderValueMap = Lib.getExcelColoumnHeaderMap(StepDef.excelPath, StepDef.sheet, StepDef.workBook, tcid);

		String displayCardNumberValue = excelHeaderValueMap.get(displayCardNumber);

		boolean flag = false;
		int y = 0;
		StepDef.js = Utilities.rawToJson(response);
		// js.getString("cardDetails[0].size");

		int cardDetailsCount = Integer.valueOf(StepDef.js.getString("cardDetails.size()"));

		System.out.print("cardDetailsCount" + cardDetailsCount);

		for (int i = 0; i <= cardDetailsCount; i++) {
			if (StepDef.js.getString("cardDetails[" + i + "].displayCardNumber").toString()
					.contentEquals(displayCardNumberValue)) {
				flag = true;
				y = i;
				break;
			}
		}

		if (flag == true) {
			StepDef.extraTestCaseP.put(cardId, StepDef.js.getString("cardDetails[" + y + "].cardId"));
			StepDef.pr.setspecPropValue(cardId, StepDef.js.getString("cardDetails[" + y + "].cardId"));
		} else {
			StepDef.extraTestCaseP.put(cardId, "no card present");
			StepDef.pr.setspecPropValue(cardId, "no card present");
		}
	}

	/*
	 * This step def for to get transactionAmount for partner pointTransfer from an
	 * array Author :- AM48355
	 */

	@Then("Apply formula to get transactionAmount from an Array")
	public void getTransactionAmountfromArray() throws IOException {

		// removing [] from extracted string

		String affinityPartnerId = StepDef.extraTestCaseP.get("affinityPartnerId").replace("[", "").replace("]", "");
		String minimumPointsToTransfer = StepDef.extraTestCaseP.get("minimumPointsToTransfer").replace("[", "")
				.replace("]", "");
		String programConversionRate = StepDef.extraTestCaseP.get("programConversionRate").replace("[", "").replace("]",
				"");
		String feeType = StepDef.extraTestCaseP.get("feeType").replace("[", "").replace("]", "");
		String feeAmount = StepDef.extraTestCaseP.get("feeAmount").replace("[", "").replace("]", "");
		String feeCurrencyCode = StepDef.extraTestCaseP.get("feeCurrencyCode").replace("[", "").replace("]", "");

		double pointsToTransfer = Double.valueOf(minimumPointsToTransfer) * Double.valueOf(programConversionRate);
		pointsToTransfer = Math.round(pointsToTransfer);
		StepDef.extraTestCaseP.put("pointsToTransfer", String.valueOf(pointsToTransfer));
		StepDef.pr.setspecPropValue("pointsToTransfer", String.valueOf(pointsToTransfer));

		String targetPoints = String.valueOf(pointsToTransfer);

		StepDef.extraTestCaseP.put("targetPoints", targetPoints);
		StepDef.pr.setspecPropValue("targetPoints", targetPoints);

		StepDef.extraTestCaseP.put("affinityPartnerId", affinityPartnerId);
		StepDef.pr.setspecPropValue("affinityPartnerId", affinityPartnerId);

		StepDef.extraTestCaseP.put("programConversionRate", programConversionRate);
		StepDef.pr.setspecPropValue("programConversionRate", programConversionRate);

		StepDef.extraTestCaseP.put("feeType", feeType);
		StepDef.pr.setspecPropValue("feeType", feeType);

		StepDef.extraTestCaseP.put("feeAmount", feeAmount);
		StepDef.pr.setspecPropValue("feeAmount", feeAmount);

		StepDef.extraTestCaseP.put("feeCurrencyCode", feeCurrencyCode);
		StepDef.pr.setspecPropValue("feeCurrencyCode", feeCurrencyCode);

	}

	@Then("retrieve active encryptedAccountNumber {string}")
	public void retrieveencryptedAccountNumber(String encryptedAccountNumber) throws KeyManagementException,
			UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		boolean flag = false;
		int y = 0;
		StepDef.js = Utilities.rawToJson(response);

		int accountDetailsCount = Integer.valueOf(StepDef.js.getString("accountDetails.size"));
		System.out.print("accountDetailsCount" + accountDetailsCount);

		for (int i = 0; i <= accountDetailsCount; i++) {
			if (StepDef.js.getString("accountDetails[" + i + "].accountStatus").toString().contentEquals("ACTIVE")) {

				flag = true;
				y = i;
				break;

			}
		}

		if (flag == true) {

			StepDef.pr.setspecPropValue(encryptedAccountNumber,
					StepDef.js.getString("accountDetails[" + y + "].encryptedAccountNumber"));
			StepDef.extraTestCaseP.put(encryptedAccountNumber,
					StepDef.js.getString("accountDetails[" + y + "].encryptedAccountNumber"));

		} else {

			StepDef.pr.setspecPropValue(encryptedAccountNumber, "no active payee present");
			StepDef.extraTestCaseP.put(encryptedAccountNumber, "no active payee present");

		}

	}

	/*
	 * Step def to get transactionReferenceId and orderId for SWP reversals API
	 * Author :- AM08458
	 */
	@Then("converting orderId")
	public void getTransactionReferenceIdAndOrderId() throws IOException {

		String orderId = StepDef.extraTestCaseP.get("orderId").replace("[", "").replace("]", "").trim();
		String transactionReferenceNumber = StepDef.extraTestCaseP.get("transactionReferenceNumber").replace("[", "")
				.replace("]", "").trim();

		StepDef.extraTestCaseP.put("orderId", String.valueOf(orderId));
		StepDef.pr.setspecPropValue("orderId", String.valueOf(orderId));

		StepDef.extraTestCaseP.put("transactionReferenceNumber", String.valueOf(transactionReferenceNumber));
		StepDef.pr.setspecPropValue("transactionReferenceNumber", String.valueOf(transactionReferenceNumber));

	}

	/*
	 * Step def to get transactionAmount for SnC API Author :- AM08458
	 */
	@Then("Apply formula to get data for SnC transactionAmount")

	public void transactionAmountforSnC() throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		String programConversionRate = StepDef.extraTestCaseP.get("rewardAccounts[1].programConversionRate")
				.replace("[", "").replace("]", "");
		StepDef.pr.setspecPropValue(programConversionRate, "programConversionRate");
		StepDef.extraTestCaseP.put(programConversionRate, "programConversionRate");
		String minimumRedemptionAmount = StepDef.extraTestCaseP
				.get("rewardAccounts[1].partialRedemption[0].minimumRedemptionAmount").replace("[", "")
				.replace("]", "");
		StepDef.pr.setspecPropValue(minimumRedemptionAmount, "minimumRedemptionAmount");
		StepDef.extraTestCaseP.put(minimumRedemptionAmount, "minimumRedemptionAmount");

		double pointsToTransfer = Double.valueOf(minimumRedemptionAmount) * Double.valueOf(programConversionRate);
		pointsToTransfer = Math.round(pointsToTransfer);
		StepDef.extraTestCaseP.put("pointsToTransfer", String.valueOf(pointsToTransfer));
		StepDef.pr.setspecPropValue("pointsToTransfer", String.valueOf(pointsToTransfer));

	}

}
