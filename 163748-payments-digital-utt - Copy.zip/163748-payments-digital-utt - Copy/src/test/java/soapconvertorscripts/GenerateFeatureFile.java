package soapconvertorscripts;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import utilities.ExcelConfiguration;
import utilities.ExcelDataReader;
import utilities.PropertiesReader;
import utilities.soapXMLParser;

public class GenerateFeatureFile {

	List<Map<String, String>> data;
	static List<Map<String, String>> dataa;
	public static PropertiesReader pr = new PropertiesReader();
	public static Map<String, String> extraOutputPropp = new HashMap<String, String>();

	public static String workBook = pr.getUserPropValue("workBook");
	public static String excelPath = pr.getUserPropValue("excelPath");
	public static String xmlPath = pr.getUserPropValue("xmlPath");

	public static String userTestSuiteName = pr.getUserPropValue("userTestSuiteName");
	public static String userTestCaseName = pr.getUserPropValue("userTestCaseName");
	public static String usertestdatasheet = pr.getUserPropValue("usertestdatasheet");
	static String TestCase_ID = pr.getUserPropValue("primaryKey");
	public static String testStepName = "";

	public static int ActiveStepIndex;
	public static int firstActiveStepIndex;
	static String scPath = "output\\" + userTestSuiteName + ".feature";
	public static File logPath = new File("src\\test\\resources\\Log\\UI");
	public static File uilogPath = new File("src\\test\\resources\\Log\\UI_Screenshots");

	static Map<String, String> resultExtractor = new HashMap<String, String>();

	public static void main(String arg[]) throws ParseException, IOException {

		ArrayList<String> dep = new ArrayList<String>();
		dep = soapXMLParser.returnDependentSteps(userTestSuiteName, userTestCaseName, xmlPath);

		for (int z = 0; z < dep.size() - 2; z++) {
			String depValue = dep.get(z);
			if (!depValue.contains("id=")) {
				ActiveStepIndex = z;
			}
		}

		for (int z = 0; z < dep.size() - 2; z++) {
			String depValue = dep.get(z);
			if (depValue.contains("id")) {
			} else {
				firstActiveStepIndex = z;
				break;
			}
		}

		FileWriter fw = new FileWriter(scPath, false);
		BufferedWriter bw = new BufferedWriter(fw);
		ExcelConfiguration config = new ExcelConfiguration.ExcelConfigurationBuiler().setFileName(workBook)
				.setFileLocation(excelPath).setSheetName(usertestdatasheet).build();
		ExcelDataReader excelObj = new ExcelDataReader(config);
		bw.newLine();
		String text = "Feature: " + userTestSuiteName;
		bw.write(text);

		int rowsize = excelObj.getAllRows().size();

		for (int k = 0; k < rowsize; k++) {

			for (int i = 0; i <= dep.size() - 3; i++) {

				int apilen = dep.size() - 2;

				testStepName = dep.get(i).trim();
				String scenari = "";

				if (!testStepName.contains("Delay")) {
					if (!soapXMLParser.onlyDigits(testStepName)) {

						if (k == 0) {

							System.out.println(testStepName);

						}

						if (!soapXMLParser
								.returnTestStepType(userTestSuiteName, userTestCaseName, testStepName, xmlPath)
								.contains("groovy")) {

							if (i < (ActiveStepIndex) && k == 0 && apilen > 1) {
								generateScenarioesBackground(userTestSuiteName, userTestCaseName, xmlPath, bw, excelObj,
										k, i, firstActiveStepIndex, ActiveStepIndex, scenari);
								RetriveProp(bw, text);

							} else if (i == (ActiveStepIndex)) {
								generateScenarioes(userTestSuiteName, userTestCaseName, xmlPath, bw, excelObj, k,
										firstActiveStepIndex, ActiveStepIndex, k);
								RetriveProp(bw, text);
							}

						} else if (k == 0) {

							extraTestCaseProp(userTestSuiteName, userTestCaseName, xmlPath, false);
							RetriveProp(bw, text);
						}

					}

				} else if (testStepName.contains("Delay") && k == 0) {
					bw.newLine();
					text = "20000";
					if (k == 0) {
						System.out.println(testStepName);
					}
					bw.write("Then Apply wait for \"" + text + "\"");
				}

			}
		}

		clodeBw(bw);

	}

	public static void RetriveProp(BufferedWriter bw, String text) {
		try {
			Iterator<Entry<String, String>> it = extraOutputPropp.entrySet().iterator();
			String prop = "";
			String value = "";
			while (it.hasNext()) {
				@SuppressWarnings("rawtypes")
				Map.Entry pair = it.next();
				prop = pair.getKey().toString();
				value = pair.getValue().toString();

				bw.newLine();
				text = "And retrieve property \"" + prop + "\" \"" + value + "\" value";
				bw.write(text);

			}
			extraOutputPropp.clear();
		} catch (Exception e) {

		}
	}

	public static void generateScenarioes(String TestSuiteName, String TestCaseName, String xmlPath, BufferedWriter bw,
			ExcelDataReader excelObj, int i, int apilength, int apilength2, int k) throws IOException, ParseException {

		Map<String, String> excelHeaderRowMap = new HashMap<String, String>();

		excelHeaderRowMap = excelObj.getAllRows().get(i);
		String TC_ID1 = excelHeaderRowMap.get(TestCase_ID);
		String scenario;
		String text;
		String expectedcode = excelHeaderRowMap.get("Expected_Status_Code");
		String scenarioName = excelHeaderRowMap.get("TestCase_API_Name");
		if (scenarioName == null) {
			scenarioName = excelHeaderRowMap.get("Test Case Name");
		}
		String envEndpoint = "";
		String res = soapXMLParser.getResourcePath(TestSuiteName, TestCaseName, testStepName, xmlPath);

		String method = soapXMLParser.getTestMethod(TestSuiteName, TestCaseName, testStepName, xmlPath);

		String uri = soapXMLParser.getEndpoint(TestSuiteName, TestCaseName, testStepName, xmlPath);

		if (uri.contains("#Project#")) {

			envEndpoint = uri.replace("${#Project#", "").replace("}", "");
		}

		scenario = "Scenario: " + scenarioName;

		String ploadtype = soapXMLParser.getPayloadType(TestSuiteName, userTestCaseName, testStepName, xmlPath);

		if (ploadtype.toString().contains("application/x-www-form-urlencoded")) {

			String j = soapXMLParser.getSamplePayload(TestSuiteName, userTestCaseName, testStepName, xmlPath);

			text = "When user provides Payload OF TC_ID \"" + TC_ID1
					+ "\" with type application x-www-form-urlencoded value \"" + j + "\"";
			// bw.write(text);
			bw.newLine();

			formHeaderOfRel(TestSuiteName, TestCaseName, xmlPath, TC_ID1, bw, excelHeaderRowMap);
			bw.newLine();
			text = "And user submit a " + " " + method + " " + "with type \"form\" for " + res + " in \"" + envEndpoint
					+ "\" OF TC_ID \"" + TC_ID1 + "\"";

			bw.write(text);

		} else if (ploadtype.toString().contains("application/json")) {

			int param = 1;

			for (int j = 0; j <= excelObj.getAllRows().size() - 1; j++) {

				if (excelObj.getAllRows().get(j).get(TestCase_ID).contentEquals(TC_ID1)) {

					param = j;

					break;
				}
			}

			excelHeaderRowMap = excelObj.getAllRows().get(param);

			payLoadof(TestSuiteName, userTestCaseName, xmlPath, TC_ID1, bw, apilength, apilength2, scenario, k);

			HeaderOfRel(TestSuiteName, userTestCaseName, xmlPath, TC_ID1, bw, excelHeaderRowMap);

			bw.newLine();

//			text = "When user submit a " + " " + method + " " + res + "" + " in \"" + envEndpoint + "\" OF TC_ID \""
//					+ TC_ID1 + "\"";

			text = "And user submit a " + " " + method + " " + "with type \"json\" for " + res + " in \"" + envEndpoint
					+ "\" OF TC_ID \"" + TC_ID1 + "\"";

			bw.write(text);

		}

		if (TestCaseName.contentEquals(userTestCaseName)) {
			bw.newLine();
			text = "Then validate value of statuscode  is \"" + expectedcode + "\" ";

			bw.write(text);

		} else {
			bw.newLine();
			text = "200";
			bw.write("Then validate value of statuscode  is \"" + text + "\"");

		}
		extraTestCaseProp(TestSuiteName, userTestCaseName, xmlPath, true);

	}

	public static void generateScenarioesBackground(String TestSuiteName, String userTestCaseName, String xmlPath,
			BufferedWriter bw, ExcelDataReader excelObj, int k, int i, int firstActiveStepIndex, int apiIteration,
			String scenario) throws IOException, ParseException {

		Map<String, String> excelHeaderRowMap = new HashMap<String, String>();

		excelHeaderRowMap = excelObj.getAllRows().get(k);
		String TC_ID1 = excelHeaderRowMap.get(TestCase_ID);
		String text;
		String envEndpoint = "";
		String backgroundtext;
		String intializeRest;
		String proxyset;
		String relaxProxy;
		String excelText;
		String res = soapXMLParser.getResourcePath(TestSuiteName, userTestCaseName, testStepName, xmlPath);

		String method = soapXMLParser.getTestMethod(TestSuiteName, userTestCaseName, testStepName, xmlPath);

		String uri = soapXMLParser.getEndpoint(TestSuiteName, userTestCaseName, testStepName, xmlPath);

		if (uri.contains("#Project#")) {

			envEndpoint = uri.replace("${#Project#", "").replace("}", "");
		}
		String expectedcode = excelHeaderRowMap.get("Expected_Status_Code");
		String scenarioName = excelHeaderRowMap.get("TestCase_API_Name");

		bw.newLine();
		bw.newLine();
		bw.newLine();

		backgroundtext = "Background: ";
		intializeRest = "And initialize rest assured object";
		proxyset = "And setssl and proxy";
		relaxProxy = "And relax proxy";
		excelText = "Given Couple Excel \"" + pr.getUserPropValue("workBook") + "\" on path \""
				+ pr.getUserPropValue("excelPath") + "\" in sheet \"" + pr.getUserPropValue("usertestdatasheet") + "\"";

		if ((i == firstActiveStepIndex || i == 0) && k == 0) {
			bw.write(backgroundtext);
			bw.newLine();
			bw.write(excelText);
			bw.newLine();
			bw.write(intializeRest);

		}

		String ploadtype = soapXMLParser.getPayloadType(TestSuiteName, userTestCaseName, testStepName, xmlPath);

		if (ploadtype.toString().contains("application/x-www-form-urlencoded")) {

			String j = soapXMLParser.getSamplePayload(TestSuiteName, userTestCaseName, testStepName, xmlPath);

			bw.newLine();
			bw.newLine();
			text = "When user provides Payload OF TC_ID \"" + TC_ID1
					+ "\" with type application x-www-form-urlencoded value \"" + j + "\"";

			if (k == 0) {
				bw.newLine();
				bw.write(proxyset);
				bw.newLine();
				bw.write(relaxProxy);
				bw.newLine();
				bw.write(text);
			}

			formHeaderOfRel(TestSuiteName, userTestCaseName, xmlPath, TC_ID1, bw, excelHeaderRowMap);

			bw.newLine();
//			text = "When user submit a " + " " + method + " " + res + " with application as form" + " in \""
//					+ envEndpoint + "\"";

			text = "And user submit a " + " " + method + " " + "with type \"form\" for " + res + " in \"" + envEndpoint
					+ "\" OF TC_ID \"" + TC_ID1 + "\"";

			if (k == 0) {
				bw.write(text);
			}

		} else if (ploadtype.toString().contains("application/json")) {

			int param = 1;

			for (int j = 0; j <= excelObj.getAllRows().size() - 1; j++) {

				if (excelObj.getAllRows().get(j).get(TestCase_ID).contentEquals(TC_ID1)) {

					param = 0;

					break;
				}
			}

			excelHeaderRowMap = excelObj.getAllRows().get(param);

			payLoadof(TestSuiteName, userTestCaseName, xmlPath, TC_ID1, bw, i, apiIteration, scenarioName, k);

			HeaderOfRel(TestSuiteName, userTestCaseName, xmlPath, TC_ID1, bw, excelHeaderRowMap);

			bw.newLine();
//			text = "When user submit a " + " " + method + " " + res + "" + " in \"" + envEndpoint + "\" OF TC_ID \""
//					+ TC_ID1 + "\"";

			text = "And user submit a " + " " + method + " " + "with type \"json\" for " + res + " in \"" + envEndpoint
					+ "\" OF TC_ID \"" + TC_ID1 + "\"";

			if (k == 0) {
				bw.write(text);
			}
		}

		if (userTestCaseName.contentEquals(userTestCaseName)) {
			bw.newLine();
			text = "Then validate value of statuscode  is \"" + expectedcode + "\" ";

			bw.write(text);
		} else {
			bw.newLine();
			text = "200";
			bw.write("Then validate value of statuscode  is \"" + text + "\"");

		}
		extraTestCaseProp(TestSuiteName, userTestCaseName, xmlPath, true);

	}

	public static void clodeBw(BufferedWriter bw) throws IOException {

		bw.close();
	}

	@SuppressWarnings({ "unchecked", "unused" })
	public static void payLoadof(String TestSuiteName, String TestCaseName, String xmlPath, String TC_ID,
			BufferedWriter bw, int apilength, int apiIteration, String scenario, int k)
			throws IOException, ParseException {

		String proxyset;
		String relaxProxy;
		proxyset = "And setssl and proxy";
		relaxProxy = "And relax proxy";
		String j = soapXMLParser.getSamplePayload(TestSuiteName, userTestCaseName, testStepName, xmlPath);

		if (j == "") {
			bw.newLine();
			bw.write(proxyset);
			bw.newLine();
			bw.write(relaxProxy);
			bw.newLine();
			String text = "When user provides Payload OF TC_ID \"" + TC_ID
					+ "\" with type application json head as application/json";

			if (firstActiveStepIndex == apilength) {
				bw.newLine();
				bw.newLine();
				bw.write(scenario);
				bw.newLine();
				bw.write(proxyset);
				bw.newLine();
				bw.write(relaxProxy);
				bw.newLine();

			} else if (k >= 0) {

			}
		} else if (j.charAt(0) == '$') {

			String[] s = j.split("#");

			String jkl = s[s.length - 1];

			jkl = jkl.replaceAll("}", "");

			String payloadExcelRequestHeader = jkl.toString().trim();

			bw.newLine();

			if (firstActiveStepIndex == apilength) {
				bw.newLine();
				bw.write(scenario);
				bw.newLine();
			} else if (k > 0) {
				bw.newLine();
				bw.write(scenario);
				bw.newLine();
				bw.write(proxyset);
				bw.newLine();
				bw.write(relaxProxy);

				bw.newLine();
			}
			String text = "When user provides Payload OF TC_ID \"" + TC_ID + "\" with type application json head as \""
					+ payloadExcelRequestHeader + "\"";

			if (k >= 0) {
				bw.newLine();
				bw.write(proxyset);
				bw.newLine();
				bw.write(relaxProxy);
				bw.newLine();
				bw.write(text);
			}
		} else {

			bw.newLine();
			String text = "When user provides Payload OF TC_ID \"" + TC_ID + "\" with type application json for \""
					+ testStepName + "\" API in \"" + TestSuiteName + "\"";

			bw.newLine();

			if (firstActiveStepIndex == apilength) {
				bw.write(scenario);
				bw.newLine();
				bw.write(proxyset);
				bw.newLine();
				bw.write(relaxProxy);
				bw.newLine();
				bw.write(text);

			} else if (k > 0) {
				bw.newLine();
				bw.write(scenario);
				bw.newLine();
				bw.write(proxyset);
				bw.newLine();
				bw.write(relaxProxy);
				bw.newLine();

			} else if (k >= 0) {
				bw.newLine();
				bw.write(proxyset);
				bw.newLine();
				bw.write(relaxProxy);
				bw.newLine();
				bw.write(text);
			}

			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(j);

			JSONArray arr = new JSONArray();
			arr.add(json);

			File PayloadPath = new File("src/test/resources/json/" + TestSuiteName + "/");
			if (!PayloadPath.isDirectory()) {
				PayloadPath.mkdirs();
			}

			try (FileWriter file = new FileWriter(PayloadPath + "/" + testStepName + ".json")) {

				file.write(arr.toJSONString().replace("[", "").replace("]", ""));
				file.flush();
			}
		}
	}

	public static void HeaderOf(String TestSuiteName, String TestCaseName, String xmlPath, String TC_ID,
			BufferedWriter bw, Map<String, String> excelHeaderRowMap) throws IOException, ParseException {

		Map<String, String> header = soapXMLParser.getHeaderMap(TestSuiteName, userTestCaseName, testStepName, xmlPath);
		Map<String, String> propTcase = soapXMLParser.getPropertiesTestCase(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> propTcsuite = soapXMLParser.getPropertiesTestSuite(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> valueAdderHeader = new HashMap<String, String>();
		Iterator<Entry<String, String>> it = header.entrySet().iterator();

		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();
			String attbt = pair.getValue().toString();
			String flg = "";

			do {

				flg = "";

				try {

					if (attbt.contains("#TestCase#")) {

						String trunc = attbt.replace("${#TestCase#", "").replace("}", "");
						if (propTcase.containsKey(trunc)) {

							if (propTcsuite.containsKey(trunc)) {
								valueAdderHeader.put(pair.getKey().toString(), propTcsuite.get(trunc));
								flg = propTcsuite.get(trunc);
								attbt = flg;
							} else {

								if (excelHeaderRowMap.get(trunc) != null) {
									valueAdderHeader.put(pair.getKey().toString(), excelHeaderRowMap.get(trunc));
									flg = excelHeaderRowMap.get(trunc).toString();
									attbt = flg;

								} else {
									valueAdderHeader.put(pair.getKey().toString(), propTcase.get(trunc));
									flg = propTcase.get(trunc).toString();
									attbt = flg;
								}
							}
						} else {
							valueAdderHeader.put(pair.getKey().toString(), trunc);
							flg = trunc;
							attbt = flg;

						}

					} else if (attbt.contains("#Project#")) {

						String trunc = attbt.replace("${#Project#", "").replace("}", "");

						if (propTcsuite.containsKey(trunc)) {
							valueAdderHeader.put(pair.getKey().toString(), propTcsuite.get(trunc));
							flg = flg + propTcsuite.get(trunc);
							attbt = flg;
						}

					} else {

						valueAdderHeader.put(pair.getKey().toString(), attbt.trim());
						flg = flg + attbt.trim();
						attbt = flg;

					}
				} catch (Exception e) {
					System.out.println(e.getLocalizedMessage());
				}

			} while (flg.contains("${#"));

		}

		bw.newLine();

		String text = "And user provides \"blank\" Headers OF TC_ID\" " + TC_ID + "\"";
		bw.write(text);

		String h = "";
		String v = "";

		it = valueAdderHeader.entrySet().iterator();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			h = h + "|" + pair.getKey();
			v = v + "|" + pair.getValue();

		}

		h = h + "|";
		v = v + "|";

		bw.newLine();
		bw.write(h);
		bw.newLine();
		bw.write(v);

	}

	public static void HeaderOfRel(String TestSuiteName, String TestCaseName, String xmlPath, String TC_ID,
			BufferedWriter bw, Map<String, String> excelHeaderRowMap) throws IOException, ParseException {

		Map<String, String> header = soapXMLParser.getHeaderMap(TestSuiteName, userTestCaseName, testStepName, xmlPath);

		Map<String, String> valueAdderHeader = new HashMap<String, String>();

		Map<String, String> propTcase = soapXMLParser.getPropertiesTestCase(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> propTcsuite = soapXMLParser.getPropertiesTestSuite(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);

		Iterator<Entry<String, String>> suiteProp = propTcsuite.entrySet().iterator();
		while (suiteProp.hasNext()) {
			Entry<String, String> suitePair = suiteProp.next();

			String suiteKey = suitePair.getKey().toString();
			String suiteValue = suitePair.getValue().toString();
			if (suiteValue.contains("http")) {
				pr.setPropValue(suiteKey, suiteValue);

			}
		}

		int headerSize = header.size();
		int expheaderSize = 0;

		Iterator<Entry<String, String>> it = header.entrySet().iterator();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			try {

				String key = pair.getKey().toString();
				String value = pair.getValue().toString().trim().toString();

				if (value.contains("java.util.")) {
					valueAdderHeader.put(key, value);
				} else {

					do {
						if (value.contains("${#Project#")) {

							String g = propTcsuite
									.get(value.replace("${#Project#", "").replace("\"", "").replace("}", ""));

							value = g;
							valueAdderHeader.put(key, value);

						} else if (value.contains("${#TestCase#")) {
							String v;

							do {

								v = excelHeaderRowMap
										.get(value.replace("${#TestCase#", "").replace("\"", "").replace("}", ""));

								if (v == null) {
									value = propTcase
											.get(value.replace("${#TestCase#", "").replace("\"", "").replace("}", ""));
								} else {
									value = v;
								}

								valueAdderHeader.put(key, value);
								expheaderSize++;
							} while (headerSize == expheaderSize);

						} else if (value.contains("$")) {

						} else {

							valueAdderHeader.put(key, value);
						}
					} while (value.contains("${#Project"));
				}

			} catch (Exception e) {
				System.out.println(e.getLocalizedMessage());
			}
		}

		bw.newLine();

		String text = "And user provides \"blank\" Headers OF TC_ID \"" + TC_ID + "\"";
		bw.write(text);

		String h = "";
		String v = "";

		it = valueAdderHeader.entrySet().iterator();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			h = h + "|" + pair.getKey();
			v = v + "|" + pair.getValue();

		}

		h = h + "|";
		v = v + "|";

		bw.newLine();
		bw.write(h);
		bw.newLine();
		bw.write(v);

	}

	public static void formHeaderOf(String TestSuiteName, String TestCaseName, String xmlPath, String TC_ID,
			BufferedWriter bw, Map<String, String> excelHeaderRowMap) throws IOException, ParseException {

		Map<String, String> header = soapXMLParser.getHeaderMap(TestSuiteName, userTestCaseName, testStepName, xmlPath);
		Map<String, String> propTcase = soapXMLParser.getPropertiesTestCase(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> propTcsuite = soapXMLParser.getPropertiesTestSuite(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> valueAdderHeader = new HashMap<String, String>();
		Iterator<Entry<String, String>> it = header.entrySet().iterator();

		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			if (pair.getValue().toString().contains("#TestCase#")) {
				String trunc = pair.getValue().toString().replace("${#TestCase#", "").replace("}", "");
				if (propTcase.containsKey(trunc)) {
					if (propTcsuite.containsKey(trunc)) {
						valueAdderHeader.put(pair.getKey().toString(), propTcsuite.get(trunc));
					} else {

						if (excelHeaderRowMap.get(pair.getKey().toString()) != null) {
							valueAdderHeader.put(pair.getKey().toString(),
									excelHeaderRowMap.get(pair.getKey().toString()));
						} else {
							valueAdderHeader.put(pair.getKey().toString(), propTcase.get(trunc));
						}
					}
				}

			} else if (pair.getValue().toString().contains("#Project#")) {
				String trunc = pair.getValue().toString().replace("${#Project#", "").replace("}", "");
				if (propTcsuite.containsKey(trunc)) {
					valueAdderHeader.put(pair.getKey().toString(), propTcsuite.get(trunc));
				}
			}

			else {
				valueAdderHeader.put(pair.getKey().toString(), pair.getValue().toString().trim());
			}
		}

		bw.newLine();
		String text = "And user provides \"form\" Headers OF TC_ID \"" + TC_ID + "\"   ";
		bw.write(text);
		String h = "";
		String v = "";

		it = valueAdderHeader.entrySet().iterator();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			h = h + "|" + pair.getKey();
			v = v + "|" + pair.getValue();
		}

		h = h + "|";
		v = v + "|";

		bw.newLine();
		bw.write(h);
		bw.newLine();
		bw.write(v);

	}

	public static void formHeaderOfRel(String TestSuiteName, String TestCaseName, String xmlPath, String TC_ID,
			BufferedWriter bw, Map<String, String> excelHeaderRowMap) throws IOException, ParseException {

		Map<String, String> header = soapXMLParser.getHeaderMap(TestSuiteName, userTestCaseName, testStepName, xmlPath);
		Map<String, String> propTcase = soapXMLParser.getPropertiesTestCase(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> propTcsuite = soapXMLParser.getPropertiesTestSuite(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> valueAdderHeader = new HashMap<String, String>();

		Iterator<Entry<String, String>> it = header.entrySet().iterator();

		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			try {

				String key = pair.getKey().toString();
				String value = pair.getValue().toString().trim().toString();

				if (value.contains("java.util.")) {
					valueAdderHeader.put(key, value);
				} else {

					do {
						if (value.contains("${#Project#")) {

							String g = propTcsuite
									.get(value.replace("${#Project#", "").replace("\"", "").replace("}", ""));
							value = g;
							valueAdderHeader.put(key, value);

						} else if (value.contains("${#TestCase#")) {
							String v;

							do {

								v = excelHeaderRowMap
										.get(value.replace("${#TestCase#", "").replace("\"", "").replace("}", ""));

								if (v == null) {
									value = propTcase
											.get(value.replace("${#TestCase#", "").replace("\"", "").replace("}", ""));
								} else {
									value = v;
								}

								valueAdderHeader.put(key, value);

							} while (v != null);

						} else {

							valueAdderHeader.put(key, value);
						}

					} while (value.contains("${#Project"));
				}

			} catch (Exception e) {
				System.out.println(e.getLocalizedMessage());
			}

		}

		bw.newLine();
		String text = "And user provides \"form\" Headers OF TC_ID \"" + TC_ID + "\"   ";
		bw.write(text);
		String h = "";
		String v = "";

		it = valueAdderHeader.entrySet().iterator();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			h = h + "|" + pair.getKey();
			v = v + "|" + pair.getValue();

		}

		h = h + "|";
		v = v + "|";

		bw.newLine();
		bw.write(h);
		bw.newLine();
		bw.write(v);

	}

	public static Map<String, String> extraTestCaseProp(String TestSuiteName, String TestCaseName, String xmlPath,
			boolean groovyType) {
		String gs;
		if (groovyType == true) {
			gs = soapXMLParser.returnGroovyAssertion(TestSuiteName, userTestCaseName, testStepName, xmlPath);
		} else {
			gs = soapXMLParser.returnGroovyScript(TestSuiteName, userTestCaseName, testStepName, xmlPath);
		}
		Map<String, String> extraOutputProp = new HashMap<String, String>();
		Map<String, String> responseProperty = new HashMap<String, String>();

		// ArrayList<Integer> oc = new ArrayList<Integer>();

		int index = gs.indexOf(".setPropertyValue");
		while (index >= 0) {
			String d = "";
			for (int i = index; i <= gs.length() - 1; i++) {

				if (String.valueOf(gs.charAt(i)).contentEquals(")")) {
					break;
				} else {
					d = d + String.valueOf(gs.charAt(i));
				}
			}

			if (!extraOutputProp.containsKey(d.split("\"")[1].toString().trim())) {

				extraOutputProp.put(d.split("\"")[1].toString().trim(),
						d.split("\"")[2].toString().replace(",", "").trim());

			}
			Iterator<Entry<String, String>> itt = extraOutputProp.entrySet().iterator();
			while (itt.hasNext()) {
				@SuppressWarnings("rawtypes")
				Map.Entry pair = itt.next();
				if (pair.getKey().equals("Authorization")) {
					extraOutputProp.put("Authorization", "access_token");
				}
			}
			index = gs.indexOf(".setPropertyValue", index + 1);
		}
		responseProperty = extraTestCasePropSlurper(gs, extraOutputProp);

		try {
			Iterator<Entry<String, String>> it = responseProperty.entrySet().iterator();

			while (it.hasNext()) {
				Entry<String, String> pair = it.next();
				extraOutputPropp.put(pair.getKey().toString(), pair.getValue().toString());
			}
		} catch (Exception e) {
			System.out.println("error");
		}
		return extraOutputPropp;

	}

	public static Map<String, String> extraTestCasePropSlurper(String gs, Map<String, String> m) {

		Map<String, String> ot = new HashMap<String, String>();
		Iterator<Entry<String, String>> it = m.entrySet().iterator();

		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry pair = it.next();

			int index = gs.indexOf(pair.getValue().toString());

			String d = "";
			for (int i = index; i <= gs.length() - 1; i++) {

				if (String.valueOf(gs.charAt(i)).contentEquals("\n")) {
					break;
				} else {
					d = d + String.valueOf(gs.charAt(i));
				}
			}

			String matcher = "";
			String match = "";
			String actMatch = "";
			String resMatcher = "= new JsonSlurper()";
			int resm = gs.indexOf(resMatcher);

			if (resm != -1) {
				for (int h = resm; h <= gs.length(); h--) {

					if (String.valueOf(gs.charAt(h)).contains("\n")) {
						break;
					} else {
						match = match + String.valueOf(gs.charAt(h));
						StringBuilder bs = new StringBuilder(match);
						bs.reverse();
						actMatch = bs.toString().trim();
					}

				}

				if (actMatch.contains("def")) {
					String[] refmatch = actMatch.split(" ");
					String Arrmatch = refmatch[1];
					matcher = Arrmatch.trim();
				} else {
					String[] refmatch = actMatch.split(" ");
					String Arrmatch = refmatch[0];

					matcher = Arrmatch.trim();
				}

			}

			if (d.contains(matcher)) {
				String mn = "";
				for (int i = d.indexOf(matcher + ".") + matcher.length() + 1; i <= d.length() - 1; i++) {

					if (String.valueOf(d.charAt(i)).contentEquals("\n")) {
						break;
					} else {
						mn = mn + String.valueOf(d.charAt(i));
					}
				}

				ot.put(pair.getKey().toString(), mn.toString().replace(")", ""));
			} else {

				String a[] = d.split("\\+");

				for (int l = 0; l <= a.length - 1; l++) {

					a[l] = a[l].replace("\"", "").replace(" ", "").trim();
				}

				for (int t = 0; t <= a.length - 1; t++) {

					if (gs.indexOf(a[t]) > 0) {

						String moreS = gs.substring(gs.indexOf(a[t]), gs.length());

						if (moreS.contains(matcher)) {
							String mn1 = "";
							for (int i = moreS.indexOf(matcher + ".") + matcher.length() + 1; i <= moreS.length()
									- 1; i++) {

								if (String.valueOf(moreS.charAt(i)).contentEquals("\n")) {
									break;
								} else {
									mn1 = mn1 + String.valueOf(moreS.charAt(i));
								}
							}

							ot.put(pair.getKey().toString(), mn1.toString().replace(")", ""));
						} else {

						}
					} else {

					}

				}

			}

		}

		return ot;

	}

}
