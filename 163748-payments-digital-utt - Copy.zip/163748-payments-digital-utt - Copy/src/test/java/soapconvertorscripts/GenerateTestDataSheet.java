package soapconvertorscripts;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.parser.ParseException;

import utilities.PropertiesReader;
import utilities.soapXMLParser;

public class GenerateTestDataSheet {

	List<Map<String, String>> data;
	static List<Map<String, String>> dataa;
	public static PropertiesReader pr = new PropertiesReader();
	public static Map<String, String> extraOutputPropp = new HashMap<String, String>();

	public static String workBook = pr.getUserPropValue("workBook");
	public static String excelPath = pr.getUserPropValue("excelPath");
	public static String xmlPath = pr.getUserPropValue("xmlPath");

	public static String userTestSuiteName = pr.getUserPropValue("userTestSuiteName");
	public static String userTestCaseName = pr.getUserPropValue("userTestCaseName");
	public static String usertestdatasheet = pr.getUserPropValue("usertestdatasheet");
	static String TestCase_ID = pr.getUserPropValue("primaryKey");
	public static String testStepName = "";

	public static int ActiveStepIndex;
	public static int firstActiveStepIndex;

	static Map<String, String> resultExtractor = new HashMap<String, String>();

	public static void main(String arg[]) throws ParseException, IOException {

		HeaderOf(userTestSuiteName, userTestCaseName, xmlPath);

	}

	public static void HeaderOf(String TestSuiteName, String TestCaseName, String xmlPath)
			throws IOException, ParseException {

		Map<String, String> propTcase = soapXMLParser.getPropertiesTestCase(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Map<String, String> propTcsuite = soapXMLParser.getPropertiesTestSuite(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet(userTestCaseName);
		Iterator<Entry<String, String>> Tcaseprop = propTcase.entrySet().iterator();
		while (Tcaseprop.hasNext()) {

			Row header = sheet.createRow(0);
			for (int i = 0; i < propTcase.size(); i++) {
				Map.Entry TCasepair = Tcaseprop.next();
				String key = TCasepair.getKey().toString();
				Cell cell = header.createCell(i);
				cell.setCellValue(key);
			}

		}
		Map<String, String> propTcaseval = soapXMLParser.getPropertiesTestCase(TestSuiteName, userTestCaseName,
				testStepName, xmlPath);
		Iterator<Entry<String, String>> Tcasepropval = propTcaseval.entrySet().iterator();
		int rowNum = 1;
		while (Tcasepropval.hasNext()) {

			Row row = sheet.createRow(rowNum++);
			for (int i = 0; i < propTcaseval.size(); i++) {
				Map.Entry TCasepair = Tcasepropval.next();
				row.createCell(i).setCellValue(TCasepair.getValue().toString());
			}

		}

		FileOutputStream file = new FileOutputStream("output\\" + TestSuiteName + "_TestData.xlsx");
		workbook.write(file);
		file.close();
		System.out.println("Data Written to Excel");

	}

}
