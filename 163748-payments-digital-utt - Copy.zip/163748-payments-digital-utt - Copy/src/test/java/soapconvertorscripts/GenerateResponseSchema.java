package soapconvertorscripts;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import utilities.JsonSchemaWriter;
import utilities.PropertiesReader;

public class GenerateResponseSchema {

	public static void main(String args[]) throws IllegalArgumentException, IOException, ParseException {

		PropertiesReader pr = new PropertiesReader();

		String pat = "input";
		String patc = pr.getUserPropValue("jsontoschemaname");

		File Log_path = new File(pat);

		File DestFile = new File(Log_path.getAbsolutePath() + "/" + patc);

		String TestCase_payload = "";

		JSONParser parser = new JSONParser();

		try (FileReader reader = new FileReader(DestFile)) {

			Object obj = parser.parse(reader);

			TestCase_payload = obj.toString();
		} catch (FileNotFoundException e) {

		}

		System.out.println(TestCase_payload);

		String jsonSchema = JsonSchemaWriter.getJsonSchema(TestCase_payload);

		System.out.println(jsonSchema);

	}
}
