package com.citi.dataDriven;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CommomReadFunction {

	public static String xlsPath = "";

	public static String returnPreviousFolderOfProjectDirectory(String fileName) {

		Path path = null;
		try {

			path = Paths.get(CommomReadFunction.class.getResource("..").toURI());
			
			
			
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		//String value1 = path.getParent().getParent().getParent().getParent().getParent().toString();
		String value1 = path.getParent().getParent().getParent().getParent().toString();
		
		System.out.println(value1 + fileName);  
		return value1 + fileName;
		
		
  
	}

	public static void main(String[] args) {
		xlsPath = returnPreviousFolderOfProjectDirectory("/Data_table.XLSX");

	}
	
	
	
}