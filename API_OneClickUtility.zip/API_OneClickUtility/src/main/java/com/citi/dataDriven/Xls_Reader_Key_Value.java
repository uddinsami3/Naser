package com.citi.dataDriven;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Xls_Reader_Key_Value {

	public static String returnPreviousFolderOfProjectDirectory(String fileName) {
		Path path = null;
		try {
			path = Paths.get(CommomReadFunction.class.getResource("..").toURI());
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		String value1 = path.getParent().getParent().getParent().getParent().getParent().getParent().toString();
		return value1 + fileName;

	}

}
