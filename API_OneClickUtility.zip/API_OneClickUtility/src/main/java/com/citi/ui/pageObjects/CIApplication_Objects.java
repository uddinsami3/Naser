package com.citi.ui.pageObjects;

import java.sql.Driver;
import java.sql.DriverAction;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

//import utils.SeleniumDriver;

public class CIApplication_Objects {
	//private WebDriver driver;

		public static final By UserID =By.id("USER_ID");
		public static final By Password = By.id("PASSWORD");
		public static final By drp = By.xpath("//*[contains(@name,'LV')]");
		//@FindBy(xpath="//*[contains(@name,'btnSubmit')]")public WebElement btnSubmit;

		
		public static final By btnSubmit = By.xpath("//*[contains(@name,'btnSubmit')]");
		public static final By CI_Acct_Opening_Dropdown = By.cssSelector("div#extrasysmenutable button");
		//public static final By CI_Acct_Opening_Dropdown = By.xpath("//button[@class='btn btn-primary dropdown-toggle']");
		//public static final By CI_Acct_Opening_Link = By.xpath("//*[contains(@name,'Acct. Opening')]");
		//public static final By CI_Acct_Opening_Link = By.cssSelector("a[name='Acct. Opening']");
		//public static final By CI_Acct_Opening_Link = By.cssSelector("a[name='Acct. Opening']");
		public static final By CI_Acct_Opening_Link = By.name("Acct. Opening");
		public static final By CI_Dropdown = By.xpath("//*[text()='CI']");
		//public static final By Continue_page3 = By.id("continue");
		//Driving licence related code
		//public static final By issueState = By.id("issueState");
		//public static final By Id_Num = By.id("idNum");
		public static final By CI_WorkQueue_Link = By.xpath("(//*[text()='Work Queues'])[1]");
		public static final By CI_WorkQueue_Access_Link = By.xpath("//*[contains(@name,'Work Queue Access')]");
		public static final By URN_drp = By.xpath("//*[@class='clsWCCInputSelectNoUppercase']");
		public static final By CI_ApplicationID_Dropdown = By.id("selGlobalFilter");	
		public static final By MainMenu_Arrow = By.xpath("//div[@id='extrasysmenutable']/button");
	   public static final By CI_ApplicationID_TextBox = By.id("txtGloalFilter");
		
		@FindBy(id="txtGloalFilter")public WebElement CI_ApplicationID_TextBox1;
		
		//@FindBy(name="btnGlobalFilter")
		//public WebElement CI_ApplicationID_Serch_Button;
		
		//Application Summary
		public static final By CI_ApplicationID_Serch_Button = By.name("btnGlobalFilter");
		public static final By CI_ibtn_refresh = By.id("ibtn_refresh");
		public static final By CI_btnInstinctErrorSkip = By.id("btnInstinctErrorSkip");
		public static final By CI_next_btn = By.id("btnXpressNext");
		public static final By CI_proceed_btn = By.id("btnProceed");
		public static final By CI_income = By.id("tIncomeVerification");
		public static final By CI_GrossSalaryIncometext = By.id("vluDecGrossSalaryIncome");
		public static final By CI_GrossSalaryIncome = By.id("curVerGrossSalaryIncome");
		public static final By CI_save_Button = By.id("btnAISave");
		public static final By CI_btnAIProceed = By.id("btnAIProceed");	
		public static final By CI_btnSimulate = By.id("btnSimulate");
		public static final By CI_doc_List_UAT= By.id("btnDocCheckList");
		public static final By CI_btnSaveProof= By.id("btnSaveProof");
		public static final By CI_btnClose= By.id("btnClose");
		public static final By CI_btnFinalSubmit= By.id("btnFinalSubmit");
		public static final By CI_radApproveAll= By.id("radApproveAll");
		
		
		public static final By CI_ApplicationSummary_pos = By.id("lblProcessingPosVal");
		public static final By CI_Product_Interest_Owner = By.xpath("//*[contains(@name,'colOwner')]");
		public static final By CI_Product_Interest_Category = By.xpath("//*[contains(@name,'colProdCategory')]");
		public static final By colProdCategory = By.xpath("//*[contains(@name,'colProdType')]");
		//public static final By Continue_page3 = By.id("continue");
		//Driving licence related code
		//public static final By issueState = By.id("issueState");
		//public static final By Id_Num = By.id("idNum");
		//Application Summary
		public static final By CI_btn_skip = By.id("btnSkip");
		public static final By CI_Desired_credit_limit = By.xpath("//*[contains(@name,'colFreshMoney')]");
		public static final By CI_next = By.id("btnXpressNext");
		//throgh citiphone enquiry
		public static final By CI_Citiphone_Enquiry = By.xpath("(//*[text()='Citiphone Enquiry'])[1]");
		public static final By CI_Citiphone_Enquiry_Access = By.xpath("//*[contains(@name,'Citiphone Enquiry')]");
		public static final By URNId = By.id("URNId");
		public static final By CI_Application_ID = By.xpath("//*[contains(@name,'applicationID')]");
		public static final By CI_search_BtnURN = By.id("searchBtn");
		public static final By CI_App_ID_Link = By.xpath("//*[contains(@name,'lblApplicationID')]");
		public static final By radApproveAll_Radio = By.id("radApproveAll");
		public static final By Submit = By.id("btnSubmit");
		public static final By doc_List_UAT = By.id("btnDocCheckList");
		
	//@FindBy(id="ErrorPopup']") 
	//public WebElement CI_Alert_Close_Button;
	//Demographics Details 
		public static final By CI_DemoGraphic_prefix = By.id("selPrefix");
		public static final By CI_DemoGraphic_Lastname = By.id("txtLastName");
		public static final By CI_DemoGraphic_Sex = By.id("selSex");
		public static final By CI_DemoGraphic_DateOfBirth = By.id("DateofBirth");
		public static final By CI_DemoGraphic_FirstName = By.id("txtFirstName");
		public static final By CI_DemoGraphic_Permanent_Address = By.id("selPR");
		public static final By CI_DemoGraphic_Nationality = By.id("selNationality");
		public static final By CI_DemoGraphic_Residence_Ownership = By.id("selResidenceOwnerShip");
		public static final By CI_Email_Address = By.id("txtEmailAddress1");
		
	//-------End
		
		
	//PF Declaration
		public static final By CI_PF_Declaration = By.id("selPFDeclaration");
		public static final By Doc_Check_List = By.id("btnXpressDocCheckList");
		public static final By Save_btn1 = By.id("btnSaveProof");
		
		
		
	//dynamically doing image upload
		/*
		 * @FindBy(
		 * xpath="//td[contains(text(),'PASSPORT VISA PAGE')]/following-sibling::td[2]/select"
		 * ) public WebElement List_Passport_Visa_Page;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'FRONT AND BACK PAGE')]/following-sibling::td[2]/select"
		 * ) public WebElement Front_Back_PageOf_DriverLicense;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'CURRENT AUSTRALIAN DEFENCE')]/following-sibling::td[2]/select"
		 * ) public WebElement Current_Aus_Defence_Force_Photo_ID;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'LETTER OF EMPLOYMENT')]/following-sibling::td[2]/select"
		 * ) public WebElement Letter_Of_Employment;
		 * 
		 * @FindBy(xpath="//td[contains(.,'PAYSLIP')]/following-sibling::td[2]/select")
		 * public WebElement PaySlip;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'MEDICARE CARD')]/following-sibling::td[2]/select")
		 * public WebElement MEDICARE_CARD;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Biz tax return less')]/following-sibling::td[2]/select"
		 * ) public WebElement Company_Biz_return_tax;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Australian Passport')]/following-sibling::td[2]/select"
		 * ) public WebElement Australian_Passport;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Council Rate Notice')]/following-sibling::td[2]/select"
		 * ) public WebElement Council_rate_notice;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Letter from Centrelink')]/following-sibling::td[2]/select"
		 * ) public WebElement Letter_From_Gov_Per_pe;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Credit Card Statement')]/following-sibling::td[2]/select"
		 * ) public WebElement Credit_Card;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Centrelink statement confirming')]/following-sibling::td[2]/select"
		 * ) public WebElement Centralic_Confirming_Address;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Notice of assessment')]/following-sibling::td[2]/select"
		 * ) public WebElement Notice_Of_Assesment;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Individual Tax Return')]/following-sibling::td[2]/select"
		 * ) public WebElement Individual_Tax_return;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Bank Statement with Address')]/following-sibling::td[2]/select"
		 * ) public WebElement Bank_Statement_With_Address;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Utility bills latest')]/following-sibling::td[2]/select"
		 * ) public WebElement Utility_Bills_Latest3;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Telephone Bill last')]/following-sibling::td[2]/select"
		 * ) public WebElement Telephone_Bill_Last3;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'PROOF OF IDENTITY')]/following-sibling::td[2]/select"
		 * ) public WebElement Proof_Of_Identity;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Annual superannuation statement')]/following-sibling::td[2]/select"
		 * ) public WebElement Annual_Superannuation_Statement;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Payslip with Address')]/following-sibling::td[2]/select"
		 * ) public WebElement Payslip_With_Address;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'3 months personal bank statemenets')]/following-sibling::td[2]/select"
		 * ) public WebElement Three_Months_Personal_Bank_Statemenets_INC;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'EMPLOYMENT CONTRACT LETTER')]/following-sibling::td[2]/select"
		 * ) public WebElement EMPLOYMENT_CONTRACT_LETTER_INC;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Payslip - INC')]/following-sibling::td[2]/select")
		 * public WebElement Payslip_INC;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Letter Of Employment')]/following-sibling::td[2]/select"
		 * ) public WebElement Letter_Of_Employment_INC;
		 * 
		 * @FindBy(
		 * xpath="//td[contains(.,'Tenancy Agreement')]/following-sibling::td[2]/select"
		 * ) public WebElement Tenancy_Agreement_Address_ADDR;
		 * 
		 * @FindBy(xpath=
		 * "//td[contains(.,'INCOME/EMPLOYMENT')]/following-sibling::td[2]/select")
		 * public WebElement INCOME_EMPLOYMENT;
		 * 
		 * @FindBy(id="btnSaveProof") public WebElement Save_btn;
		 */
	
	
	/*
	 * @FindBy(xpath="id='tSupervisorEnquiry") public WebElement
	 * CI_tSupervisorEnquiry;
	 * 
	 * @FindBy(xpath="id='errorPopup") public WebElement CI_ErrorPopUpId;
	 */
	/*
	 * @FindBy(xpath="//input[@onclick='closeErrorPopup(true);']") public WebElement
	 * CI_Alert_Close_Button;
	 */ 
		/*
		 * @FindBy(xpath="//a[@onclick='closeErrorPopup(true);']") public WebElement
		 * CI_Alert_Cancel_Button;
		 * 
		 */

	/*
	 * @FindBy(xpath="//*[@id='selGlobalFilter']") public WebElement
	 * CI_ApplicationID_Dropdown;
	 * 
	 * 
	 * @FindBy(xpath="//*[@id='txtGloalFilter']") public WebElement
	 * CI_ApplicationID_TextBox;
	 * 
	 * @FindBy(xpath="//*[@name='btnGlobalFilter']") public WebElement
	 * CI_ApplicationID_OK_Button;
	 */
	
	}
