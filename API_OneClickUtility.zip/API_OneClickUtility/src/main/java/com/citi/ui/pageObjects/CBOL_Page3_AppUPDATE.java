package com.citi.ui.pageObjects;

import org.openqa.selenium.By;

public class CBOL_Page3_AppUPDATE {
	public static final By Country_Of_CitizenShip =By.id("nationalityautoComplete");
	public static final By Mother_Maiden = By.xpath("//*[contains(@name,'motherName')]");
	public static final By Dob = By.xpath("//*[contains(@name,'dob')]");
	public static final By Medicare = By.id("medicareLabel");
	public static final By Medicare_Number = By.id("medicareNumber");
	public static final By Position_ref_Number = By.id("referenceNumber");
	public static final By Middle_Name = By.id("middleNameOnCard");
	//public static final By Continue_page3 = By.id("continue");
	//Driving licence related code
	//public static final By issueState = By.id("issueState");
	//public static final By Id_Num = By.id("idNum");
	public static final By Id_Card_Color = By.xpath("//*[contains(@name,'idCardColor')]");
	public static final By Medicare_ExpiryDate = By.xpath("//*[contains(@name,'medicareExpiryDateGreen')]");
	public static final By Residencial_Status = By.xpath("//*[contains(@name,'residencialStatus')]");
	public static final By predictive_Address_Search = By.xpath("//*[contains(@name,'predictiveAddressSearch')]");	
	public static final By predictive_Address_Search_0 = By.xpath("//*[@id='dr-item-predictiveAddressSearch-0']/a");
	public static final By continue_page3 = By.xpath("//*[contains(@name,'continue')]");
	
	
	

}
