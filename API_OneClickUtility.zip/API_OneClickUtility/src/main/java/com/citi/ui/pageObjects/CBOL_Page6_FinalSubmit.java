package com.citi.ui.pageObjects;

import org.openqa.selenium.By;

public class CBOL_Page6_FinalSubmit {
	
	public static final By Income_Document = By.xpath("//*[contains(@name,'PRIMARY_APPLICANT_incomeDocument')]");
	public static final By Residential_Address = By.xpath("//*[contains(@name,'PRIMARY_APPLICANT_residentialAddress')]");
	public static final By Employment_Document = By.xpath("//*[contains(@name,'PRIMARY_APPLICANT_employmentDocument')]");
	public static final By continue_Page6 = By.xpath("//*[contains(@name,'continue')]");
	
	
}
