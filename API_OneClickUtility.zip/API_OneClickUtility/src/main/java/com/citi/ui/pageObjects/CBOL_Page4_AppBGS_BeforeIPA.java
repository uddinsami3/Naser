package com.citi.ui.pageObjects;

import org.openqa.selenium.By;

public class CBOL_Page4_AppBGS_BeforeIPA {
	
	public static final By Employment_Status =By.id("employmentStatus");
	public static final By Employment_Status_List =By.id("employmentStatus-list-option-1");
	public static final By Company_Name = By.xpath("//*[contains(@name,'companyName')]");
	public static final By Occupation = By.xpath("//*[contains(@name,'occupation')]");
	public static final By Occupation_List = By.id("occupation-list-option-1");
	public static final By Office_Years = By.xpath("//*[contains(@name,'officeYears')]");
	public static final By Annual_Income = By.xpath("//*[contains(@name,'annualIncome')]");
	public static final By Other_Income = By.id("incomeChkBox_N");
	public static final By No_Of_Dependencies = By.id("dpndntsdummyChkBox_3");
	public static final By Month_Expenses = By.xpath("//*[contains(@name,'monthExpenses')]");
	public static final By Other_Expenses = By.xpath("//*[contains(@name,'recurringMonthlyExpenses')]");
	public static final By Other_CreditCard = By.id("otherCCCheck_N");
	public static final By Financial_Status = By.id("finStatus_N");
	public static final By Existing_Loan = By.id("loanOption_N");
	//public static final By Mortage = By.xpath("//*[contains(@name,'loanOption')]");
	//public static final By monthlyRepayments = By.xpath("//*[contains(@name,'monthlyRepayments')]");
	//public static final By balanceOwing = By.xpath("//*[contains(@name,'balanceOwing')]");

	
	
	
	
	
	
	
	public static final By Continue_page4 = By.xpath("//*[contains(@name,'continue')]");
	
	
	
}
