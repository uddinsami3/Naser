package com.citi.ui.pageObjects;

import org.openqa.selenium.By;

public class CBOL_Page5_OfferAcceptance_BeforeFS {
	public static final By Amount_Transfer =By.id("amountTransfer");
	public static final By BSB = By.xpath("//*[contains(@name,'branchNumber')]");
	public static final By Account_Number = By.xpath("//*[contains(@name,'accountNumber')]");
	public static final By Account_Name = By.xpath("//*[contains(@name,'accountName')]");
	public static final By continue_Page5 = By.xpath("//*[contains(@name,'continue')]");
	
	
	
	
	
}
