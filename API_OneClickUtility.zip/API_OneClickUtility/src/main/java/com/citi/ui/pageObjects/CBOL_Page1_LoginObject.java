package com.citi.ui.pageObjects;

import org.openqa.selenium.By;

public class CBOL_Page1_LoginObject {

	public static final By Slider_EditPencil_Icon = By.xpath("//*[contains(@class,'sliderEditPencilIcon')]");
	public static final By Principal_Amount = By.id("principalAmount");
	public static final By Saveicon = By.xpath("//*[contains(@class,'editSaveicon')]");
	public static final By Repay = By.xpath("//ul[@class='tenorRange']//li[5]");
	public static final By Loan_Amount = By.xpath("//*[@id='fixedloancalculatorSubmit']/div[3]/div[2]/span");
	public static final By Submit = By.id("continue");
	
	
}
