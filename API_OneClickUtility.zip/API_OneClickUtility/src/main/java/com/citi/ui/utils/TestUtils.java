package com.citi.ui.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.citi.Automation.capabilities.DesiredCap;
import io.cucumber.java.Scenario;

public class TestUtils {
	public static final long WAIT = 10;

	InputStream stringsis = null;


	public HashMap<String, String> parseStringXML() throws Exception {
		String xmlFileName = "strings/strings.xml";
		stringsis = getClass().getClassLoader().getResourceAsStream(xmlFileName);

		HashMap<String, String> stringMap = new HashMap<String, String>();
		// Get Document Builder
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();

		// Build Document
		Document document = builder.parse(stringsis);

		// Normalize the XML Structure; It's just too important !!
		document.getDocumentElement().normalize();

		// Here comes the root node
		Element root = document.getDocumentElement();

		// Get all elements
		NodeList nList = document.getElementsByTagName("string");

		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node node = nList.item(temp);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) node;
				// Store each element key value in map
				//stringMap.put(eElement.getAttribute("name"), eElement.getTextContent());
			}
		}
		return stringMap;
	}

	public static void softassert(By ciDemographicPrefix, String expected) {
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(ciDemographicPrefix, expected);

	}

	/*
	 * public String dateTime() { DateFormat dateFormat = new
	 * SimpleDateFormat("yyyy-MM-dd-HH-mm-ss"); Date date = new Date(); return
	 * dateFormat.format(date); }
	 * 
	 * public void log(String txt) { BaseTest base = new BaseTest(); String msg =
	 * Thread.currentThread().getId() + ":" + base.getPlatform() + ":" +
	 * base.getDeviceName() + ":" +
	 * Thread.currentThread().getStackTrace()[2].getClassName() + ":" + txt;
	 * 
	 * System.out.println(msg);
	 * 
	 * String strFile = "logs" + File.separator + base.getPlatform() + "_" +
	 * base.getDeviceName() + File.separator + base.getDateTime();
	 * 
	 * File logFile = new File(strFile);
	 * 
	 * if (!logFile.exists()) { logFile.mkdirs(); }
	 * 
	 * FileWriter fileWriter = null; try { fileWriter = new FileWriter(logFile +
	 * File.separator + "log.txt",true); } catch (IOException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } PrintWriter printWriter =
	 * new PrintWriter(fileWriter); printWriter.println(msg); printWriter.close(); }
	 */
	public static Logger log() {
		return LogManager.getLogger(Thread.currentThread().getStackTrace());
	}

	public static void takeScreenShotAfterEveryStep(Scenario message) throws InterruptedException {
		TakesScreenshot ts = (TakesScreenshot) DesiredCap.webdriver;
		byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
		message.attach(screenshot, "image/png", "");
	}

	public static void allPossibleCombinationsCheck(By... elements) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(DesiredCap.webdriver, 10000);

		List<By> by = new ArrayList<>();
		System.out.print(elements);

		for (By element : elements) {

			by.add(element);

			for (By s : by) {

				/// To check Element to loaded into DOM:
				// you can reuse this one
				System.out.println(s);
				WebElement elem = DesiredCap.webdriver.findElement(s);
				wait.until(ExpectedConditions.visibilityOf(elem));
				System.out.println(s);

				// To check Element Present:
				if (DesiredCap.webdriver.findElement(s) != null) {
					System.out.println("Element is Present");
					Assert.assertTrue(true);

				} else {
					System.out.println("Element is Absent");
					Assert.assertTrue(false);
				}
				// To check Visible:

				if (DesiredCap.webdriver.findElement(s).isDisplayed()) {
					System.out.println("Element is Visible");
					Assert.assertTrue(true);
				} else {
					System.out.println("Element is InVisible");
					Assert.assertTrue(false);
				}
				// To check Enable:

				if (DesiredCap.webdriver.findElement(s).isEnabled()) {
					System.out.println("Element is Enable");
					Assert.assertTrue(true);
				} else {
					System.out.println("Element is Disabled");
					Assert.assertTrue(false);
				}
			}
		}

	}

	public static void textConCheck(By... elements) throws InterruptedException {
		DesiredCap.webdriver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		List<By> by = new ArrayList<>();
		System.out.print(elements);

		for (By element : elements) {

			by.add(element);

			for (By s : by) {

				System.out.println(s);
				if (DesiredCap.webdriver.getPageSource().contains("s")) {
					System.out.println("Text is present");
					Assert.assertTrue(true);
				} else {
					System.out.println("Text is absent");
					Assert.assertTrue(false);
				}

			}

		}

	}

	public static String htmltable;

	public static void htmltable(String FieldName, Object ActualValue, String ExpectedValue, boolean condition) {

		if (condition) {
			htmltable = "<html>" + "<body>" + " <table border ='1'>" + "<tr>" + "<th>FieldName</th>"
					+ "<th>ActualValue</th>" + "<th>ExpectedValue</th> " + "</tr> ";

		} else {
			htmltable = htmltable + "<tr>" + "<td>" + FieldName + "</td>" + "<td>" + ActualValue + "</td> " + "<td>"
					+ ExpectedValue + "</td> " + "</tr> ";

		}

	}

	public static void htmlwrite(Scenario scenario) {

		String htmltablewrite = htmltable + "</table>" + "</body>" + "</html>";

		scenario.log(htmltablewrite);

	}

	
	  public static void screenShot() throws IOException, InterruptedException {
		  
		  
		  TakesScreenshot screenshot = (TakesScreenshot) DesiredCap.getdriver();
		  
		  File source = screenshot.getScreenshotAs(OutputType.FILE);

		  File Destination= new File("D\\Sample.png");
		  
		  FileHandler.copy(source, Destination); 
	 }
	 
		
		/*
		 * public static String getText(Object ObjectLocator) throws
		 * InterruptedException {
		 * 
		 * Thread.sleep(50000);
		 * 
		 * String text= ((WebElement) ObjectLocator).getText(); return text; }
		 */
		 
	  
	  public void selectDropDownVal(WebElement findElement, String string) {
			// TODO Auto-generated method stub
			Select selectDrp=new Select(findElement);
			 List<WebElement> listDropDown= selectDrp.getOptions();
			 //System.out.println("size"+listDropDown.size());
			 for(WebElement selVal:listDropDown) {			
				 if(selVal.getText().equals(string)) {
					 selVal.click();
					 break;
				 }
			 }
		}

	  public static void screenShotwithRobot() throws IOException {
	  
	  }
}
