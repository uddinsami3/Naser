package com.citi.ui.pageObjects;

import org.openqa.selenium.By;

public class CBOL_Page2_AppADD {
	public static final By Title = By.id("title_MR");
	public static final By First_Name = By.id("firstName");
	public static final By Middle_Name = By.id("middleName");
	public static final By Sur_Name = By.id("lastName");
	public static final By Phone_Number = By.id("phoneNumber");
	public static final By Email = By.id("email");
	public static final By continue_page2 = By.id("continue");
	
	
	
	
	
	
}
