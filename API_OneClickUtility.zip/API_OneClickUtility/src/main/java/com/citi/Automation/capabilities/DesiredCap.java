package com.citi.Automation.capabilities;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.internal.ElementScrollBehavior;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

import com.citi.dataDriven.CommomReadFunction;
import com.citi.dataDriven.Xls_Reader;
import com.citi.mobileAutomation.autoInvoking.OpeningAppiumServer;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class DesiredCap {
	public static AppiumDriver driver;
	public static WebDriver webdriver;
	private static AppiumServiceBuilder builder;

	protected static AppiumDriverLocalService service;
	
	protected static Properties props;
	static InputStream ins;
    
	public static void intializeAndroid() throws InterruptedException, IOException {
		
		props= new Properties();
		String proFileName="config.properties";//if ur class and package is same root location
		//ins= getClass().getClassLoader().getResourceAsStream(proFileName);

		Xls_Reader.readPreReqMethod();
		System.out.println("" + Xls_Reader.deviceName + "");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", "" + Xls_Reader.deviceName + "");
		capabilities.setCapability(CapabilityType.VERSION, "" + Xls_Reader.platformVersion + "");
		capabilities.setCapability("platformName", "" + Xls_Reader.platformName + "");
		capabilities.setCapability("appPackage", "" + Xls_Reader.appPackage + "");
		capabilities.setCapability("autoGrantPermissions", true);
		// capabilities.setCapability("noReset", false);
		capabilities.setCapability("appActivity", "" + Xls_Reader.appActivity + "");
		// capabilities.setCapability("chromedriverExecutable","/Users/apple/Downloads/chromedriver
		// 2");
		driver = new AppiumDriver(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
		System.out.println("Connected");

	}

	public static void initilizeiOS() throws MalformedURLException {
		
		Xls_Reader.readPreReqMethod();
		
		//OpeningAppiumServer.startAppiumServerSimple();
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "" + Xls_Reader.deviceNameIOS + "");
		caps.setCapability("platformVersion", "" + Xls_Reader.platformVersionIOS + "");
		caps.setCapability("platformName", "" + Xls_Reader.platformNameIOS + "");
		caps.setCapability("bundleId", "" + Xls_Reader.bundleID + "");
		caps.setCapability("skipUnlock", "true");
		caps.setCapability("newCommandTimeout", 60 * 50);
		caps.setCapability("autoAcceptAlerts", true);
		// caps.setCapability("app", "/Users/apple/Downloads/TWA.app");
		driver = new IOSDriver(new URL("http://0.0.0.0:4723/wd/hub"), caps);

	}
	

@SuppressWarnings("deprecation")
public static WebDriver initilizeSeleniiumtemp(String url) {
	
	Xls_Reader.readPreReqMethod();
	
	//String Browser= Xls_Reader.browser_mode;
	 String Browser="ie";
	
	if (System.getProperty("os.name").toLowerCase().contains(OS.WINDOW.name().toLowerCase()))
	{
		
		switch (Browser) {
		case "chrome":
			
			
			/*
			 * chromeOpt.addArguments("ignore-certificate-errors");
			 * chromeOpt.setExperimentalOption("useAutomationExtension", false);
			 * chromeOpt.addArguments("--disable-extensions");
			 * chromeOpt.addArguments("disable-notifications");
			 */
			System.setProperty("webdriver.ie.driver", "src/test/resources/Drivers/IEDriverServer.exe");
			//System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Selenium Client\\Selenium drivers\\chromedriver.exe");
			//System.setProperty("webdriver.chrome.driver", "src/test/resources/GUI/driver/chromedriver.exe");
			 //System.setProperty("webdriver.chrome.driver", " C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome_proxy.exe");
			ChromeOptions chromeOpt = new ChromeOptions(); 
			chromeOpt.setExperimentalOption("useAutomationExtension", false);
			webdriver = new ChromeDriver(chromeOpt);
			break;

		case "chrome_headless":
			System.setProperty("webdriver.chrome.driver", "src/main/resources/com/citi/mobileAutomation/Drivers/chromedriver.exe");
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--headless");
			chromeOptions.addArguments("--disable-gpu");
			webdriver = new ChromeDriver(chromeOptions);
			break;

		case "firefox":
			System.setProperty("webdriver.gecko.driver", "src/main/resources/com/citi/mobileAutomation/Drivers/geckodriver.exe");
			webdriver = new FirefoxDriver();
			break;

		case "ie":
		case "internet explorer":
			
			
			
			
DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
	        
	        cap.setCapability("requireWindowFocus", true);
	        cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			//cap.setCapability(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR,ElementScrollBehavior.BOTTOM);
			//cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			cap.setJavascriptEnabled(true);
			InternetExplorerOptions ieoptions = new InternetExplorerOptions();
			ieoptions.merge(cap); 
			//System.setProperty("webdriver.ie.driver", "src/test/resources/Drivers/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", "C:\\Program Files (x86)\\Selenium Client\\Selenium drivers\\IE drivers\\IEDriverServer.exe");
			webdriver = new InternetExplorerDriver(ieoptions);
			break;
		default:
			throw new NotFoundException("Browser Not Found. Please Provide a Valid Browser");
		}
	}
	else if (System.getProperty("os.name").toLowerCase().contains(OS.MAC.name().toLowerCase()))
	{
	switch (Browser) {
	case "chrome":
		System.setProperty("webdriver.chrome.driver", CommomReadFunction.returnPreviousFolderOfProjectDirectory("/chromedrivermac"));
		webdriver = new ChromeDriver();
		break;

	case "chrome_headless":
		System.setProperty("webdriver.chrome.driver", "src/main/resources/com/citi/mobileAutomation/Drivers/chromedriver.exe");
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--headless");
		chromeOptions.addArguments("--disable-gpu");
		webdriver = new ChromeDriver(chromeOptions);
		break;

	case "firefox":
		System.setProperty("webdriver.gecko.driver", "src/main/resources/com/citi/mobileAutomation/Drivers/geckodriver.exe");
		webdriver = new FirefoxDriver();
		break;

	case "safari":
		webdriver = new SafariDriver();
		break;


	default:
		throw new NotFoundException("Browser Not Found. Please Provide a Valid Browser");
	}

	}
	
	webdriver.get(url);
	webdriver.manage().window().maximize();
	if( Xls_Reader.browser_mode.equalsIgnoreCase("internet explorer")||Xls_Reader.browser_mode.equalsIgnoreCase("ie"))
	{
	webdriver.navigate().to("javascript:document.getElementById('overridelink').click()");   
	}
	return webdriver; 
} 
public static WebDriver initilizeSeleniium(String url) throws InterruptedException {
	
	
			
			
DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
	        
	        cap.setCapability("requireWindowFocus", true);
	        cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			//cap.setCapability(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR,ElementScrollBehavior.BOTTOM);
			//cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			cap.setJavascriptEnabled(true);
			InternetExplorerOptions ieoptions = new InternetExplorerOptions();
			ieoptions.merge(cap); 
			
			//System.setProperty("webdriver.ie.driver", "src/test/resources/Drivers/IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", "C:\\Users\\pg60914\\AppData\\Local\\IEDriverServer_Win32\\IEDriverServer.exe");
			
			 webdriver=null;
			int countRetry = 0;
			int maxRetryCount=3;

			while(webdriver==null && countRetry<maxRetryCount)
			{
				try{
					webdriver = new InternetExplorerDriver(ieoptions);
					//ChromeDriver(options);	                        
				}
				catch(Exception e){
					countRetry = countRetry + 1;	                             
					if(countRetry==maxRetryCount){
						throw new WebDriverException(e.getMessage());
					}
					else {
						System.out.println("Retrying " + countRetry  + " more times to create driver instances..");
					}

				}
			}
		
			

	
	webdriver.get(url);
Thread.sleep(3000);
	webdriver.manage().window().maximize();
	Thread.sleep(3000);
	if( Xls_Reader.browser_mode.equalsIgnoreCase("internet explorer")||Xls_Reader.browser_mode.equalsIgnoreCase("ie"))
	{
	webdriver.navigate().to("javascript:document.getElementById('overridelink').click()");   
	Thread.sleep(3000);
	}
	return webdriver;
	
} 

public static WebDriver getdriver() throws InterruptedException
{
	Thread.sleep(3000);
	return driver;
	
}


	public static void main(String[] args) throws InterruptedException, IOException {

		initilizeiOS();
	}
}
