package com.citi.Automation.capabilities;

public enum OS {
	
	WINDOW,
	MAC

}
