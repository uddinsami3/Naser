package com.citi.Automation.otp;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

	public class Elixr {

		public static void main(String[] args) throws Exception {
			getOTP();
		}

		public static void getOTP() throws Exception {
			Map<String, Object> param = new HashMap<String, Object>();
	
			String url = "http://elixir.nam.nsroot.net/otpLog?phone=" + "5826" + "&environment=" + "UAT2"
					+ "-Linux&application=CBOL&country=" + "SGGCB";

			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			String result = response.toString();
			System.out.println("hi");
			char otp;

			for (int i = 0; i <= result.length() - 1; i++) {
				Thread.sleep(5000);
				Thread.sleep(5000);
				otp = result.charAt(i);
				String a = Character.toString(otp);

				System.out.println(otp);

				param.put("label", a);
				param.put("match", "last");
				// DeviceUtils.getQAFDriver().executeScript("mobile:button-text:click", param);
				Thread.sleep(6000);
			}
		}
	}


