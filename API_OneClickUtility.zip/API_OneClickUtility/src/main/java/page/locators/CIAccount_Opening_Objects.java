package page.locators;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class CIAccount_Opening_Objects {
	private WebDriver driver;
	
	@FindBy(id="USER_ID")
	public WebElement UserID;
	
	@FindBy(id="PASSWORD")
	public WebElement Password;
	
	@FindBy(name="LV")
	public WebElement drp;
	
	@FindBy(name="btnSubmit")
	public WebElement btnsub;
	
	@FindBy(xpath="//button[@class='btn btn-primary dropdown-toggle']")
	public WebElement CI_Acct_Opening_Dropdown;

	@FindBy(xpath="//*[@name='Acct. Opening']")
	public WebElement CI_Acct_Opening_Link;
	
	//@FindBy(xpath="//*[@name='Acct. Opening']")
	//public WebElement CI_Acct_Opening_Link;
	//esms
	@FindBy(xpath="//*[text()='Search Request']")
	public WebElement ESMS_Search;
	
	
	@FindBy(name="Search Request")
	public WebElement ESMS_Search_click;
	
	
	@FindBy(name="URN")
	public WebElement URN_seach;
	
	@FindBy(xpath="//*[text()='Done']")
	public WebElement Done;
	
	@FindBy(xpath="//*[@id='myGrid']/DIV[5]/DIV/DIV[1]/DIV[3]")
	public WebElement ESMS_Cardupgrade_urnStatus1;
	
	
	@FindBy(xpath="//*[text()='CI']")
	public WebElement CI_Dropdown;

	@FindBy(xpath="(//*[text()='Work Queues'])")
	public WebElement CI_WorkQueue_Link;  

	@FindBy(name="Work Queue Access")
	public WebElement CI_WorkQueue_Access_Link;
	
	@FindBy(id="ErrorPopup']") 
	public WebElement CI_Alert_Close_Button;
	
	@FindBy(xpath="//*[@class='clsWCCInputSelectNoUppercase']")
	public WebElement URN_drp;
	
	@FindBy(id="selGlobalFilter")
	public WebElement CI_ApplicationID_Dropdown;

	@FindBy(xpath="//div[@id='extrasysmenutable']/button")
	public WebElement MainMenu_Arrow;

	@FindBy(id="txtGloalFilter")
	public WebElement CI_ApplicationID_TextBox;

	@FindBy(name="btnGlobalFilter")
	public WebElement CI_ApplicationID_Serch_Button;
	//Application Summary
	
	@FindBy(id="lblProcessingPosVal")
	public WebElement CI_ApplicationSummary_pos;
	//product interest customer choice
	
	@FindBy(name="colOwner")
	public WebElement CI_Product_Interest_Owner;
	
	@FindBy(name="colProdCategory")
	public WebElement CI_Product_Interest_Category;
	
	@FindBy(name="colProdType")
	public WebElement CI_Product_Interest_Product_Type;
	
	@FindBy(id="btnSkip")
	public WebElement CI_btn_skip;
	
	@FindBy(name="colFreshMoney")
	public WebElement CI_Desired_credit_limit;
	
	@FindBy(id="btnXpressNext")
	public WebElement CI_next;
	
	@FindBy(xpath="(//*[text()='Citiphone Enquiry'])")
	public WebElement CI_Citiphone_Enquiry;  

	@FindBy(name="Citiphone Enquiry")
	public WebElement CI_Citiphone_Enquiry_Access;
	
	@FindBy(name="applicationID")
	public WebElement CI_Application_ID;
	
	@FindBy(name="searchBtn")
	public WebElement CI_search_Btn;
	
	@FindBy(name="lblApplicationID")
	public WebElement CI_App_ID_Link;
	
	@FindBy(id="radApproveAll")
	public WebElement radApproveAll_Radio;
	
	@FindBy(id="btnSubmit")
	public WebElement Submit;
	
	@FindBy(id="btnDocCheckList")
	public WebElement doc_List_UAT;
	
	
	//income flow
	@FindBy(id="tIncomeVerification")
	public WebElement Income;
	
	
	@FindBy(id="curVerGrossSalaryIncome")
	public WebElement Gross_Salary_Income;
	//COMPLETED
	//@FindBy(name="selAtVerStatus")
	//public WebElement Verification_Status;
	//PASS & REVIEW
	//@FindBy(name="selAtOutcome")
	//public WebElement Outcome;
	
	//@FindBy(name="delt")
	//public WebElement Check_Box;
	
	@FindBy(id="btnAISave")
	public WebElement save_Button;
	
	@FindBy(id="btnAIProceed")
	public WebElement proceed_Button;
	
	@FindBy(id="btnSimulate")
	public WebElement simulate_button;
	
	@FindBy(id="btnFinalSubmit")
	public WebElement final_submit;

	
	
	
	//Demographics Details 
	
	
	@FindBy(id="selPrefix")
	public WebElement CI_DemoGraphic_prefix;
	
	@FindBy(id="txtLastName")
	public WebElement CI_DemoGraphic_Lastname;
	
	@FindBy(id="selSex")
	public WebElement CI_DemoGraphic_Sex;
	
	@FindBy(id="DateofBirth")
	public WebElement CI_DemoGraphic_DateOfBirth;
	
	@FindBy(id="txtFirstName")
	public WebElement CI_DemoGraphic_FirstName;
	
	@FindBy(id="selPR")
	public WebElement CI_DemoGraphic_Permanent_Address;
	
	@FindBy(id="selNationality")
	public WebElement CI_DemoGraphic_Nationality;
	
	@FindBy(id="selResidenceOwnerShip")
	public WebElement CI_DemoGraphic_Residence_Ownership;
	
	@FindBy(id="txtEmailAddress1")
	public WebElement CI_Email_Address;
	
	
	//-------End
	
	//PF Declaration
	
	@FindBy(id="selPFDeclaration")
	public WebElement CI_PF_Declaration;
	//DocCheckList
	@FindBy(id="btnXpressDocCheckList")
	public WebElement Doc_Check_List;
	
	@FindBy(xpath="//td[contains(text(),'PASSPORT VISA PAGE')]/following-sibling::td[2]/select")
	public WebElement List_Passport_Visa_Page;	
	
	@FindBy(xpath="//td[contains(.,'FRONT AND BACK PAGE')]/following-sibling::td[2]/select")
	public WebElement Front_Back_PageOf_DriverLicense;
	
	@FindBy(xpath="//td[contains(.,'CURRENT AUSTRALIAN DEFENCE')]/following-sibling::td[2]/select")
	public WebElement Current_Aus_Defence_Force_Photo_ID;
	
	@FindBy(xpath="//td[contains(.,'LETTER OF EMPLOYMENT')]/following-sibling::td[2]/select")
	public WebElement Letter_Of_Employment;
	
	@FindBy(xpath="//td[contains(.,'PAYSLIP')]/following-sibling::td[2]/select")
	public WebElement PaySlip;
	
	@FindBy(xpath="//td[contains(.,'MEDICARE CARD')]/following-sibling::td[2]/select")
	public WebElement MEDICARE_CARD;
	
	@FindBy(xpath="//td[contains(.,'Biz tax return less')]/following-sibling::td[2]/select")
	public WebElement Company_Biz_return_tax;
	
	@FindBy(xpath="//td[contains(.,'Australian Passport')]/following-sibling::td[2]/select")
	public WebElement Australian_Passport;
	
	@FindBy(xpath="//td[contains(.,'Council Rate Notice')]/following-sibling::td[2]/select")
	public WebElement Council_rate_notice;
	
	@FindBy(xpath="//td[contains(.,'Letter from Centrelink')]/following-sibling::td[2]/select")
	public WebElement Letter_From_Gov_Per_pe;
	
	@FindBy(xpath="//td[contains(.,'Credit Card Statement')]/following-sibling::td[2]/select")
	public WebElement Credit_Card;
	
	@FindBy(xpath="//td[contains(.,'Centrelink statement confirming')]/following-sibling::td[2]/select")
	public WebElement Centralic_Confirming_Address;
	
	@FindBy(xpath="//td[contains(.,'Notice of assessment')]/following-sibling::td[2]/select")
	public WebElement Notice_Of_Assesment;
	
	@FindBy(xpath="//td[contains(.,'Individual Tax Return')]/following-sibling::td[2]/select")
	public WebElement Individual_Tax_return;
	
	@FindBy(xpath="//td[contains(.,'Bank Statement with Address')]/following-sibling::td[2]/select")
	public WebElement Bank_Statement_With_Address;
	
	@FindBy(xpath="//td[contains(.,'Utility bills latest')]/following-sibling::td[2]/select")
	public WebElement Utility_Bills_Latest3;
	
	@FindBy(xpath="//td[contains(.,'Telephone Bill last')]/following-sibling::td[2]/select")
	public WebElement Telephone_Bill_Last3;
	
	@FindBy(xpath="//td[contains(.,'PROOF OF IDENTITY')]/following-sibling::td[2]/select")
	public WebElement Proof_Of_Identity;
	
	@FindBy(xpath="//td[contains(.,'Annual superannuation statement')]/following-sibling::td[2]/select")
	public WebElement Annual_Superannuation_Statement;
	
	@FindBy(xpath="//td[contains(.,'Payslip with Address')]/following-sibling::td[2]/select")
	public WebElement Payslip_With_Address;
	
	@FindBy(xpath="//td[contains(.,'3 months personal bank statemenets')]/following-sibling::td[2]/select")
	public WebElement Three_Months_Personal_Bank_Statemenets_INC;
	
	@FindBy(xpath="//td[contains(.,'EMPLOYMENT CONTRACT LETTER')]/following-sibling::td[2]/select")
	public WebElement EMPLOYMENT_CONTRACT_LETTER_INC;
	
	@FindBy(xpath="//td[contains(.,'Payslip - INC')]/following-sibling::td[2]/select")
	public WebElement Payslip_INC;
	
	@FindBy(xpath="//td[contains(.,'Letter Of Employment')]/following-sibling::td[2]/select")
	public WebElement Letter_Of_Employment_INC;
	
	@FindBy(xpath="//td[contains(.,'Tenancy Agreement')]/following-sibling::td[2]/select")
	public WebElement Tenancy_Agreement_Address_ADDR;
	
	@FindBy(xpath="//td[contains(.,'INCOME/EMPLOYMENT')]/following-sibling::td[2]/select")
	public WebElement INCOME_EMPLOYMENT;
	
	@FindBy(id="btnSaveProof")
	public WebElement Save_btn;
	
	@FindBy(id="btnClose")
	public WebElement close_btn;
	@FindBy(id="btnProceed")
	public WebElement proceed_btn;
	
	@FindBy(id="btnXpressNext")
	public WebElement next_btn;
	
	
	@FindBy(id="ibtn_refresh")
	public WebElement refresh_btn;
	
	
	
	
	/*
	 * @FindBy(xpath="id='tSupervisorEnquiry") public WebElement
	 * CI_tSupervisorEnquiry;
	 * 
	 * @FindBy(xpath="id='errorPopup") public WebElement CI_ErrorPopUpId;
	 */
	/*
	 * @FindBy(xpath="//input[@onclick='closeErrorPopup(true);']") public WebElement
	 * CI_Alert_Close_Button;
	 */ 
	  @FindBy(xpath="//a[@onclick='closeErrorPopup(true);']")
	  public WebElement CI_Alert_Cancel_Button;
	 


	/*
	 * @FindBy(xpath="//*[@id='selGlobalFilter']") public WebElement
	 * CI_ApplicationID_Dropdown;
	 * 
	 * 
	 * @FindBy(xpath="//*[@id='txtGloalFilter']") public WebElement
	 * CI_ApplicationID_TextBox;
	 * 
	 * @FindBy(xpath="//*[@name='btnGlobalFilter']") public WebElement
	 * CI_ApplicationID_OK_Button;
	 */
	
	public CIAccount_Opening_Objects(WebDriver driver) {
		 
	        this.driver = driver;
		        PageFactory.initElements(driver, this);
}
}