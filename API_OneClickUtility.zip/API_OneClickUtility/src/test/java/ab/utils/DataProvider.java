package ab.utils;



import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import ab.common.TestConfiguration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.NumberToTextConverter;

public class DataProvider {

    static Fillo fillo=new Fillo();
    static Connection connection;
    
    
    public static void writeExcelData(String testCaseID, String sheetName, String objectkey,String objectvalue,String Workbook) throws FilloException, IOException, InterruptedException
    {
    	
    	connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");

    	String strQuery="Update "+sheetName+" Set "+ objectkey+"='" +objectvalue +"' where TestCaseID='" +testCaseID +"' ";
    	
    	Thread.sleep(1000);
    	
    	connection.executeUpdate(strQuery);
    	Thread.sleep(1000);
    	connection.close();
    		
    }
    public static void writeExcelData(String testCaseID, String sheetName, String objectkey,int objectvalue,String Workbook) throws FilloException, IOException, InterruptedException
    {
    	
    	connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");

    	String strQuery="Update "+sheetName+" Set "+ objectkey+"='" +objectvalue +"' where TestCaseID='" +testCaseID +"' ";
    	
    	
    	Thread.sleep(1000);
    	connection.executeUpdate(strQuery);
    	Thread.sleep(1000);
    	connection.close();
    		
    }
	
    public static HashMap<String, Object> extractExceldata(String testCaseId, String sheetName, String Workbook) throws FilloException {
    	
    	
    	
   
        HashMap<String,Object> excelMap= new HashMap<String, Object>();

       connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");
        
         //connection=fillo.getConnection("src/test/testData/Book.xlsx");
       
      String strQuery="Select * from "+sheetName+" where TestCaseID='" +testCaseId +"'and Status='YES'";
      Recordset recordset=connection.executeQuery(strQuery);
    
      while(recordset.next()) {
          ArrayList<String> ColCollection = recordset.getFieldNames();
          int size = ColCollection.size();
          for (int Iter = 0; Iter <= (size - 1); Iter++) {
              String ColName = ColCollection.get(Iter);
              String ColValue = recordset.getField(ColName);
              excelMap.put(ColName, ColValue);
              
          }
      }
          recordset.close();
          connection.close();

          return excelMap;
    }

public static HashMap<String, Object> ReadTestCases(String testCaseId, String Workbook) throws FilloException {
    	
    	
    	
    	
        HashMap<String,Object> excelMap= new HashMap<String, Object>();

       connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");
        
         //connection=fillo.getConnection("src/test/testData/Book.xlsx");
       
      String strQuery="Select * from Sheet3 where TCName='" +testCaseId +"'";
      Recordset recordset=connection.executeQuery(strQuery);
    
      while(recordset.next()) {
          ArrayList<String> ColCollection = recordset.getFieldNames();
          int size = ColCollection.size();
          for (int Iter = 0; Iter <= (size - 1); Iter++) {
              String ColName = ColCollection.get(Iter);
              String ColValue = recordset.getField(ColName);
              excelMap.put(ColName, ColValue);
              
          }
      }
          recordset.close();
          connection.close();

          return excelMap;
    }

public static HashMap<String, Object> ReadTestCasesUsingAPIName(String APIName, String TestCaseName) throws FilloException {
	
	
	
	
    HashMap<String,Object> excelMap= new HashMap<String, Object>();
   // connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/APITestData - Copy.xlsx");
    // connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/APITestData - Copy.xlsx");
    connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");

   //connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");
    
    //String strQuery="Select * from "+sheetName+" where TestCaseID='" +testCaseId +"'and Status='YES'";
   
  String strQuery="Select * from Sheet1 where API='" +APIName +"' and TCName='"+TestCaseName+"'";
  Recordset recordset=connection.executeQuery(strQuery);
 
  while(recordset.next()) {
      ArrayList<String> ColCollection = recordset.getFieldNames();
      int size = ColCollection.size();
      for (int Iter = 0; Iter <= (size - 1); Iter++) {
          String ColName = ColCollection.get(Iter);
          String ColValue = recordset.getField(ColName);
          excelMap.put(ColName, ColValue);
          
      }
  }
      recordset.close();
      connection.close();

      return excelMap;
}
   public static HashMap<String, Object> extractExceldataoverride(String testCaseId) throws FilloException {
    	
    	
    	
        HashMap<String,Object> excelMap= new HashMap<String, Object>();

       connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/ProductDirectory.xlsx");
        // connection=fillo.getConnection(System.getProperty("user.dir")+"/metadata/Metadata.xls");
       
      String strQuery="Select * from Sheet1 where TestCaseName='" +testCaseId +"'";
       //String strQuery="Select * from Sheet1";
      Recordset recordset=connection.executeQuery(strQuery);
      
      while(recordset.next()) {
          ArrayList<String> ColCollection = recordset.getFieldNames();
          int size = ColCollection.size();
          for (int Iter = 0; Iter <= (size - 1); Iter++) {
              String ColName = ColCollection.get(Iter);
              String ColValue = recordset.getField(ColName);
              excelMap.put(ColName, ColValue);
          }
      }
      
          recordset.close();
          connection.close();

          return excelMap;
    }

   public static HashMap<String, Object> Metadataextract(String testCaseId) throws FilloException {
   	
   	
  
       HashMap<String,Object> excelMap= new HashMap<String, Object>();

      //connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/ProductDirectory.xlsx");
       connection=fillo.getConnection(System.getProperty("user.dir")+"/metadata/Metadata.xls");
      
     String strQuery="Select * from MetaData where Business_Element_name='" +testCaseId +"'";
     
      //String strQuery="Select * from Sheet1";
     Recordset recordset=connection.executeQuery(strQuery);
    
     while(recordset.next()) {
         ArrayList<String> ColCollection = recordset.getFieldNames();
         int size = ColCollection.size();
         for (int Iter = 0; Iter <= (size - 1); Iter++) {
             String ColName = ColCollection.get(Iter);
             String ColValue = recordset.getField(ColName);
             excelMap.put(ColName, ColValue);
         }
     }
     
         recordset.close();
         connection.close();

         return excelMap;
   }

   
   public static List<Map<String, String>> GetAPIDataFromExcel(String sheetName, String Workbook) throws FilloException {

	System.setProperty("ROW",String.valueOf(TestConfiguration.setCurrentRow));
	
 
       List<Map<String, String>> excelMap = new ArrayList<Map<String, String>>();
      connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");
        //connection=fillo.getConnection("src/test/testData/Book.xlsx");
      
     String strQuery="Select * from "+sheetName+"";
     Recordset recordset=connection.executeQuery(strQuery);
    
     while(recordset.next()) {
         ArrayList<String> ColCollection = recordset.getFieldNames();
         int size = ColCollection.size();
         
               
         for (int currentRow = TestConfiguration.setCurrentRow; currentRow <= TestConfiguration.setCurrentRow; currentRow++) {
         for (int Iter = 0; Iter <= (size - 1); Iter++) {
             String ColName = ColCollection.get(Iter);
             String ColValue = recordset.getField(ColName);
             LinkedHashMap<String, String> columnMapdata = new LinkedHashMap<String, String>();
             columnMapdata.put(ColName, ColValue);
             columnMapdata.remove("TestCaseID");
             if(columnMapdata.containsValue("")) {
           	 columnMapdata.remove(ColName);
           	 
             }

             
             excelMap.add(columnMapdata);            
             //excelMap.removeAll(Arrays.asList("",null));
             

         }
         }
         break;
      
     }

         recordset.close();
         connection.close();

         return excelMap;
   }

   public static void writeExcelDataOverride(String testCaseID, String objectkey,String objectvalue) throws FilloException, IOException, InterruptedException
   {
   	
   	connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/ProductDirectory.xlsx");

   	String strQuery="Update Sheet1 Set "+ objectkey+"='" +objectvalue +"' where TestCaseName='" +testCaseID +"' ";
   	
   	
   	Thread.sleep(1000);
   	connection.executeUpdate(strQuery);
   	Thread.sleep(1000);
   	connection.close();
   		
   }
   public static void WriteDataToExcel(String ApiName, String objectkey,String objectvalue, String TestCaseName) throws FilloException, IOException, InterruptedException
   {
   	
   //	connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/APITestData - Copy.xlsx");
       connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");

   	//String strQuery="Update Sheet3 Set "+ objectkey+"='" +objectvalue +"' where API='" +ApiName +"' and TCName='"+TestCaseName+"'";
       String strQuery="Update Sheet1 Set "+ objectkey+"='" +objectvalue +"' where API='" +ApiName +"' and TCName='"+TestCaseName+"'";


       Thread.sleep(1000);
   	connection.executeUpdate(strQuery);
   	Thread.sleep(1000);
   	connection.close();
   		
   }
   public List<Map<String, String>> getData(String excelFilePath, String sheetName)
           throws InvalidFormatException, IOException {
       Sheet sheet = getSheetByName(excelFilePath, sheetName);
   return readSheet(sheet);
}

public List<Map<String, String>> getData(String excelFilePath, int sheetNumber)
       throws InvalidFormatException, IOException {
   Sheet sheet = getSheetByIndex(excelFilePath, sheetNumber);
   return readSheet(sheet);
}

private Sheet getSheetByName(String excelFilePath, String sheetName) throws IOException, InvalidFormatException {
   Sheet sheet = getWorkBook(excelFilePath).getSheet(sheetName);
   return sheet;
}

private Sheet getSheetByIndex(String excelFilePath, int sheetNumber) throws IOException, InvalidFormatException {
   Sheet sheet = getWorkBook(excelFilePath).getSheetAt(sheetNumber);
   return sheet;
}

private Workbook getWorkBook(String excelFilePath) throws IOException, InvalidFormatException {
   return WorkbookFactory.create(new File(excelFilePath));
}

private List<Map<String, String>> readSheet(Sheet sheet) {
   Row row;
  // int totalRow = sheet.getPhysicalNumberOfRows();
   List<Map<String, String>> excelRows = new ArrayList<Map<String, String>>();
   int headerRowNumber = getHeaderRowNumber(sheet);
   if (headerRowNumber != -1) {
       int totalColumn = sheet.getRow(headerRowNumber).getLastCellNum();
       
       for (int currentRow = TestConfiguration.setCurrentRow; currentRow <= TestConfiguration.setCurrentRow; currentRow++) {
           row = getRow(sheet, sheet.getFirstRowNum() + currentRow);
           LinkedHashMap<String, String> columnMapdata = new LinkedHashMap<String, String>();
           for (int currentColumn = 0; currentColumn < totalColumn; currentColumn++) {
               columnMapdata.putAll(getCellValue(sheet, row, currentColumn));
           }
           
           excelRows.add(columnMapdata);
           
       }
   }
   return excelRows;
}


private int getHeaderRowNumber(Sheet sheet) {
   Row row;   
   int totalRow = sheet.getLastRowNum();
   for (int currentRow = 0; currentRow <= totalRow + 1; currentRow++) {
       row = getRow(sheet, currentRow);
       if (row != null) {
           int totalColumn = row.getLastCellNum();
           for (int currentColumn = 0; currentColumn < totalColumn; currentColumn++) {
               Cell cell;
               cell = row.getCell(currentColumn, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
               if (cell.getCellTypeEnum() == CellType.STRING) {
                   return row.getRowNum();

               }
               else if (cell.getCellTypeEnum() == CellType.NUMERIC) {
                   return row.getRowNum();

               } else if (cell.getCellTypeEnum() == CellType.BOOLEAN) {
                   return row.getRowNum();
               } else if (cell.getCellTypeEnum() == CellType.ERROR) {
                   return row.getRowNum();
               }
           }
       }
   }
   return (-1);
}

private Row getRow(Sheet sheet, int rowNumber) {
   return sheet.getRow(rowNumber);
}

private LinkedHashMap<String, String> getCellValue(Sheet sheet, Row row, int currentColumn) {
   LinkedHashMap<String, String> columnMapdata = new LinkedHashMap<String, String>();
   Cell cell;
   if (row == null) {
       if (sheet.getRow(sheet.getFirstRowNum()).getCell(currentColumn, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
               .getCellTypeEnum() != CellType.BLANK) {
           String columnHeaderName = sheet.getRow(sheet.getFirstRowNum()).getCell(currentColumn)
                   .getStringCellValue();
           columnMapdata.put(columnHeaderName, "");
       }
   } else {
       cell = row.getCell(currentColumn, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
       if (cell.getCellTypeEnum() == CellType.STRING) {
           if (sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex(), Row.MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum() != CellType.BLANK) {
               String columnHeaderName = sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex()).getStringCellValue();
               columnMapdata.put(columnHeaderName, cell.getStringCellValue());
           }
       } else if (cell.getCellTypeEnum() == CellType.NUMERIC) {
           if (sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex(), Row.MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum() != CellType.BLANK) {
               String columnHeaderName = sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex()).getStringCellValue();
               columnMapdata.put(columnHeaderName, NumberToTextConverter.toText(cell.getNumericCellValue()));
           }
       } else if (cell.getCellTypeEnum() == CellType.BLANK) {
           if (sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex(), Row.MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum() != CellType.BLANK) {
               String columnHeaderName = sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex()).getStringCellValue();
               columnMapdata.put(columnHeaderName, "");
           }
       } else if (cell.getCellTypeEnum() == CellType.BOOLEAN) {
           if (sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex(), Row.MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum() != CellType.BLANK) {
               String columnHeaderName = sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex()).getStringCellValue();
               columnMapdata.put(columnHeaderName, Boolean.toString(cell.getBooleanCellValue()));
           }
       } else if (cell.getCellTypeEnum() == CellType.ERROR) {
           if (sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex(), Row.MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum() != CellType.BLANK) {
               String columnHeaderName = sheet.getRow(sheet.getFirstRowNum()).getCell(cell.getColumnIndex()).getStringCellValue();
               columnMapdata.put(columnHeaderName, Byte.toString(cell.getErrorCellValue()));
           }
       }
   }
   return columnMapdata;
}

}
