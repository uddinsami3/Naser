package ab.utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;

public class VoyagerResponseValidation {

   private static String accessToken;
   private static String accountId;

    public static String getAccessToken() {
        return "Bearer "+accessToken ;

    }
   public static String getAccountId()
   {
       return  accountId;
   }

    public static void voyagerResponeData(JSONObject responsebody, String apiName, Map<String,Object> getdata)
    {

       if(apiName.equals("Voyager2legAuthorization"))
       {


             accessToken= responsebody.getString("access_token");
            
       }
       if(apiName.equals("Autherization2Leg"))
       {


             accessToken= responsebody.getString("access_token");

       }

       if(apiName.equals("VoyagerAccountSummary"))
       {


           JSONArray accountSummaryjsonArray= responsebody.getJSONArray("accountGroupSummary");



           for (int i=0;i<accountSummaryjsonArray.length();i++)
           {

             if(accountSummaryjsonArray.getJSONObject(i).get("accountGroup").equals(getdata.get("accountGroup")) )
             {

                 JSONArray accounts=accountSummaryjsonArray.getJSONObject(i).getJSONArray("accounts");

                 for(int j=0;j<accounts.length();j++)
                 {
                   JSONObject accountSummary= accounts.getJSONObject(j).getJSONObject(String.valueOf(getdata.get("AccountSummary")));

                     {

                         if (accountSummary.get("displayAccountNumber").equals(getdata.get("displayAccountNumber"))) {

                             accountId = accountSummary.getString("accountId");

                         }
                     }
                 }
             }


           }

       }



    }
}
