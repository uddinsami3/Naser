package ab.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import io.cucumber.java.Scenario;



public class TestUtils {
                public static final long WAIT = 10;

                InputStream stringsis = null;
                public static Scenario message;

                public HashMap<String, String> parseStringXML() throws Exception {
                                String xmlFileName = "strings/strings.xml";
                                stringsis = getClass().getClassLoader().getResourceAsStream(xmlFileName);

                                HashMap<String, String> stringMap = new HashMap<String, String>();
                                // Get Document Builder
                                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                                DocumentBuilder builder = factory.newDocumentBuilder();

                                // Build Document
                                Document document = builder.parse(stringsis);

                                // Normalize the XML Structure; It's just too important !!
                                document.getDocumentElement().normalize();

                                // Here comes the root node
                                Element root = document.getDocumentElement();

                                // Get all elements
                                NodeList nList = document.getElementsByTagName("string");

                                for (int temp = 0; temp < nList.getLength(); temp++) {
                                                Node node = nList.item(temp);
                                                if (node.getNodeType() == Node.ELEMENT_NODE) {
                                                                Element eElement = (Element) node;
                                                                // Store each element key value in map
                                                               // stringMap.put(eElement.getAttribute("name"), eElement.getTextContent());
                                                }
                                }
                                return stringMap;
                }

                public static void softassert(String actual, String expected) {
                                SoftAssert sa = new SoftAssert();
                                sa.assertEquals(actual, expected);

                }

               
                

                

               // public static String htmltable;
                public static void softassert(String fieldName, Object actual,String expected) {
                	
                	
                    SoftAssert sa = new SoftAssert();
                    
                    boolean condition=actual.equals(expected);
                    
                        if(condition)
                        {
                        	
                        	sa.assertEquals(actual, expected);
                        	htmltable(fieldName,actual,expected,"PASS",false);
                        	
                        }
                        else
                        {
                        	
                        	sa.assertEquals(actual, expected);
                        	
                        	htmltable(fieldName,actual,expected,"FAIL",false);	
                        }
                        sa.assertAll();
                    
                    
					

    }
    
    

    
   
    

    

    public static String htmltable;

    public static void htmltable(String FieldName, Object ActualValue, String ExpectedValue, String Status,boolean condition) {
    	 htmltable = "<html>" + "<body>" + " <table border ='1'>" + "<tr>";
                    if (condition) {
                                   
                    	htmltable = htmltable + "<tr>" + "<th>"+FieldName+"</th>"
                                                                    
                    + "<th>"+ActualValue+"</th>" 
                    + "<th>"+ExpectedValue+"</th> " 
                    + "<th>Status</th> " 
                    + "</tr> ";

                    } else {
                    	
                    	if(Status.equals("FAIL")) {
                    		
                    		htmltable = htmltable + "<tr>" + "<td>" + FieldName + "</td>" + "<td>" + ActualValue + "</td> " + "<td>"
                					+ ExpectedValue + "</td> "+"<td bgcolor=\"red\">" +  Status + "</td> "+ "</tr> ";

                    	}
                    	else
                    	{
                    		
                    
                    	htmltable = htmltable + "<tr>" + "<td>" + FieldName + "</td>" + "<td>" + ActualValue + "</td> " + "<td>"
            					+ ExpectedValue + "</td> "+"<td>" +  Status + "</td> "+ "</tr> ";
                    	}
                    }

    }

    public static void htmlwrite(Scenario scenario) {

                    String htmltablewrite = htmltable + "</table>" + "</body>" + "</html>";

                    scenario.log(htmltablewrite);
                    scenario.attach(htmltablewrite.getBytes(), "text/html","");

    }


//                public static void htmltable(String FieldName, Object ActualValue, String ExpectedValue, boolean condition) {
//
//                                if (condition) {
//                                                htmltable = "<html>" + "<body>" + " <table border ='1'>" + "<tr>" + "<th>FieldName</th>"
//                                                                                + "<th>ActualValue</th>" + "<th>ExpectedValue</th> " + "</tr> ";
//
//                                } else {
//                                                htmltable = htmltable + "<tr>" + "<td>" + FieldName + "</td>" + "<td>" + ActualValue + "</td> " + "<td>"
//                                                                                + ExpectedValue + "</td> " + "</tr> ";
//
//                                }
//
//                }
//
//                public static void htmlwrite(Scenario scenario) {
//
//                                String htmltablewrite = htmltable + "</table>" + "</body>" + "</html>";
//
//                                scenario.write(htmltablewrite);
//
//                }
                
    public  Properties readProperties(String PropertyFileName) throws FileNotFoundException
	{
		File source=new File(("src/test/resources/APOLLO_CI/"+PropertyFileName+".properties"));
		FileInputStream fis=new FileInputStream(source);
		Properties properties=new Properties();
		try {
			properties.load(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	return properties;
		
	}
                 public static  String date()
                 
                 { 
                	 DateFormat dateFormat = new
                		 SimpleDateFormat("yyyy-MM-dd"); Date date = new Date(); return
                		 dateFormat.format(date); 
                		 
                 }
                  public static String Time() { DateFormat dateFormat = new
                		 SimpleDateFormat("HH-mm-ss"); Date date = new Date(); return
                		  dateFormat.format(date); }
                		 
                		 

}
