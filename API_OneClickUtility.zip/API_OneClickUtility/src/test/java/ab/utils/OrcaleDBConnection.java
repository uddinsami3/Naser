package ab.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.cucumber.java.Scenario;

public class OrcaleDBConnection {
	
	

	static Connection con;
	static Statement stmt=null;
	HashMap<String, Object> storeValue =null;
	ResultSet rs;
	
	public static  void connectDBConnection_test() throws Exception
	{		
		
		HashMap<String, Object> storeValue =null;
			boolean runFlag = true;
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@oraasmwd11-scan.nam.nsroot.net:8889:AUSHRS","CIX1","ye3sY48E");  
			stmt=con.createStatement();  
			
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
	
		//ResultSet rsappiid = stmt.executeQuery("select APPLICATION_ID,UNIV_REF_NO,THIRD_PARTY_REF_NO,PARTNER_ORG_CODE from cix1.APPLICATION_TXN where 1=1 and UNIV_REF_NO='E331YW127274'");
		//while (rsappiid.next())
			//System.out.println(rsappiid.getString("APPLICATION_ID"));
      ResultSet rs1 = stmt.executeQuery("select * from CUSTOMER_TXN where 1=1 and APPLICATION_ID='20200822000028181'");
		while (rs1.next())
		System.out.println(rs1.getString("CUST_FIRST_NM"));
		
			/* ResultSetMetaData metadata = rs1.getMetaData();
	 	 	 int columnCount = metadata.getColumnCount();
	 	 	 rs1.getRow();
			 while(rs1.next())  
				{
				  
				 storeValue = new HashMap<String, Object>(columnCount);
				  for(int i=1;i<=columnCount;i++)
				  {
					  storeValue.put(metadata.getColumnName(i), rs1.getObject(i));
					  
					  System.out.println(storeValue);
				  }
				}*/
			/*ResultSet rs1 = stmt.executeQuery("select * from OAC_PRODUCT_TXN");
			   ResultSetMetaData rsMetaData = rs1.getMetaData();
			    int numberOfColumns = rsMetaData.getColumnCount();
			    for (int i = 1; i < numberOfColumns + 1; i++) {
			        String columnName = rsMetaData.getColumnName(i);
			        // Get the name of the column's table name
			        String tableName = rsMetaData.getTableName(i);
			        System.out.println("column name=" + columnName + " table=" + tableName + "");
			      } */
//			while (rs1.next())
//				System.out.println(rs1);	
			
			//con.commit();
			if (runFlag) {
				//step4 execute query  
				ResultSet rs=stmt.executeQuery(""
						+ "select APPLICATION_ID,MODULE,KEY_FIELD_2,TRANSACTION_ID,PROCESSNAME,STATE,OPERATION, REQUESTPAYLOAD, RESPONSEPAYLOAD,STARTTIMESTAMP,ENDTIMESTAMP from cix1.CP_APP_PROCESS_ERR "
						+ "where 1=1 "
						+ "and APPLICATION_ID='20200823000028194'"
						+ "and OPERATION in ('CI_APPUPD','OAC_APPUPD','OAC_BGS','OAC_IPA_REQ', 'OAC_IPA_RES','OAC_FS_REQ','OAC_APPINQ','OAC_APPADD') "
						+ "order by STARTTIMESTAMP"
						+ "");  
				
				
				while(rs.next()) {
					System.out.println(rs.getString("APPLICATION_ID"));
					System.out.println(rs.getString("OPERATION"));
					System.out.println(rs.getString("REQUESTPAYLOAD"));
					System.out.println(rs.getString("RESPONSEPAYLOAD"));
//					System.out.println(rs.getString("APPLICATION_ID"));
					
				}
				
			}
			  

			
			

			  
			//step5 close the connection object  
			con.close(); 
//			you need to try cache and close the object of db connection
//			otherwisem, will occupy all connneciotn of db in ST2
			
			
	
}
	
	
		
		

		public HashMap<String, Object> connectDBConnection(String sqlQuery ,String wherecondition,Scenario scenario) throws Exception
		{		
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@oraasmwd11-scan.nam.nsroot.net:8889:AUSHRS","CIX1","ye3sY48E");  
			//stmt=con.createStatement();  
			
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			
			
				if(sqlQuery.contains("cix1.APPLICATION_TXN"))
				{
				  rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");  
				  scenario.log(sqlQuery+wherecondition);
				  
				}
				else
				{
					
					rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
					scenario.log(sqlQuery+wherecondition);
				}
				 ResultSetMetaData metadata = rs.getMetaData();
		 	 	 int columnCount = metadata.getColumnCount();
		 	 	 rs.getRow();
		 	 
				 while(rs.next())  
					{
					  
					 storeValue = new HashMap<String, Object>(columnCount);
					
					  for(int i=1;i<=columnCount;i++)
					  {
						  storeValue.put(metadata.getColumnName(i), rs.getObject(i));
					  }
					}
				 
				 return storeValue;
					
				
		
	}
		public  ArrayList<String> getResult(String sqlQuery ,String wherecondition,String column,Scenario scenario) throws Exception {
			
		
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@oraasmwd11-scan.nam.nsroot.net:8889:AUSHRS","CIX1","ye3sY48E");  
			
			
			//stmt=con.createStatement();  
			
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  scenario.log(sqlQuery+wherecondition);
			
			if(sqlQuery.contains("cix1.APPLICATION_TXN"))
			{
				
			  rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");  
			  scenario.log(sqlQuery+wherecondition);
			  
			}
		
			else
			{
				
				rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
				scenario.log(sqlQuery+wherecondition);
			}
			
			
			ArrayList<String> results = new ArrayList<String>();
			
		   System.out.println(results);
			//scenario.log(sqlQuery+wherecondition);
		    while (rs.next()) {
		        results.add(rs.getString(column));
		    }
		    
		    System.out.println(results);
		    return results;
		}
	
	public static void main(String[] args) throws Exception {
		Scenario scenario = null;
		// TODO Auto-generated method stub
		
		connectDBConnection_test();

	}

}
