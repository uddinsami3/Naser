package ab.utils;

import java.util.Map;

import ab.common.CommonUtility;
import io.cucumber.java.Scenario;
import io.restassured.response.Response;

public class Dbvalidation {
	
	
	public static Response response;
	public static String URN;
	
	public static void apllicationadd(Map<String, Object> getData,Response response,Scenario scenario) throws Exception
	{
		
		CommonUtility common = new CommonUtility();

		 URN=response.jsonPath().getString("ApplicationAddResponse.applicationId");
		          
		            
		            // Fetching Application ID
					//common.dbvalues("CI_APPLICATIONID","E331YW127274","",scenario);
					common.listdbvalues("CI_APPLICATIONID",CommonUtility.applicationId(), "APPLICATION_ID", scenario);
					
					
					// Fetching and validating ORG
				
				TestUtils.softassert("ORG_NO",getData.get("product.creditCardProduct.organization"),common.listdbvalues("CI_PRODUCT_TXN", "", "ORG_NO", scenario).get(0).toString());
					
					// Fetching and validating PROD_CD
					TestUtils.softassert("PROD_CD",getData.get("product.creditCardProduct.productCode"),common.listdbvalues("CI_PRODUCT_TXN", "", "PROD_CD", scenario).get(0).toString());
					
				    // Fetching and validating SOURCE_CD
					
					TestUtils.softassert("SOURCE_CD",getData.get("product.creditCardProduct.sourceCode"),common.listdbvalues("CI_PRODUCT_TXN","",  "SOURCE_CD", scenario).get(0).toString());
					
					// Fetching and validating CUST_PREFIX
					TestUtils.softassert("CUST_PREFIX",getData.get("applicant.name.salutation"),common.listdbvalues("CI_CUSTOMER_TXN","",  "CUST_PREFIX", scenario).get(0).toString());
					
					// Fetching and validating CUST_FIRST_NM
				     TestUtils.softassert("CUST_FIRST_NM",getData.get("applicant.name.givenName"),common.listdbvalues("CI_CUSTOMER_TXN","",  "CUST_FIRST_NM", scenario).get(0).toString());
				 
			     	// Fetching and validating CUST_OTHER_NM
			       //  TestUtils.softassert("CUST_OTHER_NM",getData.get("product.creditCardProduct.sourceCode"),common.dbvalues("", "CI_PRODUCT_TXN", "CI_CUSTOMER_TXN", scenario));
			    
			        // Fetching and validating CUST_LAST_NM
			 		TestUtils.softassert("CUST_LAST_NM",getData.get("applicant.name.surname"),common.listdbvalues("CI_CUSTOMER_TXN", "", "CUST_LAST_NM", scenario).get(0).toString());
			 		
			 		 // Fetching and validating PHONE_TYP
			 		TestUtils.softassert("PHONE_TYP",getData.get("applicant.phone[0].phoneType"),common.listdbvalues( "CI_CUST_PHONE_TXN","", "PHONE_TYP", scenario).get(0).toString());
			 			
			 		 // Fetching and validating PH_COUNTRY_CD
			 		TestUtils.softassert("PH_COUNTRY_CD",getData.get("applicant.phone[0].phoneCountryCode"),common.listdbvalues("CI_CUST_PHONE_TXN","",  "PH_COUNTRY_CD", scenario).get(0).toString());
			 			
			 		 // Fetching and validating PHONE_NO	
			 		TestUtils.softassert("PHONE_NO",getData.get("applicant.phone[0].phoneNumber"),common.listdbvalues("CI_CUST_PHONE_TXN","",  "PHONE_NO", scenario).get(0).toString());
			 			
			 		 // Fetching and validating EMAIL_1
			 		TestUtils.softassert("EMAIL_1",getData.get("applicant.email[0].emailAddress"),common.listdbvalues("CI_CUSTOMER_TXN","",  "EMAIL_1", scenario).get(0).toString());
			 			
			 		 // Fetching and validating PREFERRED_EMAIL_ADDR1
			 		TestUtils.softassert("PREFERRED_EMAIL_ADDR1",getData.get("applicant.email[0].isPreferredEmailAddress"),common.listdbvalues("CI_CUSTOMER_TXN","",  "PREFERRED_EMAIL_ADDR1", scenario).get(0).toString());
			 			
			 		 // Fetching and validating CONSENT_TYPE
			 		TestUtils.softassert("CONSENT_TYPE",getData.get("applicant.consentDetails[0].consentType"),common.listdbvalues ("CI_CUST_CONSENT_TXN","", "CONSENT_TYPE", scenario).get(0).toString());
			 			
			 		 // Fetching and validating CONSENT_TYPE
			 		TestUtils.softassert("CONSENT_TYPE",getData.get("applicant.consentDetails[1].consentType"),common.listdbvalues ("CI_CUST_CONSENT_TXN","", "CONSENT_TYPE", scenario).get(1).toString());
			 		
			 	// Fetching and validating CONSENT_FLAG
			 		TestUtils.softassert("CONSENT_FLAG",getData.get("applicant.consentDetails[0].isConsentGiven"),common.listdbvalues ("CI_CUST_CONSENT_TXN","", "CONSENT_FLAG", scenario).get(0).toString());	
			 		
				 	// Fetching and validating CONSENT_FLAG
				 		TestUtils.softassert("CONSENT_FLAG",getData.get("applicant.consentDetails[1].isConsentGiven"),common.listdbvalues ("CI_CUST_CONSENT_TXN","", "CONSENT_FLAG", scenario).get(1).toString());	
				 		
				 	// Fetching and validating PAY_AT_MONTH		
				 		TestUtils.softassert("PAY_AT_MONTH",getData.get("product.creditCardProduct.organization"),common.listdbvalues("CI_PRODUCT_TXN", "", "PAY_AT_MONTH", scenario).get(0).toString());	
				 	// Fetching and validating PAY_AT_MONTH	
				 		
				 		TestUtils.softassert("ANNUAL_INCOME_RANGE",getData.get("product.creditCardProduct.organization"),common.listdbvalues("CI_PRODUCT_TXN", "", "ANNUAL_INCOME_RANGE", scenario).get(0).toString());	
				 		
				 	// Fetching and validating PAY_AT_MONTH		
				 		TestUtils.softassert("PREFERRED_FEATURE1",getData.get("product.creditCardProduct.organization"),common.listdbvalues("CI_PRODUCT_TXN", "", "PREFERRED_FEATURE1", scenario).get(0).toString());	
				 		
				 	// Fetching and validating PREFERRED_FEATURE2		
				 		TestUtils.softassert("PAY_AT_MONTH",getData.get("product.creditCardProduct.organization"),common.listdbvalues("CI_PRODUCT_TXN", "", "PREFERRED_FEATURE2", scenario).get(0).toString());	
				 		
				 	 	// Fetching and validating MONTHLY_CC_SPEND_RANGE	
				 			
				 		TestUtils.softassert("MONTHLY_CC_SPEND_RANGE",getData.get("product.creditCardProduct.organization"),common.listdbvalues("CI_PRODUCT_TXN", "", "MONTHLY_CC_SPEND_RANGE", scenario).get(0).toString());
				 		
				 	// Fetching and validating ID_CARD_TYP	
			 			
				 		TestUtils.softassert("ID_CARD_TYP",getData.get("applicant.identificationDocumentDetails[0].idType"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_CARD_TYP", scenario).get(0).toString());	
				 		
		 	         // Fetching and validating ID_NO	
			 			
				 		TestUtils.softassert("ID_NO",getData.get("applicant.identificationDocumentDetails[0].idNumber"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_NO", scenario).get(0).toString());	
				 		
		               // Fetching and validating ID_CARD_TYP	
			 			
				 		TestUtils.softassert("ID_CARD_TYP",getData.get("applicant.identificationDocumentDetails[1].idType"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_CARD_TYP", scenario).get(1).toString());	
				 		
		 	         // Fetching and validating ID_NO	
			 			
				 		TestUtils.softassert("ID_NO",getData.get("applicant.identificationDocumentDetails[1].idNumber"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_NO", scenario).get(1).toString());	
		             // Fetching and validating ADDR_TYP	
			 			
				 		TestUtils.softassert("ADDR_TYP",getData.get("applicant.address[0].addressType"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "ADDR_TYP", scenario).get(0).toString());	
				 		
		               // Fetching and validating CITY	
			 			
				 		TestUtils.softassert("CITY",getData.get("applicant.address[0].cityName"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "CITY", scenario).get(0).toString());	
				 		
		               // Fetching and validating PROVINCE	
			 			
				 		TestUtils.softassert("PROVINCE",getData.get("applicant.address[0].state"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "PROVINCE", scenario).get(0).toString());	
				 		
		                // Fetching and validating ZIP_CD	
			 			
				 		TestUtils.softassert("ZIP_CD",getData.get("applicant.address[0].postalCode"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "ZIP_CD", scenario).get(0).toString());	
				 		
		              // Fetching and validating COUNTRY	
			 			
				 		TestUtils.softassert("COUNTRY",getData.get("applicant.address[0].countryCode"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "COUNTRY", scenario).get(0).toString());	
				 		
					
		
	}
	
	public static void apllicationupdate(Map<String, Object> getData,Response response,Scenario scenario) throws Exception
	{
		
		CommonUtility common = new CommonUtility();

		//String URN=response.jsonPath().getString("ApplicationAddResponse.applicationId");
		          
		            
		            // Fetching Application ID
					common.dbvalues("CI_APPLICATIONID","WDI6XH183403","",scenario);
					//common.listdbvalues("CI_APPLICATIONID",CommonUtility.applicationId(), "APPLICATION_ID", scenario);
					
					
					// Fetching and validating GENDER
				TestUtils.softassert("GENDER",getData.get("applicant.demographics.gender"),common.listdbvalues("CI_CUSTOMER_TXN", "", "SEX", scenario).get(0).toString());
				
				// Fetching and validating GENDER
				TestUtils.softassert("BIRTH_DT",getData.get("applicant.demographics.dateOfBirth"),common.listdbvalues("CI_CUSTOMER_TXN", "", "BIRTH_DT", scenario).get(0).toString());
					
				// Fetching and validating NATIONALITY
				TestUtils.softassert("NATIONALITY",getData.get("applicant.demographics.nationality"),common.listdbvalues("CI_CUSTOMER_TXN", "", "NATIONALITY", scenario).get(0).toString());
				
				// Fetching and validating ID_TYP
				TestUtils.softassert("PASSPORT",getData.get("applicant.identificationDocumentDetails[0].idType"),common.listdbvalues("CI_CUSTOMER_TXN", "", "ID_TYP", scenario).get(0).toString());
				
				// Fetching and validating ID_TYP
				TestUtils.softassert("DRIVERS_LICENCE",getData.get("applicant.identificationDocumentDetails[1].idType"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_CARD_TYP", scenario).get(0).toString());
				
				// Fetching and validating ID_TYP
				TestUtils.softassert("MEDICARE_CARD",getData.get("applicant.identificationDocumentDetails[2].idType"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_CARD_TYP", scenario).get(1).toString());
				
				
				// Fetching and validating ID_TYP
				TestUtils.softassert("PASSPORT_Number",getData.get("applicant.identificationDocumentDetails[0].idNumber"),common.listdbvalues("CI_CUSTOMER_TXN", "", "ID_NO", scenario).get(0).toString());
				
				// Fetching and validating ID_TYP
				TestUtils.softassert("DRIVERS_LICENCE_Number",getData.get("applicant.identificationDocumentDetails[1].idNumber"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_NO", scenario).get(0).toString());
				
				// Fetching and validating ID_TYP
				TestUtils.softassert("MEDICARE_CARD_Number",getData.get("applicant.identificationDocumentDetails[2].idNumber"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_NO", scenario).get(0).toString());
				
				// Fetching and validating ID_ISSUE_STATE
				//TestUtils.softassert("ID_ISSUE_STATE",getData.get("applicant.identificationDocumentDetails[1].idIssueState"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_ISSUE_STATE", scenario).get(3).toString());
					
				// Fetching and validating ID_ISSUING_CTRY
				TestUtils.softassert("ISSUING_COUNTRY",getData.get("applicant.identificationDocumentDetails[0].idIssueCountry"),common.listdbvalues("CI_CUSTOMER_TXN", "", "ID_ISSUING_CTRY", scenario).get(0).toString());
				
				// Fetching and validating ID_REMARKS
				//TestUtils.softassert("ID_REMARKS",getData.get("applicant.identificationDocumentDetails[2].middleName"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_REMARKS", scenario).get(3).toString());
				
				// Fetching and validating color
				//TestUtils.softassert("Color",getData.get("applicant.identificationDocumentDetails[2].color"),common.listdbvalues("CI_CUST_MOREID_TXN", "", "ID_PHOTO_TYP", scenario).get(3).toString());
							
		
				// Fetching and validating ADDR_TYP
				TestUtils.softassert("ADDR_TYP",getData.get("applicant.address[0].addressType"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "ADDR_TYP", scenario).get(0).toString());
				
				// Fetching and validating ADDR_LN_2
				TestUtils.softassert("ADDR_LN_2",getData.get("applicant.address[0].countrySpecificAddress.unitNumber"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "ADDR_LN_2", scenario).get(0).toString());
						
				// Fetching and validating ADDR_LN_3
				TestUtils.softassert("ADDR_LN_3",getData.get("applicant.address[0].countrySpecificAddress.streetNumber"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "ADDR_LN_3", scenario).get(0).toString());
						
				// Fetching and validating ADDR_LN_4
				TestUtils.softassert("ADDR_LN_4",getData.get("applicant.address[0].countrySpecificAddress.streetName"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "ADDR_LN_4", scenario).get(0).toString());
						
				// Fetching and validating CITY
				TestUtils.softassert("CITY",getData.get("applicant.address[0].cityName"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "CITY", scenario).get(0).toString());
						
				// Fetching and validating COUNTRY
				TestUtils.softassert("COUNTRY",getData.get("applicant.address[0].countryCode"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "COUNTRY", scenario).get(0).toString());
						
				
				// Fetching and validating ZIP_CD
				TestUtils.softassert("ZIP_CD",getData.get("applicant.address[0].postalCode"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "ZIP_CD", scenario).get(0).toString());
						
				// Fetching and validating PROVINCE
				TestUtils.softassert("PROVINCE",getData.get("applicant.address[0].state"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "PROVINCE", scenario).get(0).toString());
						
				
				// Fetching and validating STREET_TYPE
				TestUtils.softassert("STREET_TYPE",getData.get("applicant.address[0].countrySpecificAddress.streetType"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "STREET_TYPE", scenario).get(0).toString());
						
				// Fetching and validating MOTHER_MAIDEN_NM
				TestUtils.softassert("MOTHER_MAIDEN_NM",getData.get("applicant.motherMaidenName"),common.listdbvalues("CI_CUSTOMER_TXN", "", "MOTHER_MAIDEN_NM", scenario).get(0).toString());
					
				// Fetching and validating NO_OF_DEPENDENT
				TestUtils.softassert("NO_OF_DEPENDENT",getData.get("applicant.additionalData.numberOfDependents"),common.listdbvalues("CI_CUSTOMER_TXN", "", "NO_OF_DEPENDENT", scenario).get(0).toString());
				
				// Fetching and validating ID_ISSUING_CTRY
				TestUtils.softassert("RESIDENT_STATUS",getData.get("applicant.demographics.residencyStatus"),common.listdbvalues("CI_CUSTOMER_TXN", "", "RESIDENT_STATUS", scenario).get(0).toString());
				
				
				
				
				
	}
	
	public static void applicationUpdateBeforeIPA(Map<String, Object> getData,Response response,Scenario scenario) throws Exception
	{
		CommonUtility common = new CommonUtility();

		//String URN=response.jsonPath().getString("ApplicationAddResponse.applicationId");
		          
		            
		            // Fetching Application ID
					//common.dbvalues("CI_APPLICATIONID","VT35R9025910","",scenario);
					common.listdbvalues("CI_APPLICATIONID",CommonUtility.applicationId(), "APPLICATION_ID", scenario);
					
					
				// Fetching and validating INCOME_TYPE
				TestUtils.softassert("INCOME_TYPE",getData.get("applicant.financialInformation.incomeDetails[0].incomeType"),common.listdbvalues("CI_CUST_INCOME_TXN", "", "INCOME_TYPE", scenario).get(0).toString());
				
				// Fetching and validating INCOME_TYPE
				TestUtils.softassert("INCOME_TYPE",getData.get("applicant.financialInformation.incomeDetails[1].incomeType"),common.listdbvalues("CI_CUST_INCOME_TXN", "", "INCOME_TYPE", scenario).get(1).toString());	
				
				// Fetching and validating FIXED_AMT
				TestUtils.softassert("FIXED_AMT",getData.get("applicant.financialInformation.incomeDetails[0].fixedAmount"),common.listdbvalues("CI_CUST_INCOME_TXN", "", "FIXED_AMT", scenario).get(0).toString());	
				
				// Fetching and validating FIXED_AMT
				TestUtils.softassert("FIXED_AMT",getData.get("applicant.financialInformation.incomeDetails[1].fixedAmount"),common.listdbvalues("CI_CUST_INCOME_TXN", "", "FIXED_AMT", scenario).get(1).toString());	
	
	
				// Fetching and validating FIXED_AMT
				TestUtils.softassert("FREQUENCY",getData.get("applicant.financialInformation.incomeDetails[0].frequency"),common.listdbvalues("CI_CUST_INCOME_TXN", "", "FREQUENCY", scenario).get(0).toString());	
	           
				
				// Fetching and validating FIXED_AMT
				TestUtils.softassert("FREQUENCY",getData.get("applicant.financialInformation.incomeDetails[1].frequency"),common.listdbvalues("CI_CUST_INCOME_TXN", "", "FREQUENCY", scenario).get(1).toString());	
	
	
					// Fetching and validating FIXED_AMT
					TestUtils.softassert("PROFESSION_CD",getData.get("applicant.employmentDetails[0].occupationCode"),common.listdbvalues("CI_CUST_EMP_TXN", "", "PROFESSION_CD", scenario).get(0).toString());	
		
					// Fetching and validating YEARS_IN_EMPLOYMENT
					TestUtils.softassert("YEARS_IN_EMPLOYMENT",getData.get("applicant.employmentDetails[0].employmentDurationInYears"),common.listdbvalues("CI_CUST_EMP_TXN", "", "YEARS_IN_EMPLOYMENT", scenario).get(0).toString());	
		
					// Fetching and validating EXPENSE_TYPE
					TestUtils.softassert("EXPENSE_TYPE",getData.get("applicant.financialInformation.expenseDetails[0].expenseType"),common.listdbvalues("CI_CUST_EXPENSE_TXN", "", "EXPENSE_TYPE", scenario).get(0).toString());	
		   
					// Fetching and validating EXPENSE_TYPE
					TestUtils.softassert("EXPENSE_TYPE",getData.get("applicant.financialInformation.expenseDetails[1].expenseType"),common.listdbvalues("CI_CUST_EXPENSE_TXN", "", "EXPENSE_TYPE", scenario).get(0).toString());
					
					// Fetching and validating EXPENSE_TYPE
					TestUtils.softassert("EXPENSE_TYPE",getData.get("applicant.financialInformation.expenseDetails[2].expenseType"),common.listdbvalues("CI_CUST_EXPENSE_TXN", "", "EXPENSE_TYPE", scenario).get(0).toString());	
	
					// Fetching and validating AMOUNT_EARNED
					TestUtils.softassert("AMOUNT_EARNED",getData.get("applicant.financialInformation.expenseDetails[0].expenseType"),common.listdbvalues("CI_CUST_EXPENSE_TXN", "", "AMOUNT_EARNED", scenario).get(0).toString());	
	
					// Fetching and validating AMOUNT_EARNED
					TestUtils.softassert("AMOUNT_EARNED",getData.get("applicant.financialInformation.expenseDetails[1].expenseType"),common.listdbvalues("CI_CUST_EXPENSE_TXN", "", "AMOUNT_EARNED", scenario).get(0).toString());	
	
					// Fetching and validating AMOUNT_EARNED
					TestUtils.softassert("SIGNIFICANT_CHANGE)",getData.get("applicant.financialInformation.hasForeseeableFinancialChanges"),common.listdbvalues("CI_CUSTOMER_TXN", "", "SIGNIFICANT_CHANGE", scenario).get(0).toString());	
	               
					// Fetching and validating LOAN_TYP
					TestUtils.softassert("LOAN_TYP)",getData.get("applicant.financialInformation.existingLoanDetails[0].loanType"),common.listdbvalues("CI_CUST_LINE_LOAN_TXN", "", "LOAN_TYP", scenario).get(0).toString());	
	
					// Fetching and validating MON_LN_LINE_CC_AMT
					TestUtils.softassert("MON_LN_LINE_CC_AMT)",getData.get("applicant.financialInformation.existingLoanDetails[0].monthlyInstallmentAmount"),common.listdbvalues("CI_CUST_LINE_LOAN_TXN", "", "MON_LN_LINE_CC_AMT", scenario).get(0).toString());	
					
						// Fetching and validating OUTSTANDING_AMT
						TestUtils.softassert("OUTSTANDING_AMT)",getData.get("applicant.financialInformation.existingLoanDetails[0].outstandingBalanceAmount"),common.listdbvalues("CI_CUST_LINE_LOAN_TXN", "", "OUTSTANDING_AMT", scenario).get(0).toString());	
						
						// Fetching and validating BILL_TO_FLG
						//TestUtils.softassert("BILL_TO_FLG)",getData.get("product.creditCardProduct.billingAddress"),common.listdbvalues("CI_CUST_ADDRESS_TXN", "", "BILL_TO_FLG", scenario).get(0).toString());	
								
						
	}
	public static void ApplicationUpdateBeforeFinal(Map<String, Object> getData,Response response,Scenario scenario) throws Exception
	{
		CommonUtility common = new CommonUtility();

		//String URN=response.jsonPath().getString("ApplicationAddResponse.applicationId");
		          
		            
		            // Fetching Application ID
					//common.dbvalues("CI_APPLICATIONID","7FB2YK038446","",scenario);
					common.listdbvalues("CI_APPLICATIONID",CommonUtility.applicationId(), "APPLICATION_ID", scenario);
					
					
				// Fetching and validating BILL_CD
				TestUtils.softassert("BILL_CD",getData.get("product.creditCardProduct.balanceTransferDetails[0].billerCode"),common.listdbvalues("CI_Product_BT_Txn", "", "BILL_CD", scenario).get(0).toString());
				
				// Fetching and validating account_no
				TestUtils.softassert("account_no",getData.get("product.creditCardProduct.balanceTransferDetails[0].accountReferenceNumber"),common.listdbvalues("CI_Product_BT_Txn", "", "account_no", scenario).get(0).toString());
				
			
				// Fetching and validating BT_AMT
				TestUtils.softassert("BT_AMT",getData.get("product.creditCardProduct.balanceTransferDetails[0].amountToTransfer"),common.listdbvalues("CI_Product_BT_Txn", "", "BT_AMT", scenario).get(0).toString());
				
				// Fetching and validating Account_name
				TestUtils.softassert("Account_name",getData.get("product.creditCardProduct.balanceTransferDetails[0].accountName"),common.listdbvalues("CI_Product_BT_Txn", "", "Account_name", scenario).get(0).toString());
				

				// Fetching and validating campaign_CD
				TestUtils.softassert("campaign_CD",getData.get("product.creditCardProduct.balanceTransferDetails[0].campaignId"),common.listdbvalues("CI_Product_BT_Txn", "", "campaign_CD", scenario).get(0).toString());
				
				// Fetching and validating campaign_CD
				TestUtils.softassert("CONSENT_TYPE",getData.get("applicant.consentDetails[0].consentType"),common.listdbvalues("CI_CUST_CONSENT_TXN", "", "CONSENT_TYPE", scenario).get(0).toString());
				
				// Fetching and validating campaign_CD
				TestUtils.softassert("CONSENT_FLAG",getData.get("applicant.consentDetails[0].isConsentGiven"),common.listdbvalues("CI_CUST_CONSENT_TXN", "", "CONSENT_FLAG", scenario).get(0).toString());
				
	}
	
}
