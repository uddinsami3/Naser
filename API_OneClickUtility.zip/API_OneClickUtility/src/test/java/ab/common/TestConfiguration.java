package ab.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.extension.responsetemplating.ResponseTemplateTransformer;
import com.github.tomakehurst.wiremock.http.Response;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import ab.glue.Genericglue;
import ab.utils.DataProvider;
import io.cucumber.java.Before;
import io.restassured.RestAssured;
import io.swagger.inflector.processors.JsonNodeExampleSerializer;
import io.swagger.models.Swagger;
import io.swagger.models.parameters.BodyParameter;
import io.swagger.parser.SwaggerParser;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

import io.swagger.parser.SwaggerParser;
import io.swagger.util.Json;
import io.swagger.util.Yaml;
import io.swagger.v3.parser.core.models.ParseOptions;
import io.swagger.models.*;
import io.swagger.models.apideclaration.Parameter;
import io.swagger.models.parameters.BodyParameter;
import io.swagger.models.parameters.HeaderParameter;
import io.swagger.models.properties.Property;
import io.swagger.models.properties.RefProperty;
import io.swagger.inflector.examples.*;
import io.swagger.inflector.examples.models.Example;
import io.swagger.inflector.processors.JsonNodeExampleSerializer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
//import io.swagger.util.Json;
//import io.swagger.util.Yaml;
import java.util.Map;
import java.util.Set;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
//import com.jayway.jsonpath.JsonPath;
//import com.jayway.jsonpath.internal.filter.ValueNodes.JsonNode;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

public class TestConfiguration {
	// header Varaiable
	private final static String ContentType = "application/json";
	private static String countryCode = "HK";
	private final static String AcceptLanguage = "en";
	private final static String channelID = "MBK";
	private final static String businessCode = "GCB";
	private final static String cif = "000723059";
	private static String uuid;
	private final static String accept = "application/json";
	// Variable declaration
	public static WireMockServer wireMockServer;
	// https://aspac.sandbox.api.citi.com/gcbap/api
	// https://aspac.sandbox.api.citi.com/gcbap/uat1/api/

	private final static String uat1endpoint = "https://aspac.sandbox.api.citi.com/gcbap/uat1/api";
	private final static String sitendpoint = "https://xlg-fdn-p-psg-internal-apac-sit2.apps-mw1-perf.apac.nsroot.net";
	private final static String sit2endpoint = "https://sit2.globalcommondirectsalesagent.consumer.citigroup.net:4001";
	private final static String uatendpoint = "https://uat2consumerapi.apac.nsroot.net";
	private final static String uat2endpoint = "https://uat2a.customer360liteview.citigroup.net";
	public static String wireMockHost = "http://localhost:8082";
	// public static String uatEclipse =
	// "https://eclipse.uat2a.citigroup.net/siteminderagent/forms/login.fcc?&popup=1";
	// public static String uatEclipse = "https://eclipse.uat2a.citigroup.net/";
	public static String uatEclipse = "https://eclipse.uat2b.citigroup.net/siteminderagent/forms/login.fcc?&popup=1";

	public static String sitEclipse = "https://eclipse.sit.citigroup.net:4001/";
	private static String endpoint = null;
	private static String path = null;
	private static String body = null;
	public static int setCurrentRow = 1;
	static Fillo fillo = new Fillo();
	static Connection connection;
	public static String jsonPayload = null;
	public static String swaggerVersion = null;
	public static Set<String> payloadKeyset = null;
	public static String requestBodyPattern = "\"bodyPatterns\" : [";
	public static String queryStringPattern = "\"queryParameters\" : {";
	public static String responseTemplate = "{\r\n" + " \"request\" : {\r\n" + " \"urlPath\" : \"{{URI}}\",\r\n"
			+ " \"method\" : \"{{METHOD}}\",\r\n" + " {{REQUEST}} \r\n" + "\r\n" + " },\r\n" + " \"response\" : {\r\n"
			+ " \"status\" : 200,\r\n" + " \"body\" : \"{{RESPONSE}}\",\r\n" + " \"headers\": {\r\n"
			+ " \"Content-Type\": \"application/json\"\r\n" + " },\r\n"
			+ " \"transformers\": [\"response-template\"]\r\n" + " }\r\n" + "}";
	
	public static String[] strs = { "uniqueReferenceId", "sequenceNumber", "customerAssociatedTags", "contentSource",
			"contentTitle", "contentPublishedDate" };	
	public static String[] dynamicFields = { "uniqueReferenceId", "sequenceNumber", "contentId", "nextChallengeId" };
	public static String apiPath;

	// Private object creation
	private static TestConfiguration ourInstance = new TestConfiguration();

	// object calling outside class methhod declaration
	public static TestConfiguration getInstance() {
		return ourInstance;
	}

	public static String eclipseUrl(String environment) {

		if (environment.equals("UAT")) {
			endpoint = uatEclipse;
		} else if (environment.equals("SIT")) {
			endpoint = sitEclipse;
		}
		return endpoint;

	}

	@Before
	public static String endpoint(String environment) throws FilloException {
		TestConfiguration testConfiguration = getInstance();
		HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(CommonUtility.APIName,
				CommonUtility.CurrentTestCaseName);
		String EndPointURL = excelmap.get("EndPointURL").toString();
		// RestAssured.proxy("proxy.citicorp.com", 8080);

		if (System.getProperty("ENV") != null && System.getProperty("ENV").equals("SIT")) {

			endpoint = testConfiguration.sitendpoint;

			System.out.println(endpoint + "SIT");
		}

		else if (System.getProperty("ENV") != null && System.getProperty("ENV").equals("UAT1")) {
			endpoint = testConfiguration.sitendpoint;

		} else if (System.getProperty("ENV") != null && System.getProperty("ENV").equals("SIT2")) {
			// endpoint = testConfiguration.sit2endoint;

		} else if (environment.equals("SIT2")) {
			endpoint = testConfiguration.sit2endpoint;
		} else if (environment.equals("UAT")) {
			endpoint = testConfiguration.uatendpoint;
		} else if (environment.equals("UAT2")) {
			endpoint = testConfiguration.uat2endpoint;
		} else if (environment.equals("STUB")) {
			endpoint = EndPointURL;
		} else if (environment.equals("LIVE")) {
			endpoint = EndPointURL;
		} else {
			endpoint = testConfiguration.sitendpoint;

		}

		return endpoint;
	}

	public static String requestpath(String scope, String apiName) throws NoSuchFieldException {

		if (scope.equalsIgnoreCase("private")) {
			path = ab.common.APIResourcePathPrivate.class.getDeclaredField(apiName)
					.getAnnotation(ab.common.APIResourcePathPrivate.Data.class).name();
		}

		else {
			path = ab.common.APIResourcePathPublic.class.getDeclaredField(apiName)
					.getAnnotation(ab.common.APIResourcePathPublic.Data.class).name();
			System.out.println(path);
		}
		return path;
	}

	public static String Getpayloadbody(String apiName) throws NoSuchFieldException, FileNotFoundException, IOException,
			ParseException, FilloException, InterruptedException {
		DataProvider readdata = new DataProvider();

		JSONParser parser = new JSONParser();
		Object obj = null;
		Map<Object, Object> map = new HashMap<>();

		Object key;
		Object value;
		if (apiName.contains("Update")) {
			obj = parser.parse(
					readdata.extractExceldataoverride(Genericglue.testCaseID()).get("OrchesReq_Payload").toString());
		} else {
			obj = parser.parse(
					readdata.extractExceldataoverride(Genericglue.testCaseID()).get("Request_Payload").toString());
		}
		JSONObject jsonObject = (JSONObject) obj;

		body = jsonObject.toString();
		System.out.println(body);
		return body;
	}

	public static String payloadbody(String apiName) throws NoSuchFieldException, FileNotFoundException, IOException,
			ParseException, FilloException, InterruptedException {
		DataProvider readdata = new DataProvider();

		JSONParser parser = new JSONParser();
		Object obj = null;
		Map<Object, Object> map = new HashMap<>();

		Object key;
		Object value;

		// readdata.extractExceldata(Genericglue.testCaseID(), Genericglue.sheetName(),
		// Genericglue.workbook()).entrySet().parallelStream().forEach(
		/*
		 * readdata.extractExceldataoverride(Genericglue.testCaseID(),
		 * Genericglue.sheetName(),
		 * Genericglue.workbook()).entrySet().parallelStream().forEach(
		 * 
		 * S ->{ Object key; Object value; key = S.getKey(); value = S.getValue(); try {
		 * //Thread.sleep(200); CommonUtility.payload(key, value,apiName); } catch
		 * (IOException | ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } }
		 * 
		 * );
		 */

		/*
		 * for (Entry<String, Object> entry :
		 * readdata.extractExceldata(Genericglue.testCaseID(), Genericglue.sheetName(),
		 * Genericglue.workbook()).entrySet()) { //System.out.println("Key : " +
		 * entry.getKey() + " Value : " + entry.getValue());
		 * 
		 * key = entry.getKey(); value = entry.getValue();
		 * 
		 * //System.out.println("Key : " + key + " Value : " + value);
		 * 
		 * CommonUtility.payload(key, value,apiName); }
		 */

		/*
		 * StringBuilder json = new StringBuilder(); FileReader path = new
		 * FileReader("src/test/resources/Payloads/"+apiName+".txt");
		 * 
		 * try { BufferedReader br = new BufferedReader(path); String line; while ((line
		 * = br.readLine()) != null) { json.append(line); } br.close(); } catch
		 * (Exception e) { e.printStackTrace(); } //System.out.println(json);
		 * 
		 * 
		 * obj =parser.parse(json.toString());
		 */
		// obj = parser.parse(new
		// FileReader("src/test/resources/Payloads/"+apiName+".txt"));
		if (apiName.contains("Update")) {
			obj = parser.parse(
					readdata.extractExceldataoverride(Genericglue.testCaseID()).get("OrchesReq_Payload").toString());
		} else {
			obj = parser.parse(
					readdata.extractExceldataoverride(Genericglue.testCaseID()).get("Request_Payload").toString());
		}
		JSONObject jsonObject = (JSONObject) obj;

		// body = jsonObject.toJSONString();
		body = jsonObject.toString();
		System.out.println(body);
		// System.out.print(body + "+++++++");
		return body;
	}

	public static Map<String, Object> header() {

		Map<String, Object> header = new HashMap<String, Object>();
		UUID uuid1 = UUID.randomUUID();
		header.put("uuid", uuid1);
		// header.put("accept",Genericglue.getData.get("uuid"));
		header.put("countryCode", Genericglue.getData.get("countryCode"));
		header.put("Content-Type", Genericglue.getData.get("Content-Type"));
		// header.put("Accept-Language",Genericglue.getData.get("Accept-Language"));
		header.put("channelID", Genericglue.getData.get("channelID"));
		header.put("businessCode", Genericglue.getData.get("businessCode"));

		header.put("consumerOrgCode", Genericglue.getData.get("consumerOrgCode"));
		header.put("Accept", "application/json");

		return header;

	}

	public static Object commonHeader(String abiName) throws IllegalAccessException, InstantiationException,
			ClassNotFoundException, NoSuchMethodException, InvocationTargetException {

		Class className = Class.forName("ab.glue." + abiName);
		Object obj = className.newInstance();
		Method headermethod = className.getDeclaredMethod("apiHeader", null);
		headermethod.setAccessible(true);
		return headermethod.invoke(obj);
	}

	public static Object commonQuery(String abiName) throws ClassNotFoundException, IllegalAccessException,
			InstantiationException, NoSuchMethodException, InvocationTargetException {
		Class className = Class.forName("ab.glue." + abiName);
		Object obj = className.newInstance();
		Method querymethod = className.getDeclaredMethod("queryHeader", null);
		querymethod.setAccessible(true);
		return querymethod.invoke(obj);
	}

	public static Object commonPath(String abiName) throws ClassNotFoundException, IllegalAccessException,
			InstantiationException, NoSuchMethodException, InvocationTargetException {
		Class className = Class.forName("ab.glue." + abiName);
		Object obj = className.newInstance();
		Method querymethod = className.getDeclaredMethod("pathHeader", null);
		querymethod.setAccessible(true);
		return querymethod.invoke(obj);
	}

	public static Object commonbody(String abiName) throws ClassNotFoundException, IllegalAccessException,
			InstantiationException, NoSuchMethodException, InvocationTargetException {
		Class className = Class.forName("ab.glue." + abiName);
		Object obj = className.newInstance();
		Method querymethod = className.getDeclaredMethod("apibody", null);
		querymethod.setAccessible(true);
		return querymethod.invoke(obj);
	}

	public static void FeatureOverride() throws IOException {

		//FileReader fr = new FileReader(System.getProperty("user.dir") + "/src/test/resources/Scenarios/InputFile - Copy.txt");
		FileReader fr = new FileReader(System.getProperty("user.dir") + "/src/test/resources/Scenarios/inputUpdate.txt");

		FileWriter fw = new FileWriter(System.getProperty("user.dir")
				+ "/src/test/resources/Project/SGTWAReport/Features/wealthPortfolio.feature");
		try {

			int c = fr.read();
			while (c != -1) {
				fw.write(c);
				c = fr.read();
			}
		} catch (IOException e) {
			System.out.println(e);
		} finally {
			fr.close();
			fw.close();
		}
	}

	public static void wireMockStart() throws IOException {
		System.out.println("Starting WIREMOCK Server");
		//Genericglue.scenario.log("\r\n" + "Starting WIREMOCK Server" + "\r\n");
		wireMockServer = new WireMockServer(options().port(8082).extensions(new ResponseTemplateTransformer(false)));
		// System.out.println("wiremock global setting" +
		// wireMockServer.getGlobalSettings().getSettings().getExtended());
		File folder = new File(System.getProperty("user.dir") + "/mappings");
		File[] listOfFiles = folder.listFiles();
		for (File file : listOfFiles) {
			if (file.isFile() && file.getName().endsWith(".json")) {
				
				String content = FileUtils.readFileToString(file);
				wireMockServer.addStubMapping(StubMapping.buildFrom(content));

			}
		}
		wireMockServer.start();
		System.out.println("WIREMOCK Server Started");
		//Genericglue.scenario.log("\r\n" + "WIREMOCK Server Started" + "\r\n");

		// wireMockServer.addStubMapping(stubMapping);
	}

	public static void wireMockStop() {
		wireMockServer.stop();
		System.out.println("WIREMOCK Server Has Been Stopped");
	}

	// File featureFile
	public static List<String> setExcelDataToFeature() throws InvalidFormatException, IOException, FilloException {
		List<File> listOfFeatureFiles = listOfFeatureFiles(
				new File(System.getProperty("user.dir") + "/src/test/resources/Project/SGTWAReport/Features"));
		for (File featureFile : listOfFeatureFiles) {
			System.out.println(setCurrentRow);
			List<String> fileData = new ArrayList<String>();
			try (BufferedReader buffReader = new BufferedReader(
					new InputStreamReader(new BufferedInputStream(new FileInputStream(featureFile)), "UTF-8"))) {
				String data;
				List<Map<String, String>> excelData = null;
				boolean foundHashTag = false;
				boolean featureData = false;
				while ((data = buffReader.readLine()) != null) {
					String sheetName = null;
					String excelFilePath = null;
					if (data.trim().contains("##@externaldata")) {
						excelFilePath = data.substring(StringUtils.ordinalIndexOf(data, "@", 2) + 1,
								data.lastIndexOf("@"));
						sheetName = data.substring(data.lastIndexOf("@") + 1, data.length());
						foundHashTag = true;
						fileData.add(data);
					}
					if (foundHashTag) {
						if (setCurrentRow == 7) {
							System.out.println("i am in 7th row");
						}
						// excelData = new DataProvider().getData(excelFilePath, sheetName);
						excelData = DataProvider.GetAPIDataFromExcel("Sheet1", "APITestData");

						setCurrentRow++;
						System.out.println(setCurrentRow);
//	                    String columnHeader = "";

//	                    for (Entry<String, String> map : excelData.get(0).entrySet()) {
//	                        columnHeader = columnHeader + "|" + map.getKey();
//	                    }
//	                  
//	                    fileData.add(columnHeader + "|");
						String cellData = "";
						for (int rowNumber = 0; rowNumber < excelData.size(); rowNumber++) {

							for (Entry<String, String> mapData : excelData.get(rowNumber).entrySet()) {
								if (!mapData.getValue().isEmpty()) {
									cellData = cellData + "|" + mapData.getValue();

								}

							}

						}
						fileData.add(cellData + "|");
						foundHashTag = false;
						featureData = true;
						continue;

					}
					if (data.startsWith("|") || data.endsWith("|")) {
						if (featureData) {
							continue;
						} else {
							fileData.add(data);
							continue;
						}
					} else {
						featureData = false;
					}
					fileData.add(data);
				}
				try (BufferedWriter writer = new BufferedWriter(
						new OutputStreamWriter(new FileOutputStream(featureFile), "UTF-8"));) {
					for (String string : fileData) {
						writer.write(string);
						writer.write("\n");
					}
				}
			}

			return fileData;
		}
		return null;
	}

	private static List<File> listOfFeatureFiles(File folder) {
		List<File> featureFiles = new ArrayList<File>();
		for (File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				featureFiles.addAll(listOfFeatureFiles(fileEntry));
			} else {
				if (fileEntry.isFile() && fileEntry.getName().endsWith(".feature")) {
					featureFiles.add(fileEntry);
				}
			}
		}
		return featureFiles;
	}

	public static void overrideFeatureFiles(String featuresDirectoryPath)
			throws IOException, InvalidFormatException, FilloException {
		List<File> listOfFeatureFiles = listOfFeatureFiles(new File(featuresDirectoryPath));
		for (File featureFile : listOfFeatureFiles) {
			List<String> featureWithExcelData = setExcelDataToFeature();
			try (BufferedWriter writer = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(featureFile), "UTF-8"));) {
				for (String string : featureWithExcelData) {
					writer.write(string);
					writer.write("\n");
				}
			}
		}
	}

	public static String getWiremockProperty(String length, String type) {
		return "{{randomValue length=" + length + " type='" + type + "'}}";
	}

	public static String getMatchExpression(String jsonPath, String regex) {
		return "{\"matchesJsonPath\":{\"expression\": \"" + jsonPath + "\",\"matches\": \"" + regex + "\"},";
	}
	
	public static String getQueryParameterExpression(String param , String regex) {
		return "\"queryParameters\" : {\"" + param + "\" : {\"matches\" : \"" + regex + "\"}}";
		}

	public static String getRegex(String type, String minLength, String maxLenth) {
		if (type.contains("string")) {
			return "^[A-Za-z]{" + minLength + "," + maxLenth + "}$";
		} else if (type.contains("number")) {
			return "^[0-9]{" + minLength + "," + maxLenth + "}$";
		} else {
			return ".*";
		}
	}

	public static String getDatatype(String type) {
		if (type.contains("string")) {
			return "ALPHANUMERIC";
		} else if (type.contains("number")) {
			return "INTEGER";
		} else {
			return "ALPHABETIC";
		}
	}

	public static String getSheetname(String operationId) {
		if (operationId.contentEquals("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsights")) {
			return "RetrieveCustomerWorkbench";
		} else if (operationId
				.contentEquals("UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallenges")) {
			return "UpdateCustomerWorkbench";
		} else if (operationId
				.contentEquals("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardFinancialReadinessLevel")) {
			return "financialReadinessLevel";
		}
		else if (operationId
				.contentEquals("UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallengesRequest")) {
			return "UpdateCustomerWorkbench";
		}
		else if (operationId
				.contentEquals("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest")) {
			return "RetrieveCustomerWorkbench";
		}

		else {
			return "";
		}
	}

	public static HashMap<String, Object> Metadataextract(String testCaseId, String sheetName) throws FilloException {

		
		HashMap<String, Object> excelMap = new HashMap<String, Object>();

		connection = fillo.getConnection(System.getProperty("user.dir")+"/metadata/Metadata.xls");

		String strQuery = "Select * from " + sheetName + " where Business_Element_name='" + testCaseId + "'";

		Recordset recordset = connection.executeQuery(strQuery);

		while (recordset.next()) {
			ArrayList<String> ColCollection = recordset.getFieldNames();
			int size = ColCollection.size();
			for (int Iter = 0; Iter <= (size - 1); Iter++) {
				String ColName = ColCollection.get(Iter);
				String ColValue = recordset.getField(ColName);
				excelMap.put(ColName, ColValue);
			}
		}
		
		recordset.close();
		connection.close();

		return excelMap;
	}

	public static String getMethod(String path) {
		Swagger swagger = new SwaggerParser().read(System.getProperty("user.dir")+ "\\WealthDashboard.json", null,
				false);
		if (swagger.getPaths().get(path).getPost() != null) {
			return "POST";
		} else if (swagger.getPaths().get(path).getPut() != null) {
			return "PUT";
		} else if (swagger.getPaths().get(path).getGet() != null) {
			return "GET";
		} else if (swagger.getPaths().get(path).getDelete() != null) {
			return "GET";
		} else {
			return "PATCH";
		}
	}

	public static void generateWirmockMappings(String swaggerPath) throws FilloException {
		System.out.println("Generating WIREMOCK Mappings");
		//Genericglue.scenario.log("\r\n" + "Generating WIREMOCK Mappings" + "\r\n");
		Swagger swagger = new SwaggerParser().read(System.getProperty("user.dir")+ "\\WealthDashboard.json", null,
				false);
		String operationId = null;
		String simpleRef = null;
		String basePath = swagger.getBasePath();
		Map<String, io.swagger.models.Response> responses;
		SimpleModule simpleModule = new SimpleModule().addSerializer(new JsonNodeExampleSerializer());
		Json.mapper().registerModule(simpleModule);
		String requestTemplate = "";
		Configuration configuration = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
				.mappingProvider(new JacksonMappingProvider()).build();

		List list = Arrays.asList(strs);
		Set<String> paths = swagger.getPaths().keySet();
		Iterator pathIterator = paths.iterator();
		while (pathIterator.hasNext()) {
			List<io.swagger.models.parameters.Parameter> parameters;
			String jsonTemplate = responseTemplate;
			String path = pathIterator.next().toString();
			
			apiPath = basePath + path;
			String method = getMethod(path);
			jsonTemplate = jsonTemplate.replace("{{METHOD}}", method);
			jsonTemplate = jsonTemplate.replace("{{URI}}", apiPath);
			CommonUtility.GenerateMappings();

			
			if (method.contentEquals("POST")) {
				parameters = swagger.getPaths().get(path).getPost().getParameters();
				responses = swagger.getPaths().get(path).getPost().getResponses();
				operationId = swagger.getPaths().get(path).getPost().getOperationId();
			} else if (method.contentEquals("PUT")) {
				parameters = swagger.getPaths().get(path).getPut().getParameters();
				responses = swagger.getPaths().get(path).getPut().getResponses();
				operationId = swagger.getPaths().get(path).getPut().getOperationId();
			} else if (method.contentEquals("GET")) {
				parameters = swagger.getPaths().get(path).getGet().getParameters();
				responses = swagger.getPaths().get(path).getGet().getResponses();
				operationId = swagger.getPaths().get(path).getGet().getOperationId();
			} else {
				parameters = swagger.getPaths().get(path).getDelete().getParameters();
				responses = swagger.getPaths().get(path).getDelete().getResponses();
				operationId = swagger.getPaths().get(path).getDelete().getOperationId();
			}
			if (!getSheetname(operationId).isEmpty()) {
				if (parameters != null) {
					for (io.swagger.models.parameters.Parameter parameter : parameters) {
						if (parameter instanceof BodyParameter) {
							BodyParameter bp = (BodyParameter) parameter;
							Model schema = bp.getSchema();
							String reference = schema.getReference();
							// I do not see how to get 'simpleRef', so:
							simpleRef = reference.replaceFirst(".*/", "");
							// System.out.println("reference is " + simpleRef);
							Map<String, Model> definitions = swagger.getDefinitions();
							Model model = definitions.get(simpleRef);
							if (method.matches("POST|PUT")) {
								Set<String> keyset = model.getProperties().keySet();
								Iterator<String> itr = keyset.iterator();

								while (itr.hasNext()) {
									// System.out.println(itr.next());
									HashMap hashMap = Metadataextract(itr.next(), getSheetname(operationId));
									// System.out.println(getWiremockProperty(hashMap.get("COLUMN_20").toString(),
									// hashMap.get("JSONDatatype").toString()));
									requestTemplate += getMatchExpression(
											"$." + hashMap.get("Json element name").toString(),
											getRegex(hashMap.get("JSONDatatype").toString(),
													hashMap.get("COLUMN_20").toString(),
													hashMap.get("COLUMN_21").toString()));
									

								}
								jsonTemplate = jsonTemplate.replace("{{REQUEST}}",
										requestBodyPattern + requestTemplate.replaceAll(",$", "]"));
								Example example = ExampleBuilder.fromModel(simpleRef, model, definitions,
										new HashSet<String>());
								

							}
							if (method.matches("GET")) {
								requestTemplate += queryStringPattern
										+ "\"sequenceNumber\" : {\"matches\" : \"^[0-9]{10}$\"}}";
								System.out.println(requestTemplate);
								jsonTemplate = jsonTemplate.replace("{{REQUEST}}", requestTemplate);

							}

						}

					}

				}
				if (!(responses.get("200").getResponseSchema() == null)) {
					Model schema = responses.get("200").getResponseSchema();

					String reference = schema.getReference();
					simpleRef = reference.replaceFirst(".*/", "");
					// System.out.println("reference is " + simpleRef);
					Map<String, Model> definitions = swagger.getDefinitions();
					Model retrieveCustomer = definitions.get(simpleRef);

					Example example = ExampleBuilder.fromModel(simpleRef, retrieveCustomer, definitions,
							new HashSet<String>());
					
					Set<String> keyset = retrieveCustomer.getProperties().keySet();
					
					String responseString = Json.pretty(example).toString();
					String finalResponse = responseString;
					// JsonNode updatedJson =
					// (JsonNode)JsonPath.using(configuration).parse(responseString).set("$.contentList[0].sequenceNumber",
					// "naser1234").json();
					DocumentContext doc = null;
					Iterator listIterator;
					if (getSheetname(operationId).contentEquals("RetrieveCustomerWorkbench")) {
						listIterator = list.iterator();
					} else {
						listIterator = retrieveCustomer.getProperties().keySet().iterator();
					}
					while (listIterator.hasNext()) {
						String param = listIterator.next().toString();
						HashMap hashMap = Metadataextract(param, getSheetname(operationId));
						String randomValue = getWiremockProperty(hashMap.get("COLUMN_20").toString(),
								getDatatype(hashMap.get("JSONDatatype").toString()));
						String jsonPath = "$." + hashMap.get("Json element name").toString();
						
						String tmpString = JsonPath.parse(responseString).read(jsonPath).toString();
						// doc = JsonPath.parse(responseString).set(jsonPath, randomValue);
						finalResponse = finalResponse.replace(tmpString, randomValue);
						// finalResponse = finalResponse.replace("\"", "\\\"");

						// responseString = doc.json().toString();
					}
					//System.out.println(finalResponse);
					jsonTemplate = jsonTemplate.replace("{{RESPONSE}}", finalResponse);
					//System.out.println(jsonTemplate);
					
					
				}
				
			}
			
		}
		System.out.println("WIREMOCK Mappings Has Been Generated");
		//Genericglue.scenario.log("\r\n" + "WIREMOCK Mappings Has Been Generated" + "\r\n");
	}
	
	public static boolean isDynamicResponseField(String param) {
		boolean result = false;
		for (int count = 0; count < dynamicFields.length; count++) {
		if (dynamicFields[count].contentEquals(param)) {
		result = true;
		break;
		}



		}
		return result;
		}
		public static void writeMappingFile(String filename , String mapping) throws IOException {
			
		String filePath = System.getProperty("user.dir") + "/mappings/"+ filename + ".txt";
		File file = new File(filePath);
		FileWriter writer = new FileWriter(filePath);
		writer.write(mapping);
		writer.close();
		}
}
