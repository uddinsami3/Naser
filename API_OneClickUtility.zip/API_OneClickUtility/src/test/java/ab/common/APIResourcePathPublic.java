package ab.common;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import ab.common.APIResourcePathPublic.Data;


public interface APIResourcePathPublic {
	
	

    @Retention(RetentionPolicy.RUNTIME)
    public @interface Data{

        String name();


    }
    
    @Data (name = "/v1/apac/onboarding/products/unsecured/applications")
    String ApplicationADD = null;
    
    @Data (name = "/v1/apac/onboarding/products/unsecured/applications/{applicationId}")
    String ApplicationUpdate = null;

    @Data (name = "/v1/apac/onboarding/products/unsecured/applications/{applicationId}/backgroundScreening")
    String ApplicationBGS = null;
    
    @Data (name = "/v1/apac/onboarding/products/unsecured/applications/{applicationId}")
    String ApplicationUpdateBeforeIPA = null;
    
    @Data (name = "/v1/apac/onboarding/products/unsecured/applications/{applicationId}/inPrincipleApprovals")
    String ApplicationIPA = null;

    @Data (name = "/v1/apac/onboarding/products/unsecured/applications/{applicationId}/offerAcceptance")
    String ApplicationOfferAcceptance = null;
    
    @Data (name = "/v1/apac/onboarding/products/unsecured/applications/{applicationId}")
    String ApplicationUpdateBeforeFinal = null;
    
    @Data (name = "/v1/apac/onboarding/products/unsecured/applications/{applicationId}/submission")
    String ApplicationFinalSubmit = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/invstReturnsByPeriodGraph")
    String InvstReturnsByPeriodGraph = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/portfolio")
    String wealthPortfolio = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/investmentHoldings")
    String investmentHoldings = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/twaReportPortfolioActualLoanDetail")
    String loanDetail = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/loanHistoryTrend")
    String loanHistoryTrend = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/otherLoanSummary")
    String otherLoanSummary = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/twaReportActualLoanSnapshotResponse")
    String ActualLoanSnapshotResponse = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/loanTransaction")
    String loanTransaction = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/invstReturnsByPeriodData")
    String InvstReturnsByPeriodData = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/invstReturnsAnnuNetRetGraphData")
    String InvstReturnsAnnuNetRetGraphData = null;

    @Data (name = "/citiplannerRA/wealth/financials/invstReturnsAnnuNetRetGraph")
    String InvstReturnsAnnuNetRetGraph = null;

    @Data (name = "/citiplannerRA/wealth/financials/portfolio")
    String InvestmentPortfolio = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/closedLoanSummary")
    String ClosedLoanSummary = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/twaReportLoanCurrencyGraphData")
    String TwaReportLoanCurrencyGraphData = null;
    
    @Data (name = "/citiplannerRA/wealth/financials/portfolioLoanSummary")
    String PortfolioLoanSummary = null;
    
    @Data (name = "/citiplannerRA/wealth/customers/search/AUM")
    String AUM = null;

    @Data (name = "/citiplannerRA/customers/{cloakedCustomerID}/relationships")
    String RelationShips = null;
    
    @Data (name = "/v1/customerWorkbench/wealthDashboard/newsAndInsights/retrieve")
    String ContentList = null;
    
    @Data (name = "")
    String ContentListDetails = null; 
    
    @Data (name = "")
    String CreateCustomerWorkbenchOperatingSessionWealthDashboardLifeTargetRequest = null;
    
    @Data (name = "")
    String CreateCustomerWorkbenchOperatingSessionWealthDashboardLifeTargetResponse = null;
    
    @Data (name = "")
    String ErrorResponse = null;
    
    @Data (name = "")
    String 	RetrieveCustomerWorkbenchOperatingSessionWealthDashboardFinancialReadinessLevelResponse = null;
    
    @Data (name = "")
    String RetrieveCustomerWorkbenchOperatingSessionWealthDashboardLifeTargetNotificationResponse = null;
    
    @Data (name ="")
    String RetrieveCustomerWorkbenchOperatingSessionWealthDashboardLifeTargetResponse = null;
    
    @Data (name = "/v1/customerWorkbench/wealthDashboard/newsAndInsights/retrieve")
    String RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest = null;    
    
    @Data (name = "")
    String RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsResponse = null;
    
    @Data (name = "/v1/customerWorkbench/wealthDashboard/actionChallenges")
    String UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallengesRequest = null;
    
    @Data (name = "")
    String UpdateCustomerWorkbenchOperatingSessionWealthDashboardFavouriteStatusRequest = null;
    
    @Data (name = "/v1/customerWorkbench/wealthDashboard/financialReadinessLevel")
    String financialReadinessLevel = null;
    
    
    
    
    
}
