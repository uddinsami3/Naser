package ab.common;

import static io.restassured.RestAssured.given;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.google.gson.*;
import io.swagger.models.parameters.Parameter;
import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.apache.commons.lang3.RandomStringUtils;


import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.select.Elements;
import org.testng.Assert;

import com.codoid.products.exception.FilloException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.github.wnameless.json.unflattener.JsonUnflattener;

import ab.glue.Genericglue;
import ab.utils.DataProvider;
import ab.utils.OrcaleDBConnection;
import ab.utils.TestUtils;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.github.benas.randombeans.EnhancedRandomBuilder;
import io.github.benas.randombeans.api.EnhancedRandom;
import io.github.benas.randombeans.randomizers.range.IntegerRangeRandomizer;
import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.swagger.client.model.RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest;
import io.swagger.parser.SwaggerParser;
import io.swagger.util.Json;
import io.swagger.models.*;
import io.swagger.inflector.examples.*;
import io.swagger.inflector.examples.models.Example;
import io.swagger.inflector.processors.JsonNodeExampleSerializer;


//import io.swagger.util.Json;
//import io.swagger.util.Yaml;


import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;


public class CommonUtility {
	static Response response;
	static RequestSpecification request;
	public static Scenario scenario;
	public static String  apiName;
	public static String  sid;
    static String applicationaddId;
	static String controlFlowId;
    public static String req;
    public static String res;
    static  FileWriter fw;
    OrcaleDBConnection dbconnection = new OrcaleDBConnection();
	TestUtils getproperty = new TestUtils();
	static Map<String,String> invalidResponseDetails = new HashMap<String,String>();

	String APPLICATIONID;
	public static String cloakedCust;
	public static String cloakedRelationship;
	public static boolean result;
	public static String[] Fieldnames = {"grant_type", "Control Flow ID", "confirmationCode"}; 
	 static Fillo fillo=new Fillo();
	public static Set<Object> negativerecordsetMap = new HashSet<Object> ();
	  static Connection connection;
	  public static String APIName;
	  public static String environment;
	  public static String executionType;
	  public static String requestType;
	  public static String scope;
	  public static String jsonPayload= null;
	  public static String swaggerVersion= null;
	  public static Set<String> payloadKeyset = null;
	  public static String swaggerDescription = null;
	  public static String swaggerBasePath = null;
	  public static Set<String> swaggerPath = null;
	  public static List<String> swaggerProduces = null;
	  public static String swaggerSummary = null;
	  public static String swaggerSchemes=null;
	  public static String swaggerHost=null;
	  public static String BaseLiveHostURI =null;
	 public static String body = null;
	 public static String responsevalue;
	 public static Map<String, Object> FinalResponseMap;
	 public static String InputValueToAllApi;
	 public static  int OrchesInputFlag =0;
	 public static Map<String, String> OrchesInputKeyAndValue = new HashMap<String, String>();
	 public static String CurrentTestCaseName;
	 public static Set<Object> recordsetMap = new HashSet<Object> ();
	 public static Set<Object> testCaseMap = new HashSet<Object> ();
	 public static String TempTestCaseName;
		public static File updateFile;
	public static HashMap<String,Object> fieldMap= new HashMap<String, Object>();
	public static TreeMap<String ,String> apiDetails = new TreeMap<>();
	public static int TCCount = 0;
	 public static String TempTestCaseName1;
	 public static Set<String> header= new HashSet<>();
	 public static Map<String,Object> headerFieldvalues = new HashMap<>();
	 public static JsonArray payloadbodyMandatoryFields;
	 public static String responseCode;
	 public static String responseValue;
	 public static Set<Object> MandatoryPayloadBody = new HashSet<>();
	 public static HashMap<String,Object> valueMap= new HashMap<String, Object>();
	 public static int recordsetSize =0;
	public static HashMap<String,String> exelMap= new HashMap<String, String>();
	public static HashMap<String,String> headerWithDatatype= new HashMap<String, String>();
	public static boolean success = false;
	public static boolean invalid = false;
	public static boolean unauthorized = false;
	public static void createTestcases() throws FilloException {

		try {
			HashMap<String, Object> excelMap = new HashMap<String, Object>();
			HashMap<String, Object> excelMap1 = new HashMap<String, Object>();
			int i = 0;
			connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/testData/APITestData - Copy.xlsx");
			String strQuery = "Select * from Sheet3 where Execution_Control='Yes' and Execution_Type='UNIT'";
			Recordset recordset = connection.executeQuery(strQuery);
			while (recordset.next()) {
				ArrayList<String> ColCollection = recordset.getFieldNames();
				int size = ColCollection.size();
				for (int Iter = 0; Iter <= (size - 1); Iter++) {
					String ColName = ColCollection.get(Iter);
					String ColValue = recordset.getField(ColName);
					excelMap.put(ColName, ColValue);
					if (ColName.toString().equals("TCName")) {
						negativerecordsetMap.add(ColValue);
					}
				}
			}
			if (negativerecordsetMap.size() == 0) {
				System.out.println("No need to generate Test cases as Unit Execution type is not there");
			} else
			{
				for (Object NtestCase : negativerecordsetMap)
				{
					connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/testData/APITestData - Copy.xlsx");
					String strQuery1 = "Select * from Sheet3 where Execution_Control='Yes' and Execution_Type='UNIT' and TCName='" + NtestCase + "'";
					Recordset recordset1 = connection.executeQuery(strQuery1);
					ArrayList<String> ColCollection = recordset1.getFieldNames();

					while (recordset1.next()) {
						int size = ColCollection.size();
						for (int Iter = 0; Iter <= (size - 1); Iter++) {
							String ColName = ColCollection.get(Iter);
							String ColValue = recordset1.getField(ColName);
							excelMap1.put(ColName, ColValue);
						}
						APIName = excelMap1.get("API").toString();
						apiDetails=jsonTomap(APIName);
						environment = excelMap1.get("Env").toString();
						requestType = excelMap1.get("RequestType").toString();
						scope = excelMap1.get("Scope").toString();
						String Execution_Type = excelMap1.get("Execution_Type").toString();
						String EndPointURL = excelMap1.get("EndPointURL").toString();
						String ExpectedResFields=excelMap1.get("ExpectedResponseFields").toString();
						String ExpectedResvalues=excelMap1.get("ExpectedResponseValues").toString();

						Swagger swagger = new SwaggerParser().read(System.getProperty("user.dir") + "\\WealthDashboard.json", null, false);
						connection.close();
						connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
						String Query4 = null;
						if(!requestType.equalsIgnoreCase("PUT")) {
							Query4 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,ExpectedResponseCode,ExpectedResponseFields,ExpectedResponseValues) VALUES('Positive','" + NtestCase + "','" + NtestCase + "','" + Execution_Type + "','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','ALL','200','" + ExpectedResFields + "','" + ExpectedResvalues + "')";
						}
						else
						{
							String description=generatesucessResponse(APIName, scope, requestType.toLowerCase(), "200");
							String ex=getthePutsucessDescription(swagger);
							Query4 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,ExpectedResponseCode,ExpectedResponseFields,ExpectedResponseValues) VALUES('Positive','" + NtestCase + "','" + NtestCase + "','" + Execution_Type + "','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','ALL','200','FullResponse','"+description+"')";

						}
						connection.executeUpdate(Query4);
						getMandatoryHeaders(swagger, requestType);
						header.remove("Accept");
						header.remove("Content-Type");
						if (header.size() == 0) {
							System.out.println("No need to generate negative test cases for header as Mandotary fields are not there");
						}
						else
						{
							String Query7=null;
							if(!requestType.equalsIgnoreCase("PUT")) {
								Query7 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,ExpectedResponseCode,ExpectedResponseFields,ExpectedResponseValues) VALUES('Positive','" + NtestCase + "','" + NtestCase + "_with_MandatoryHeaders','" + Execution_Type + "','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','MANDATORY_HEADERS','200','" + ExpectedResFields + "','" + ExpectedResvalues + "')";
							}
							else
							{
								String description=generatesucessResponse(APIName, scope, requestType.toLowerCase(), "200");
								String ex=getthePutsucessDescription(swagger);
								Query7 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,ExpectedResponseCode,ExpectedResponseFields,ExpectedResponseValues) VALUES('Positive','" + NtestCase + "','" + NtestCase +"_with_MandaroyHeaders','" + Execution_Type + "','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','MANDATORY_HEADERS','200','FullResponse','"+description+"')";

							}
							connection.executeUpdate(Query7);
							for (String str : header) {
								ArrayList<String> keyList=null;
								ArrayList<String> valueList = null;
								if(str.equals("Authorization")) {
									generateExpectedResponse(APIName, scope, requestType.toLowerCase(), "401");
									keyList= new ArrayList<String>(invalidResponseDetails.keySet());
									valueList= new ArrayList<String>(invalidResponseDetails.values());
									String Query5 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,Headerfields_ExcludedForNegativeScenario,ExpectedResponseValues,ExpectedResponseFields,ExpectedResponseCode) VALUES('Negative','" + NtestCase + "','" + NtestCase + "_excludingMandatoryHeader_" + str + "','"+Execution_Type+"','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','ALL','" + str + "','"+valueList.toString().substring(1,valueList.toString().length()-1)+"','"+keyList.toString().substring(1,keyList.toString().length()-1).toLowerCase()+"','401')";
									connection.executeUpdate(Query5);
									String Query6 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,HeaderFields_DatatypeValidationForNegativescenario,ExpectedResponseValues,ExpectedResponseFields,ExpectedResponseCode) VALUES('Negative','" + NtestCase + "','" + NtestCase + "_invalidDatatypeforHeader_" + str + "','"+Execution_Type+"','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','ALL','" + str + "','"+valueList.toString().substring(1,valueList.toString().length()-1)+"','"+keyList.toString().substring(1,keyList.toString().length()-1).toLowerCase()+"','401')";
									connection.executeUpdate(Query6);

								}
								else
								{
									generateExpectedResponse(APIName, scope, requestType.toLowerCase(), "400");
									keyList= new ArrayList<String>(invalidResponseDetails.keySet());
									valueList= new ArrayList<String>(invalidResponseDetails.values());
									String Query5 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,Headerfields_ExcludedForNegativeScenario,ExpectedResponseValues,ExpectedResponseFields,ExpectedResponseCode) VALUES('Negative','" + NtestCase + "','" + NtestCase + "_excludingMandatoryHeader_" + str + "','"+Execution_Type+"','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','ALL','" + str + "','"+valueList.toString().substring(1,valueList.toString().length()-1)+"','"+keyList.toString().substring(1,keyList.toString().length()-1).toLowerCase()+"','400')";
									connection.executeUpdate(Query5);
									String Query6 = "INSERT into Sheet1(Flow,TC_Parent,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,HeaderFields_DatatypeValidationForNegativescenario,ExpectedResponseValues,ExpectedResponseFields,ExpectedResponseCode) VALUES('Negative','" + NtestCase + "','" + NtestCase + "_invalidDatatypeforHeader_" + str + "','"+Execution_Type+"','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','ALL','" + str + "','"+valueList.toString().substring(1,valueList.toString().length()-1)+"','"+keyList.toString().substring(1,keyList.toString().length()-1).toLowerCase()+"','400')";
									connection.executeUpdate(Query6);

								}

								invalidResponseDetails.clear();
							}
						}
						mandatorybodyFIelds();
						if (MandatoryPayloadBody.size() == 0) {
							System.out.println("No need to generate negative test cases for payload required Tag");
						} else {
							for (Object str : MandatoryPayloadBody) {
								ArrayList<String> keyList=null;
								ArrayList<String> valueList = null;
								generateExpectedResponse(APIName, scope, requestType.toLowerCase(), "400");
								keyList= new ArrayList<String>(invalidResponseDetails.keySet());
								valueList= new ArrayList<String>(invalidResponseDetails.values());

								String Query6 = "INSERT into Sheet1(Flow,TC_Parent,Execution_Flow,TCName,Execution_Type,API,RequestType,Scope,Env,EndPointURL,Include_Headers,RequiredBodyfields_ExcludedForNegativeScenario,ExpectedResponseValues,ExpectedResponseFields,ExpectedResponseCode) VALUES('Negative','" + NtestCase + "','Negative','" + NtestCase + "_excludingMandatorybody_" + str + "','"+Execution_Type+"','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','ALL','" + str + "','"+valueList.toString().substring(1,valueList.toString().length()-1)+"','"+keyList.toString().substring(1,keyList.toString().length()-1).toLowerCase()+"','400')";
									connection.executeUpdate(Query6);
								invalidResponseDetails.clear();
							}
						}
					}
					connection.close();
					excelMap1.clear();
					ColCollection.clear();
					header.clear();
					MandatoryPayloadBody.clear();
					headerWithDatatype.clear();
					headerFieldvalues.clear();
				}
			}
		}
		catch(Exception e)
		{
			System.out.println("No Negative test cases");
		}
		finally {
			connection.close();

		}
	}

	private static String getthePutsucessDescription(Swagger swagger) {
		String value = null;

		apiDetails.get("path");

		return value;
	}

	public static void ReadTestCases(String apiName, String RequestType, String tcName) throws Exception {
		HashMap<String, Object> excelMap = new HashMap<String, Object>();
		Set<Object> recordsetMap = new HashSet<Object>();
		connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
		//connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");
		String strQuery = "Select * from Sheet1 where TCName='" + tcName + "'";
		Recordset recordset = connection.executeQuery(strQuery);
		System.out.println(recordsetMap);
		
		
		while (recordset.next()) {

			ArrayList<String> ColCollection = recordset.getFieldNames();
			int size = ColCollection.size();
			for (int Iter = 0; Iter <= (size - 1); Iter++) {
				String ColName = ColCollection.get(Iter);
				String ColValue = recordset.getField(ColName);
				excelMap.put(ColName, ColValue);
				if (ColName.toString().equals("TCName")) {
					recordsetMap.add(ColValue);
					}

			}
			APIName = excelMap.get("API").toString();
			apiDetails=jsonTomap(APIName);
			environment = excelMap.get("Env").toString();
			requestType = excelMap.get("RequestType").toString();
			scope = excelMap.get("Scope").toString();
			CurrentTestCaseName = excelMap.get("TCName").toString();

			// generateExpectedResponse(CurrentTestCaseName);

			// CurrentTestCaseName =TestCaseName;
			Genericglue.scenario.log("\r\n---------Current Running Test Case --------- " +CurrentTestCaseName+" ---------"+ "\r\n");
			Genericglue.scenario.log("\r\n---------Current Running API Name --------- " +APIName+" ---------"+ "\r\n");

			//************Read Swagger file using Swagger parser
			readAPISpec(APIName);
			//**************Write Payload in File*********************
			WriteReqInFile();
			//*****************************
			//Generate API Random Test Data
			// GenerateAPIData();
			///*********** no need for GET and DELETE
			headerDatatype();
			generateHeaderValues();
			
			NegativeScenario_coverfor_Headers();
			NegativeDataTypescenario_coverfor_Headers();

			if(!requestType.matches("GET|DELETE")) {
				GenerateAPIDataUsingParser();
			}
			//*****************************
			//***************Triggering request
			NegativeScenario_coverfor_body(APIName);
			//Wiremock Integartion
			HashMap<String, Object> inputSheetData = DataProvider.ReadTestCasesUsingAPIName(APIName,CurrentTestCaseName);
			if(inputSheetData.get("Headerfields_ExcludedForNegativeScenario") == null && 
					inputSheetData.get("HeaderFields_DatatypeValidationForNegativescenario") == null &&
					inputSheetData.get("RequiredBodyfields_ExcludedForNegativeScenario") == null) {
				success = true;
			}else {
				if(inputSheetData.get("Headerfields_ExcludedForNegativeScenario") != null &&
					inputSheetData.get("Headerfields_ExcludedForNegativeScenario").toString().contentEquals("Authorization")) {
					unauthorized = true;
				}else if(inputSheetData.get("Headerfields_ExcludedForNegativeScenario") != null &&
						!inputSheetData.get("Headerfields_ExcludedForNegativeScenario").toString().contentEquals("Authorization")) {
						unauthorized = true;
					}
			}
			
			if(requestType.matches("PUT|POST")) {
				
			}
			response = userhitsrequestwithAPI(environment, scope, APIName, requestType, Genericglue.scenario);
			//Assert the Responses
			//generateExpectedResponse(CurrentTestCaseName);
			if(!requestType.matches("PUT")) {

				//VerifyResponse();
			}

			//*****************************
			OrchesInputFlag++;
		}
		recordset.close();
		connection.close();
		header.clear();
		headerWithDatatype.clear();
		headerFieldvalues.clear();

	}

	private static void NegativeDataTypescenario_coverfor_Headers() throws FilloException {
		HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName,CurrentTestCaseName);
		List<Object> headerExcelvalues = new ArrayList<>();
		String str = excelmap.get("HeaderFields_DatatypeValidationForNegativescenario").toString();
			if(!str.equalsIgnoreCase("")) {

				if (!str.equalsIgnoreCase("Accept") && !str.equalsIgnoreCase("Content-Type")) {
					String Datatype = headerWithDatatype.get(str);
					if (Datatype.equalsIgnoreCase("string")) {
						Datatype = "integer";
					} else if (Datatype.equalsIgnoreCase("integer")) {
						Datatype = "string";

					}
					Object value = generateRansdomData(Datatype);
					headerFieldvalues.replace(str, value);
				} else {

					headerFieldvalues.put(str, "application/json");
				}
			}
	}

	public static void verifyResponse(String expected_fields, String expected_values, String expected_resposeCode) throws FilloException, IOException, ParseException, InterruptedException {

		if(!requestType.equalsIgnoreCase("PUT")) {
			VerifyResponse();
		}
		else if(!expected_resposeCode.equalsIgnoreCase("200"))
		{
					VerifyResponse();
		}
		else if(expected_resposeCode.equalsIgnoreCase("200"))
		{
			verifyputResponse(expected_values);
		}


		verifyStatusCode(expected_resposeCode);




	}

	private static void verifyputResponse(String expected_values) {

		
	}

	private static void verifyStatusCode(String expected_resposeCode) {
			String actualResponse= String.valueOf(response.getStatusCode());
			if (expected_resposeCode.equalsIgnoreCase(actualResponse))
			{
				Genericglue.scenario.log("Actual response code "+actualResponse+ "  MATCHED WITH Expected Response"+expected_resposeCode);

			}
			else
			{
				Assert.assertEquals(actualResponse,expected_resposeCode);
				String FailureDetails =("Actual response code "+actualResponse+ " not MATCHED WITH Expected Response"+expected_resposeCode);
				Genericglue.scenario.log(FailureDetails);

			}

	}

	


	@Before
	public void beforeClass(Scenario scenario) throws IOException {
		
		Genericglue.scenario = scenario;
		
	}
	
	
public static String applicationId() {

		
		return applicationaddId;

	}

public static String cloakedCust() {

		
		return cloakedCust;

	}

	public static void noadditionalfields(Object key, String apiName, Scenario scenario)
			throws FileNotFoundException, IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONParser parserBody = new JSONParser();
		boolean flag = false;
		Object obj = parser.parse(new FileReader("src/test/resources/jsonAllFields/" + apiName + ".txt"));
		JSONObject jsonObject = (JSONObject) obj;
		Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());

		for (Entry<String, Object> entry : flattenedJsonMap.entrySet()) {
			//System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());

			if (entry.getKey().equals(key)) {
				flag = true;
				//Assert.assertTrue(true);
			
				break;
			}

		}
		if (flag == false) {
			scenario.log(key.toString());
            scenario.attach(key.toString().getBytes(), "html/text", "");
			//System.out.println("The additional field is" + key);
			//Assert.assertTrue(false);

		}
	}
	public static TreeMap<String, String> jsonTomap(String operationId) throws FileNotFoundException, IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONParser parserBody = new JSONParser();
		Object obj = parser.parse(new FileReader(System.getProperty("user.dir")+"/WealthDashboard.json"));
		JSONObject jsonObject = (JSONObject) obj;
		Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());
		String path="";
		String resp="";
		String pathResponse="";
		TreeMap<String,String> pathAndResponse= new TreeMap<String,String>();

		for (Entry<String, Object> entry : flattenedJsonMap.entrySet()) {

			//System.out.println(entry.getKey());
			//System.out.println(entry.getValue());
			Object value = entry.getValue();
			String aq1=String.valueOf(value);
			if(aq1.equals(operationId) && entry.getKey().contains("operationId")) {
				//System.out.println(entry.getKey());
				String key1=entry.getKey();
				System.out.println(key1);
				String[] splitPath = key1.split("\\.");
				System.out.println(splitPath[1]);
				path=splitPath[1];

				pathResponse="paths."+path+"."+splitPath[2]+".parameters[6].schema.$ref";

				System.out.println(pathResponse+"  response");
			}

			if(entry.getKey().equals(pathResponse)) {
				Object response = entry.getValue();
				String res=String.valueOf(response);
				System.out.println(res);
				String[] splitResp = res.split("/");
				resp= splitResp[2];
				System.out.println(resp);
			}

		}
		pathAndResponse.put("path", path);
		pathAndResponse.put("response",resp);

		System.out.println(path+"  final");
		System.out.println(resp+"  final");
		return pathAndResponse;

	}
	public static void mandatoryfieldsnullorempty(Object key, Object value, String apiName)
			throws FileNotFoundException, IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONParser parserBody = new JSONParser();
		Object obj = parser.parse(new FileReader("src/test/resources/JsonResBody/" + apiName + ".txt"));
		JSONObject jsonObject = (JSONObject) obj;
		Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());

		for (Entry<String, Object> entry : flattenedJsonMap.entrySet()) {

			if (entry.getKey().equals(key)) {
				if (value.equals(null) || value.equals("")) {
					 System.out.println("mandatory field is null"+key +"and"+value);
					Assert.assertTrue(false);
					break;
				} else {

					Assert.assertTrue(true);
				//	System.out.println("mandatory fields are not null");

				}

			}

		}
	}
	  public static void copyContent(File a, File b) throws IOException {
		  FileInputStream in = new FileInputStream(a);
		  FileOutputStream out = new FileOutputStream(b, true);

		  try {
			  int n;
			  out.write(10);
			while ((n = in.read()) != -1) {
				  System.out.println(n);
				   out.write(n);
			  }
		  } catch (Exception e) {

		  }
		  finally {
			     if (in != null) {
					  in.close();
				 }
				      if (out != null) {
						  try {
							  out.close();
						  }
						  catch (Exception e)
						  {
							  System.out.println(e);
						  }
					  }

				}

	  }
	public static void readTemplate1(Set<Object> negativerecordsetMap) throws FileNotFoundException {
		File templateFile = new File(System.getProperty("user.dir")
				+ "/src/test/resources/Scenarios/InputFileTemplate.txt");
		Object[] TCName = negativerecordsetMap.toArray();
		String oldContent = "";
		BufferedReader reader = null;
		Stream<String> lines;

		try {
			reader = new BufferedReader(new FileReader(templateFile));
			//Reading all the lines of input text file into oldContent
			// String line = reader.readLine();
			String line = reader.readLine();
			while (line != null) {
				oldContent = oldContent + line + System.lineSeparator();
				line = reader.readLine();
			}


			for(Object tc_Name:TCName)
			{

				connection = fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
				String strQuery="Select * from Sheet1 where TC_Parent='"+tc_Name+"'";

				Recordset recordset=connection.executeQuery(strQuery);

				while (recordset.next())
				{
					ArrayList<String> ColCollection = recordset.getFieldNames();
					int size = ColCollection.size();
					for (int Iter = 0; Iter <= (size - 1); Iter++)
					{
						String ColName = ColCollection.get(Iter);
						String ColValue = recordset.getField(ColName);
						exelMap.put(ColName, ColValue);
					}
					String api =exelMap.get("API");
					String versionNo=exelMap.get("APIVersion").toString();
					String requestType=exelMap.get("RequestType");
					String tcName= exelMap.get("TCName");
					String tcParent = exelMap.get("TC_Parent");
					String flow = exelMap.get("Flow");
					String expectedFields= exelMap.get("ExpectedResponseFields") ;
					String expectedvalues= exelMap.get("ExpectedResponseValues") ;
					String executionType=exelMap.get("Execution_Type") ;
					String responseCode=exelMap.get("ExpectedResponseCode");


					String swaggerName = "@All \n Feature: "+api+"_"+versionNo;
					String filepath = System.getProperty("user.dir")+ "/src/test/resources/Project/SGTWAReport/Features/"+api+".feature";

					updateFile = new File(System.getProperty("user.dir")+ "/src/test/resources/Project/SGTWAReport/Features/"+api+".feature");
					copyContent(templateFile,updateFile);
					writeToFile(filepath, swaggerName);

					Map<String ,String > vMap= fillINMap1(api,requestType,tcName,tcParent,flow,expectedFields,expectedvalues,executionType,responseCode);

					java.nio.file.Path path = Paths.get(System.getProperty("user.dir")+"/src/test/resources/Project/SGTWAReport/Features/"+api+".feature");

					lines= Files.lines(path, Charset.forName("UTF-8"));
					List<String> replacedLines=lines.map(line1-> replaceTag(line1,vMap)).collect(Collectors.toList());
					Files.write(path,replacedLines,Charset.forName("UTF-8"));
					lines.close();


				}

			}

		}
		catch (Exception E) {

		}

	}



	private static void writeToFile(String filePath, String data) throws IOException {
		RandomAccessFile file = new RandomAccessFile(filePath, "rw");
		file.seek(0);
		file.write(data.getBytes());
		file.close();
	}
	public static Map<String,String> fillINMap1(String api, String requestType, String tcName,String tcParent, String flow, String expectedFields, String expectedvalues, String executionType, String responseCode) {



		Map<String ,String> map = new HashMap<>();

		map.put("API",api);
		map.put("RequestType",requestType);
		map.put("TCName",tcName);
		map.put("TC_Parent", tcParent);
		map.put("Flow", flow);
		map.put("Expected fields",expectedFields);
		map.put("Expected Value",expectedvalues);
		map.put("Execution Type",executionType);
		map.put("Expected ResponseCode",responseCode);




		return map;
	}

	public static void readTemplate(Set<Object> negativerecordsetMap) throws FileNotFoundException {
		File templateFile = new File(System.getProperty("user.dir")
				+ "/src/test/resources/Scenarios/InputFileTemplate.txt");
		File updateFile = new File(System.getProperty("user.dir")+ "/src/test/resources/Scenarios/inputUpdate.txt");
		Object[] TCName = negativerecordsetMap.toArray();
		String oldContent = "";
		BufferedReader reader = null;
		HashMap<String ,String>  exelMap= new  HashMap<String ,String>();
		try {
			reader = new BufferedReader(new FileReader(templateFile));
			//Reading all the lines of input text file into oldContent
			// String line = reader.readLine();
			String line = reader.readLine();
			while (line != null) {
				oldContent = oldContent + line + System.lineSeparator();
				line = reader.readLine();
			}
			for(Object tc_Name:TCName)
			{
				connection = fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
				String strQuery="Select * from Sheet1 where TC_Parent='"+tc_Name+"'";
				Recordset recordset=connection.executeQuery(strQuery);
				while (recordset.next())
				{
					   ArrayList<String> ColCollection = recordset.getFieldNames();
					   int size = ColCollection.size();
					   for (int Iter = 0; Iter <= (size - 1); Iter++)
					   		{
						   String ColName = ColCollection.get(Iter);
						   String ColValue = recordset.getField(ColName);
						   exelMap.put(ColName, ColValue);
					   		}
					      String api =exelMap.get("API");
					   	  String requestType=exelMap.get("RequestType")    ;
						  String tcName= exelMap.get("TCName") ;
						  String expectedFields= exelMap.get("ExpectedResponseFields") ;
						  String expectedvalues= exelMap.get("ExpectedResponseValues") ;
						  String executionType=exelMap.get("Execution_Type") ;
						  String responseCode=exelMap.get("ExpectedResponseCode");
						  String flow=exelMap.get("Flow");
						  String tcParent=exelMap.get("TC_Parent");
							copyContent(templateFile,updateFile);

						/*  Scanner sc2 = new Scanner(new FileInputStream(updateFile));
			String content = FileUtils.readFileToString(new File(System.getProperty("user.dir")+ "/src/test/resources/Scenarios/inputUpdate.txt"), "UTF-8");
				  content = content.replaceAll("API", api);
				  content = content.replaceAll("TCName", tcName);
				  content = content.replaceAll("Expected fields", expectedFields);
				  content = content.replaceAll("Expected Value", expectedvalues);
				      String line1=null;
				  while(sc2.hasNext()){
					   line1=sc2.nextLine().toString();
					   if (line1.contains("API"))
					   {

					   }*/
					Map<String ,String > vMap= fillINMap(api,requestType,tcName,expectedFields,expectedvalues,executionType,responseCode,flow,tcParent);

					java.nio.file.Path path = Paths.get(System.getProperty("user.dir")+"/src/test/resources/Scenarios/inputUpdate.txt");

							Stream<String> lines;
					try{
						lines= Files.lines(path, Charset.forName("UTF-8"));
						List<String> replacedLines=lines.map(line1 -> replaceTag(line1,vMap)).collect(Collectors.toList());
						Files.write(path,replacedLines,Charset.forName("UTF-8"));
						lines.close();
					}catch(Exception e)
					{

					}


				}
			}

		} catch (Exception E) {

		}
	}
	public static String replaceTag(String str , Map<String,String> map){
		for(Map.Entry<String ,String> entry :map.entrySet()){
					if (str.contains(entry.getKey()))
					{
						str=str.replace(entry.getKey(),entry.getValue());
					}
		}
		return str;
	}
	public static Map<String,String> fillINMap(String api, String requestType, String tcName, String expectedFields, String expectedvalues, String executionType, String responseCode, String flow, String tcParent) {

			Map<String ,String> map = new HashMap<>();
			map.put("API",api);
			map.put("RequestType",requestType);
			map.put("TCName",tcName);
			map.put("Expected fields",expectedFields);
			map.put("Expected Value",expectedvalues);
			map.put("Execution Type",executionType);
			map.put("Expected ResponseCode",responseCode);
			map.put("Flow",flow);
			map.put("TC_Parent",tcParent);

		return map;
	}

	public static Map<String, String>  ReadMappingFileWrite(String FieldName, String TestCase, String Change) throws FilloException, FileNotFoundException, IOException, ParseException {
	Field[] fields = RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest.class.getDeclaredFields();
	for(int i=0;i<fields.length;i++) {
		System.out.println(fields[i].getName());
	}

		String Randomdatas = null;
		
	//Dictionary<String, String> dict = new Hashtable<String, String>();
	HashMap<String,String> dict=new HashMap<String,String>();
	HashMap<String,String> secondmap=new HashMap<String,String>();
	
	
	Fillo fillo=new Fillo();
	Connection connection=fillo.getConnection(System.getProperty("user.dir").replace("\\", "/") + "\\metadata\\Specification_cardAuthorizationAccessToken_v1.0.0.xls");
	ArrayList<String> row = new ArrayList<String>();
	ArrayList<String>  data = new ArrayList<String>();
	for(int j=0; j<Fieldnames.length;j++) {
		FieldName = Fieldnames[j];
		System.out.println(FieldName);
			
	
	
	String strQuery="Select * from CardLinkageAct where Business_Element_name= '"+FieldName+"'";
	//System.out.println(strQuery);
	Recordset rs=connection.executeQuery(strQuery);
	int rocnt = rs.getCount();
	//System.out.println(rocnt);
	int colcnt = rs.getFieldNames().size();
	//System.out.println(colcnt);
	
	
	
		data = rs.getFieldNames();
		rs.moveNext();
		
	
	for (int i = 1; i <= colcnt-1; i++) {
		String Colname = data.get(i);
		//System.out.println(Colname);
		String value = rs.getField(i).value();
		//System.out.println(value);
		if(value == null) {
			dict.put(Colname, "");
			
		}else {
			dict.put(Colname, value);		
			
		}	
	}
	
	
	

switch(TestCase + "|" + Change) {
	
	case"Valid|Valid":
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			Randomdatas = RandomStringWitnLength(Integer.parseInt(dict.get("COLUMN_20")), Integer.parseInt(dict.get("COLUMN_21")));
			
		}
		break;
	case"Invalid|Min Length":
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			int minusvalue = Integer.parseInt(dict.get("COLUMN_20")) -2;
			Randomdatas = RandomStringWitnLength(minusvalue, Integer.parseInt(dict.get("COLUMN_21")));
			
		}
		break;
	case"Invalid|Max Length":
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			int plusvalue = Integer.parseInt(dict.get("COLUMN_21")) -2;
			Randomdatas = RandomStringWitnLength(Integer.parseInt(dict.get("COLUMN_20")), plusvalue);
			
		}
		break;
	case"Invalid|DataType":
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			dict.put("JSONDatatype","int");			
			Randomdatas =Integer.toString(RandomNumber());			
		}
		
		break;
	
	}
		secondmap.put(FieldName, Randomdatas);
		System.out.println(secondmap.get(FieldName));
		}
	 Connection connectionUpdate=fillo.getConnection(System.getProperty("user.dir").replace("\\", "/") + "/src/test/resources/testData/ProductDirectory.xlsx");
		//System.out.println(dict.get("Business_Element_name") + "','" + dict.get("COLUMN_20") + "','" + dict.get("COLUMN_21"));
		for(Entry<String, String> m : secondmap.entrySet()){   
			int writecount = 1;
		    System.out.println(m.getKey()+" "+m.getValue());  
		   // String InsertQuery = "INSERT INTO Sheet1("+m.getKey().replaceAll("\\s", "")+") VALUES('"
			//			+ m.getValue() + "')";
		    String UpdateQuery = "Update Sheet1 set "+m.getKey().replaceAll("\\s", "")+ "= '"+ m.getValue()+"' where TCID = 'TC_001'";
			//String InsertQuery = "INSERT INTO Sheet1(BusinessName"+writecount+",BusinessMin"+writecount+",BusinessMax"+writecount+") VALUES('"
				//	+ m.getValue() + "','" + m.getValue() + "','" + m.getValue() + "')";
			System.out.println(writecount+"st iteration Query " + UpdateQuery);
			connectionUpdate.executeUpdate(UpdateQuery);
			writecount++; 
			
		   }
			/*
			 * Enumeration names = dict.keys(); String keysva = (String)
			 * names.nextElement(); System.out.println(keysva);
			 * System.out.println(dict.get(keysva));
			
	
		Connection connectionUpdate=fillo.getConnection(System.getProperty("user.dir").replace("\\", "/") + "/src/test/resources/testData/ProductDirectory.xlsx");
		System.out.println(System.getProperty("user.dir").replace("\\", "/") + "/src/test/resources/testData/TestData.xlsx");
		//if(writecount==1) {	
			
		String InsertQuery = "INSERT INTO Sheet1(BusinessName"+writecount+",BusinessMin"+writecount+",BusinessMax"+writecount+") VALUES('"
				+ dict.get("Business_Element_name") + "','" + dict.get("COLUMN_20") + "','" + dict.get("COLUMN_21") + "')";
		connectionUpdate.executeUpdate(InsertQuery);
		writecount++; */
		//}
		
	


			
		//}
		/*
		 * else { String UpdateQuery =
		 * "UPDATE Sheet1 Set BusinessName"+writecount+" = '"+dict.get(
		 * "Business_Element_name")+"', BusinessMin"+writecount+" = '"+dict.get(
		 * "COLUMN_20")+"'," + "BusinessMax"+writecount+
		 * " = '"+dict.get("COLUMN_21")+"'";
		 * 
		 * connectionUpdate.executeUpdate(UpdateQuery);
		 * 
		 * }
		 */	
	
	
	return secondmap;
	 
	//rs.close();
	//connection.close();
	
	
	
}



//AgainReadexcelusing colNameBusiness - GrantType
public static String RandomStringWitnLength(int min, int max) {
	
	String NameRandom = RandomStringUtils.randomAlphabetic(min, max);
	//System.out.println(NameRandom);
	return NameRandom;
}
public static int RandomNumber() {
	Random random = new Random();
	int RNo = random.nextInt(9999999-1000000) + 65;	
	//System.out.println(RNo);
	return RNo;
}



	public static void WritePayload(String apiName) throws ClassNotFoundException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		Class classTemp = Class.forName("io.swagger.client.model." + apiName);
		//EasyRandom Easy = new EasyRandom();
		//Class className = Class.forName("io.swagger.client.model." + apiName);
		//className.getClass() pet = Easy.nextObject(className.getClass().class);
		//Class className = Class.forName("ab.pojo." + apiName);
		//String jsonString = mapper.writeValueAsString(className);
		//System.out.println(jsonString.replaceAll("-", ""));
		
		EnhancedRandom enhancedRandom = EnhancedRandomBuilder.aNewEnhancedRandomBuilder()
   	         .seed(123L)
   	         .objectPoolSize(100)
   	         .stringLengthRange(19, 19)
   	         .collectionSizeRange(1, 10)
   	         .scanClasspathForConcreteTypes(true)
   	         .randomize(Integer.class, new IntegerRangeRandomizer(0, 10000000))
   	         .build();
		String jsonString = mapper.writeValueAsString(enhancedRandom.nextObject(classTemp, "contentPublishedDate"));
		
		
	      //contentPublishedDate
	      
	      System.out.println(jsonString.replaceAll("null", "\"1992-01-01\""));
		
		File file = new File("src/test/resources/Payloads/" + apiName + ".txt");
		
		try {
			
			file.createNewFile();
			if (result) // test if successfully created a new file
			{
				System.out.println("file created " + file.getCanonicalPath()); // returns the path string
			} else {
				System.out.println("File already exist at location: " + file.getCanonicalPath());
			}
		} catch (IOException e) {
			e.printStackTrace(); // prints exception if any
		}
		FileWriter fw;
		try {
			fw = new FileWriter(("src/test/resources/Payloads/"+apiName+".txt"));
			
			fw.write(jsonString);
			
			fw.flush();
			fw.close();
		}
		 catch (IOException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 
    		
    	
    
	public static void payload(String key, String value,String apiName) throws FileNotFoundException, IOException, ParseException {
		//String jsonString = null;
		
		JSONParser parser = new JSONParser();
		DataProvider readdata = new DataProvider();

		/*try {
			
			StringBuilder json = new StringBuilder();
			FileReader path = new FileReader("src/test/resources/Payloads/"+apiName+".txt");
			   
			        try {
			            BufferedReader br = new BufferedReader(path);
			            String line;
			            while ((line = br.readLine()) != null) {
			            	json.append(line);
			            }
			            br.close();
			        } catch (Exception e) {
			            e.printStackTrace();
			        }
			      // System.out.println(json);
			    
			        
	
			      //  Thread.sleep(250);
			        Object  obj =parser.parse(json.toString()); */
			        
			Object obj = parser.parse(new FileReader("src/test/resources/Payloads/"+apiName+".txt"));
		//Object obj = parser.parse(readdata.extractExceldata(Genericglue.testCaseID(), Genericglue.sheetName(),Genericglue.workbook()).get("Payload").toString());

			JSONObject jsonObject = (JSONObject) obj;

			// Put above JSON content to crunchify.txt file and change path location

			// JsonFlattener: A Java utility used to FLATTEN nested JSON objects
			// String flattenedJson = JsonFlattener.flatten(jsonObject.toString());

			//Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());
			Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());
			
			flattenedJsonMap.entrySet().parallelStream().forEach(S->{
						String jsonString = null;
						
						if (S.getKey().equals(key)) {
							

							flattenedJsonMap.replace(S.getKey(), value).toString();

							Gson gson = new Gson();
							jsonString = gson.toJson(flattenedJsonMap);

							String nestedJson = JsonUnflattener.unflatten(jsonString);
						//System.out.println("\n=====Unflatten it back to original JSON===== \n" + nestedJson);

							//DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(), nestedJson);
							FileWriter fw;
							try {
								fw = new FileWriter(("src/test/resources/Payloads/"+apiName+".txt"));
								
								fw.write(nestedJson);
								
								fw.flush();
								fw.close();
								
					
							}
							 catch (IOException  e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						

						} else {
						//System.out.println("Key : is not  Displaying");
						}	
						
					}
					
					
					
					);
	
			

			/*for (Entry<String, Object> entry : flattenedJsonMap.entrySet()) {
				//System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());

				if (entry.getKey().equals(key)) {

					flattenedJsonMap.replace(entry.getKey(), value).toString();

					Gson gson = new Gson();
					jsonString = gson.toJson(flattenedJsonMap);

					String nestedJson = JsonUnflattener.unflatten(jsonString);
				//System.out.println("\n=====Unflatten it back to original JSON===== \n" + nestedJson);

					//DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(), nestedJson);
					FileWriter fw=new FileWriter("src/test/resources/Payloads/"+apiName+".txt");
					fw.write(nestedJson);
					Thread.sleep(2000);
					fw.flush();
					fw.close();
					break;

				} else {
				//System.out.println("Key : is not  Displaying");
				}

			}*/

			// Unflatten it back to original JSON

		
		
	}

	public String dbvalues(String table,String URN,String columnvalue,Scenario scenario) throws Exception
	{
		String value = null;
		
		Properties pro1 = getproperty.readProperties("DBQuery");
	
		if(table.equals("CI_APPLICATIONID"))
		{
		//HashMap<String, Object> hmAPPLICATIONID = dbconnection.connectDBConnection(pro1.getProperty("CI_APPLICATIONID"),"E331YW127274");
		HashMap<String, Object> hmAPPLICATIONID = dbconnection.connectDBConnection(pro1.getProperty(table),URN,scenario);
		 BigDecimal APPLICATIONID_Decimal = (BigDecimal) hmAPPLICATIONID.get("APPLICATION_ID");
		 APPLICATIONID=APPLICATIONID_Decimal.toString();
		
		}
		else
		{
		//HashMap<String, Object> Name = dbconnection.connectDBConnection(pro1.getProperty("CI_CUSTOMER_TXN"),"20200822000028181");
		HashMap<String, Object> Name = dbconnection.connectDBConnection(pro1.getProperty(table),APPLICATIONID,scenario);
		
		value =  (String) Name.get(columnvalue);
		
		System.out.println(value);
		
		
		}
		return value;
	}
	public  ArrayList<String> listdbvalues(String table,String URN,String columnvalue,Scenario scenario) throws Exception
	{
		
		
		ArrayList<String> columnresult = null;
		
		Properties pro1 = getproperty.readProperties("DBQuery");
	
		if(table.equals("CI_APPLICATIONID"))
		{
		//HashMap<String, Object> hmAPPLICATIONID = dbconnection.connectDBConnection(pro1.getProperty("CI_APPLICATIONID"),"E331YW127274");
			APPLICATIONID = dbconnection.getResult(pro1.getProperty(table),URN,columnvalue,scenario).get(0);
		
				// BigDecimal APPLICATIONID_Decimal = (BigDecimal)alAPPLICATIONID.get(0).toString();
		 //APPLICATIONID=APPLICATIONID_Decimal.toString();
		
		}
		else
		{
		//HashMap<String, Object> Name = dbconnection.connectDBConnection(pro1.getProperty("CI_CUSTOMER_TXN"),"20200822000028181");
			 columnresult = dbconnection.getResult(pro1.getProperty(table),APPLICATIONID,columnvalue,scenario);
		
		
		}
		return columnresult;
		
	}
	
	public static Response userhitsrequestwithAPI(String environment,String scope,String apiName, String requestType, Scenario scenario) throws Exception,IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException,NoSuchFieldException, FileNotFoundException, IOException, ParseException, FilloException {
		HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName, CurrentTestCaseName);
		
		
		Genericglue.scenario=scenario;

		
		
		      if(environment.equals("UAT2"))
		      {
		  RestAssured.keyStore("src/test/resources/Certificate/uat2normalmediationself.jks", "cip1234");
          RestAssured.trustStore("src/test/resources/Certificate/uat2normalmediationself.jks", "cip1234");
		      }
		      
		      
		      else {
		    RestAssured.useRelaxedHTTPSValidation();
		      }
		
		      RestAssured.baseURI = TestConfiguration.endpoint(environment);
		
		
		if (requestType.equalsIgnoreCase("POST")) {
			if(apiName.equalsIgnoreCase("ApplicationIPA")) {
				Thread.sleep(40000);
			}
			
			//request = given().log().all().headers((Map<String, Object>) TestConfiguration.header())
			 ByteArrayOutputStream requestStream = new ByteArrayOutputStream();
		     ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
		     PrintStream requestPrint = new PrintStream(requestStream);
		     PrintStream responsePrint = new PrintStream(responseStream);

		     RequestLoggingFilter requestLoggingFilter = new RequestLoggingFilter(LogDetail.ALL,false,requestPrint);;
		     ResponseLoggingFilter responseLoggingFilter = new ResponseLoggingFilter(LogDetail.ALL,false,responsePrint);
			RestAssured.filters(requestLoggingFilter,responseLoggingFilter);
			
			
			request = given()
					
					.log().all()//headers((Map<String, Object>) TestConfiguration.header())
					 .headers((Map<String, Object>)headerFieldvalues)
					//.queryParams((Map<String, Object>) TestConfiguration.commonQuery(apiName))
					.pathParams((Map<String, Object>) TestConfiguration.commonPath(apiDetails.get("response")))
					.body(Getpayloadbody(apiName));
			
			
			if(requestType.equalsIgnoreCase("POST")){
			
				response = request.when().post(apiDetails.get("path"));
				
			}
			
			//response.then().log().all();
			
			
			
			req = requestStream.toString();
			res = responseStream.toString();
			//System.out.println("response is" + res);
			String[] splittedresponse = res.split("\\[");
			//String seqnum = response.jsonPath().getString("contentList[0].sequenceNumber");
			//DataProvider.writeExcelDataOverride(Genericglue.testCaseID(),"SequenceNumber", seqnum);
			
			//response.jsonPath().get("relationships[0].cloakedRelationshipNumber").toString();     
	        scenario.log("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n");
	        //String cookie = Genericglue.cookiee.toString();
	        //scenario.log(cookie);
//	        scenario.log(req+"\n"+"COOKIE IN CICD"+cookie);
	        scenario.log(req);
	        scenario.log("\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n");
	        
	        scenario.log("\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n");
	      
	        scenario.log(res);
	     
	       
	        scenario.log("\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
	       
	       
	        requestStream.reset();
	       
	        responseStream.reset();
	        

//	    	Genericglue.fw.append("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n"
//	        +req
//	        +"\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n"
//	        +"\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n"
//	        +res
//	        +"\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
//	    	Thread.sleep(2000);
//	    	Genericglue.fw.flush();
	       
	        String responsefieldtoverify = excelmap.get("ExpectedResponseCode").toString();
               int i = response.statusCode();
			
			String statusCode=String.valueOf(i); 
	
			if(responsefieldtoverify.equals(statusCode)) {
				System.out.println("Status code Matched");
			}
			else {
				System.out.println("Fail " + apiName );
				System.out.println("Status code Not Matched");
			}
			if(apiName.equals("AUM") && statusCode.equals("200") )
			{
				
				try {
					cloakedCust = response.jsonPath().get("customers[0].cloakedCustomerID").toString();	
				}
				catch (Exception e)
				{
					cloakedCust = response.jsonPath().get("customers[0].cloakedCustomerID").toString();	
				}
			
			
			//  DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(),"Application_ID", cloakedCust, Genericglue.workbook());
			//	DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(),"controlFlowId", controlFlowId, Genericglue.workbook());
				
			}
			

		} 
		else if(requestType.equalsIgnoreCase("PUT")) {
			//request = given().log().all().headers((Map<String, Object>) TestConfiguration.header())
			 ByteArrayOutputStream requestStream = new ByteArrayOutputStream();
		     ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
		     PrintStream requestPrint = new PrintStream(requestStream);
		     PrintStream responsePrint = new PrintStream(responseStream);

		     RequestLoggingFilter requestLoggingFilter = new RequestLoggingFilter(LogDetail.ALL,false,requestPrint);;
		     ResponseLoggingFilter responseLoggingFilter = new ResponseLoggingFilter(LogDetail.ALL,false,responsePrint);
			RestAssured.filters(requestLoggingFilter,responseLoggingFilter);
			
			
			request = given()
					
					.log().all()//.headers((Map<String, Object>) TestConfiguration.commonHeader(apiName))
					//.queryParams((Map<String, Object>) TestConfiguration.commonQuery(apiName))
					.headers((Map<String, Object>)headerFieldvalues)
					.pathParams((Map<String, Object>) TestConfiguration.commonPath(apiDetails.get("response")))
					.body(Getpayloadbody(apiName));
			
			
			
			
			if(requestType.equalsIgnoreCase("PUT"))
			{
				
			response = request.when().put((apiDetails.get("path")));
			}
			else
			{
				response = request.when().post((apiDetails.get("path")));
				
			}
			
			//response.then().log().all();
			
			
			
			req = requestStream.toString();
			res = responseStream.toString();
			//System.out.println("response is" + res);
			//response.jsonPath().get("relationships[0].cloakedRelationshipNumber").toString();     
	        scenario.log("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n");
	        //String cookie = Genericglue.cookiee.toString();
	        //scenario.log(cookie);
//	        scenario.log(req+"\n"+"COOKIE IN CICD"+cookie);
	        scenario.log(req);
	      
	        scenario.log("\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n");
	        
	        scenario.log("\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n");
	      
	        scenario.log(res);
	     
	       
	        scenario.log("\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
	       
	       
	        requestStream.reset();
	       
	        responseStream.reset();
	        

//	    	Genericglue.fw.append("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n"
//	        +req
//	        +"\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n"
//	        +"\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n"
//	        +res
//	        +"\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
//	    	Thread.sleep(2000);
//	    	Genericglue.fw.flush();
	        
	        String responsefieldtoverify = excelmap.get("ExpectedResponseCode").toString();
               int i = response.statusCode();
			
			String statusCode=String.valueOf(i); 
	
			if(responsefieldtoverify.equals(statusCode)) {
				System.out.println("Status code Matched");
				DataProvider.WriteDataToExcel(APIName, "Status", "PASS", CurrentTestCaseName);
			}
			else {
				System.out.println("Status code Not Matched");
				DataProvider.WriteDataToExcel(APIName, "Status", "FAIL", CurrentTestCaseName);
			}

		}
		
		
		else if (requestType.equals("GET")) {
			OrchesInputFlag =0;
			//Getting Value of sequence number ; 123456789
			//Genericglue.ColName = SequenceNumber column name
			//String Queryparams = DataProvider.extractExceldataoverride(Genericglue.testCaseID()).get(Genericglue.ColName).toString();
			/*
			 * String QueryparamName = excelmap.get("OrchesInputtoAllApi").toString();
			 * if(!(QueryparamName==null)) { String[] Splittedinputs =
			 * QueryparamName.split(","); QueryparamName = Splittedinputs[OrchesInputFlag];
			 * }
			 */
			 OrchesInputFlag++;
			 ByteArrayOutputStream requestStream = new ByteArrayOutputStream();
		     ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
		     PrintStream requestPrint = new PrintStream(requestStream);
		     PrintStream responsePrint = new PrintStream(responseStream);

		     RequestLoggingFilter requestLoggingFilter = new RequestLoggingFilter(LogDetail.ALL,false,requestPrint);;
		     ResponseLoggingFilter responseLoggingFilter = new ResponseLoggingFilter(LogDetail.ALL,false,responsePrint);
			RestAssured.filters(requestLoggingFilter,responseLoggingFilter);
              
			/*
			 * request = given().log().all().headers((Map<String, Object>)
			 * TestConfiguration.commonHeader(apiName)) .queryParams((Map<String, Object>)
			 * TestConfiguration.commonQuery(apiName)) .pathParams((Map<String, Object>)
			 * TestConfiguration.commonPath(apiName));
			 */
			for (String key: OrchesInputKeyAndValue.keySet()) {
			
			request = given().log().all().queryParam(key, OrchesInputKeyAndValue.get(key)).headers((Map<String, Object>)headerFieldvalues);
					//.pathParams((Map<String, Object>) TestConfiguration.commonPath(apiDetails.get("response")));
			OrchesInputKeyAndValue.clear();
		
			}
			response = request.when().get(apiDetails.get("path"));

			//response.then().log().all();
			
			req = requestStream.toString();
			res = responseStream.toString();
	                
	        scenario.log("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n");
	  
	        scenario.log(req);
	      
	        scenario.log("\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n");
	        
	        scenario.log("\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n");
	      
	        scenario.log(res);
	     
	       
	        scenario.log("\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
	       
	       
	        requestStream.reset();
	       
	        responseStream.reset();
	        

//	    	Genericglue.fw.append("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n"
//	        +req
//	        +"\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n"
//	        +"\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n"
//	        +res
//	        +"\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
//	    	Thread.sleep(2000);
//	    	Genericglue.fw.flush();
			
            int i = response.statusCode();
			
			String statusCode=String.valueOf(i);
			if(apiName.equals("RelationShips") && statusCode.equals("200") )
			{
				
				try {
				
				if(Genericglue.testCaseID().equals("TC_002")) {
					DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(),"relationshipNumber", "fhfh%", Genericglue.workbook());
				}else if(Genericglue.testCaseID().equals("TC_003")){
					DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(),"relationshipNumber", "", Genericglue.workbook());
				}else
				{

					cloakedRelationship = response.jsonPath().get("relationships[0].cloakedRelationshipNumber").toString();
					System.out.println("Value is " +cloakedRelationship);
					
					DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(),"relationshipNumber", cloakedRelationship, Genericglue.workbook());
				}
				}
				catch (Exception e)
				{
				cloakedRelationship = response.jsonPath().get("relationships[0].cloakedRelationshipNumber").toString();	
				}
				
			
			//  DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(),"Application_ID", cloakedCust, Genericglue.workbook());
			//	DataProvider.writeExcelData(Genericglue.testCaseID(), Genericglue.sheetName(),"controlFlowId", controlFlowId, Genericglue.workbook());
				
			}
			
		}
		
		
		return response;
	}
	public static void readAPISpec(String apiName) throws FilloException, IOException, InterruptedException, ParseException {
		HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName,CurrentTestCaseName);
		String EndPointURL = excelmap.get("EndPointURL").toString();
		String Env = excelmap.get("Env").toString();
		Swagger swagger = new SwaggerParser().read(System.getProperty("user.dir")+ "\\WealthDashboard.json", null , false);
		String Reqtype = excelmap.get("RequestType").toString();
		String headerRequest = excelmap.get("Include_Headers").toString();
		if(headerRequest.equalsIgnoreCase("ALL")) {
			getAllHeaders(swagger,Reqtype);
		}
		if(headerRequest.equalsIgnoreCase("MANDATORY_HEADERS"))
		{
			getMandatoryHeaders(swagger,Reqtype);
		}
		if(headerRequest.equalsIgnoreCase("NONMANDATORY_HEADERS"))
		{
			getNonMandatoryHeaders(swagger,Reqtype);
		}

		if(!Reqtype.matches("GET|DELETE")) {		
		
		//Swagger swagger = new SwaggerParser().read("C:\\Users\\zeeshansait\\Downloads\\swagger-codegen\\WealthDashboard.json", null , false);

		Map<String, Model> definitions = swagger.getDefinitions();
		Model model = definitions.get(apiDetails.get("response"));


		Example example = ExampleBuilder.fromModel(apiDetails.get("response"), model, definitions, new HashSet<String>());
		SimpleModule simpleModule = new SimpleModule().addSerializer(new JsonNodeExampleSerializer());
		Json.mapper().registerModule(simpleModule);
		jsonPayload = Json.pretty(example);
		payloadKeyset = model.getProperties().keySet();
		Object[] namesArray = payloadKeyset.toArray();
			/*
			 * for (int i = 0; i < namesArray.length; i++) { System.out.println(i + ": " +
			 * namesArray[i]); }
			 */
		
		System.out.println(jsonPayload);
		}


		swaggerVersion = swagger.getInfo().getVersion();
		swaggerDescription = swagger.getInfo().getDescription();
		swaggerBasePath = swagger.getBasePath();
		swaggerPath = swagger.getPaths().keySet();
		switch (Reqtype) {
		case "POST":
			swaggerSummary = swagger.getPaths().get("/v1/customerWorkbench/wealthDashboard/newsAndInsights/retrieve").getPost().getSummary();
		break;	
		case "GET":
			swaggerSummary = swagger.getPaths().get("/v1/customerWorkbench/wealthDashboard/financialReadinessLevel").getGet().getSummary();
			break;	
		case "PUT":
			swaggerSummary = swagger.getPaths().get("/v1/customerWorkbench/wealthDashboard/actionChallenges").getPut().getSummary();
		break;
	}
			
		
				
		swaggerProduces = swagger.getProduces();
		swaggerSchemes = swagger.getSchemes().toString().replaceAll("[^a-zA-Z0-9]", " ").toLowerCase().trim();
		swaggerHost = swagger.getHost();
		
		BaseLiveHostURI = swaggerSchemes+"://"+swaggerHost+swaggerBasePath;
		if(Env.equals("LIVE")&& EndPointURL.isEmpty()) {
			DataProvider.WriteDataToExcel(APIName, "EndPointURL", BaseLiveHostURI, CurrentTestCaseName);
		}
		DataProvider.WriteDataToExcel(APIName, "APIVersion", swaggerVersion, CurrentTestCaseName);
		System.out.println(BaseLiveHostURI);
		

		
	}
	public static void mandatorybodyFIelds()
	{
		try {
			JsonParser parser = new JsonParser();
			FileReader file = new FileReader(System.getProperty("user.dir") + "\\WealthDashboard.json");
			JsonElement ele = parser.parse(file);
			JsonObject jobj = ele.getAsJsonObject();
			Boolean Payloadbodyrequired = checkRequiredtagpresentforBody(jobj);
			if (Payloadbodyrequired) {
				String as = payloadbodyMandatoryFields.getAsString();
				if (as.contains(",")) {
					String[] arr=as.split(",");
					for(String add:arr)
					{
						MandatoryPayloadBody.add(add);
					}

				} else {
					MandatoryPayloadBody.add(as);
				}
			}
		}
		catch(Exception e)
		{

		}
	}
	public static void headerDatatype()
	{
		try {
			JsonParser parser = new JsonParser();
			FileReader file = new FileReader(System.getProperty("user.dir") + "\\WealthDashboard.json");
			JsonElement ele = parser.parse(file);
			JsonObject jobj = ele.getAsJsonObject();
			JsonArray arr=jobj.getAsJsonObject("paths").getAsJsonObject(apiDetails.get("path")).getAsJsonObject(requestType.toLowerCase()).getAsJsonArray("parameters");

			arr.size();
			for(JsonElement ar:arr)
			{
				JsonObject JsonObj =ar.getAsJsonObject();
				String in=JsonObj.get("in").getAsString();
				if(in.contains("header"))
					{
					String a1 = JsonObj.get("name").getAsString();
					String b = JsonObj.get("type").getAsString();
					headerWithDatatype.put(a1,b);
				}
			}

			System.out.println("");
		}
		catch(Exception e)
		{
			System.out.println(e);

		}
	}
	private static Boolean checkRequiredtagpresentforBody(JsonObject jObj)  {
		Boolean present;
		try {
			present=true;
			JsonElement locele =jObj.getAsJsonObject("definitions").getAsJsonObject(apiDetails.get("response")).getAsJsonArray("required");
			//JsonElement locele =jObj.getAsJsonObject("definitions").getAsJsonObject("UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallengesRequest").getAsJsonArray("required");
			payloadbodyMandatoryFields=locele.getAsJsonArray();
			System.out.println();
		}
		catch(Exception e)
		{
			present=false;
		}

		return present;
	}

	private static void getMandatoryHeaders(Swagger swagger,String request) {
		try {
			Map<String, Path> paths = swagger.getPaths();
		//	Path pa = paths.get(TestConfiguration.requestpath(scope,APIName));
			Path pa = paths.get(apiDetails.get("path"));

			List<Parameter> as = null;

			if (request.equalsIgnoreCase("POST")) {
				as = pa.getPost().getParameters();

			}
			if (request.equalsIgnoreCase("GET")) {
				as = pa.getGet().getParameters();
			}
			if (request.equalsIgnoreCase("DELETE")) {
				as = pa.getDelete().getParameters();
			}
			if (request.equalsIgnoreCase("PUT")) {
				as = pa.getPut().getParameters();
			}
			for (Parameter p :as)
			{
				String in=p.getIn();
				if (in.equalsIgnoreCase("header"))
				{
					boolean required= p.getRequired();
					if(required) {
						String headerName = p.getName();
						header.add(headerName);
					}
				}

			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	private static void getAllHeaders(Swagger swagger,String request) {
		try {
			Map<String, Path> paths = swagger.getPaths();
			Path pa = paths.get(apiDetails.get("path"));
			List<Parameter> as = null;
			if (request.equalsIgnoreCase("POST")) {
				as = pa.getPost().getParameters();
			}
			if (request.equalsIgnoreCase("GET")) {
				as = pa.getGet().getParameters();
			}
			if (request.equalsIgnoreCase("DELETE")) {
				as = pa.getDelete().getParameters();
			}
			if (request.equalsIgnoreCase("PUT")) {
				as = pa.getPut().getParameters();
			}

			for (Parameter p :as)
			{
				String in=p.getIn();
				if (in.equalsIgnoreCase("header"))
				{
						String headerName = p.getName();
						header.add(headerName);
				}

			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}


	private static void getNonMandatoryHeaders(Swagger swagger,String request) {
		try {
			Map<String, Path> paths = swagger.getPaths();
			Path pa = paths.get(apiDetails.get("path"));
			List<Parameter> as = null;
			if (request.equalsIgnoreCase("POST")) {
				as = pa.getPost().getParameters();
			}
			if (request.equalsIgnoreCase("GET")) {
				as = pa.getGet().getParameters();
			}
			if (request.equalsIgnoreCase("DELETE")) {
				as = pa.getDelete().getParameters();
			}
			if (request.equalsIgnoreCase("PUT")) {
				as = pa.getPut().getParameters();
			}
			for (Parameter p :as)
			{
				String in=p.getIn();
				if (in.equalsIgnoreCase("header"))
				{
					boolean required= p.getRequired();
					if(!required) {
						String headerName = p.getName();
						header.add(headerName);
					}
				}

			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	public static void GeneratePojoFromSwagger() throws IOException {
	//To run bat file
			Process process = Runtime.getRuntime().exec("cmd /c Pojo.bat", null,
					new File("C:\\Users\\zeeshansait\\Downloads\\swagger-codegen"));
			
			//To Copy and paste the directory
			String source = "C:\\Users\\zeeshansait\\Downloads\\swagger-codegen\\Output\\src\\main\\java\\";
			File srcDir = new File(source);
			String destination = "C:\\Users\\zeeshansait\\Desktop\\API Framework Enahncements\\166317-cplnr-jee-rmkb-financept-functest (1)\\166317-cplnr-jee-rmkb-financept-functest\\src\\test\\java\\";
			File destDir = new File(destination);
			try {
				FileUtils.copyDirectory(srcDir, destDir);
			} catch (IOException e) {
				e.printStackTrace();
			}
}


public static void replaceTestCaseInFearureFile(HashMap<String,Object> ParametersFromExcel) throws InterruptedException, FilloException {
	   //File fileToBeModified = new File(System.getProperty("user.dir")
				//+ "/src/test/resources/Project/SGTWAReport/Features/wealthPortfolio.feature");
	File fileToBeModified = new File(System.getProperty("user.dir")
			+ "/src/test/resources/Scenarios/InputFile - Copy.txt");
        String oldContent = ""; 
        String newContent = "";
        
        
        BufferedReader reader = null;
        //if(TCCount==0) {
        TempTestCaseName = "TCName";
        TempTestCaseName1 = "TCName2";
        //}
        
        FileWriter writer = null;     
       
        try
        {
            reader = new BufferedReader(new FileReader(fileToBeModified));             
            //Reading all the lines of input text file into oldContent
             
            String line = reader.readLine();             
            while (line != null)             {
                oldContent = oldContent + line + System.lineSeparator();                 
                line = reader.readLine();
            }             
            //Replacing oldString with newString in the oldContent
            for (int i = 0; i < recordsetSize; i++) {
            	if(i==0) {
					/*
					 * excelMap=ReadTestCasesUsingName(TestCases.get(i)); APIName =
					 * excelMap.get("API").toString(); requestType =
					 * excelMap.get("RequestType").toString();
					 */
                //System.out.println(ParametersFromExcel.get("RequestType").toString());
                //System.out.println(ParametersFromExcel.get("Execution_Type").toString());
            	newContent += oldContent.replace("APIName", ParametersFromExcel.get("API").toString());
            	newContent = newContent.replace("RequestType", ParametersFromExcel.get("RequestType").toString());
            	newContent = newContent.replace("ExecutionType", ParametersFromExcel.get("Env").toString())+"\n";
            	
            	newContent = newContent.replace("ResponseCode", ParametersFromExcel.get("ExpectedResponseCode").toString());
            	newContent = newContent.replace("ResponseValue", ParametersFromExcel.get("ExpectedResponseValues").toString())+"\n";
            	
            	//System.out.println(newContent);
            	}
            	else {
            		String[] splittedcontent = oldContent.split("@");
            		//System.out.println(splittedcontent.length);
            		newContent += "@"+splittedcontent[2].replace("APIName", ParametersFromExcel.get("API").toString());
            		newContent = newContent.replace("RequestType", ParametersFromExcel.get("RequestType").toString());
                	newContent = newContent.replace("ExecutionType", ParametersFromExcel.get("Env").toString().trim())+"\n";
            		//newContent += "@"+splittedcontent[3].replace(TempTestCaseName, ParametersFromExcel.get("TCName").toString()) +"\n";
                	
                	newContent = newContent.replace("ResponseCode", ParametersFromExcel.get("ExpectedResponseCode").toString());
                	newContent = newContent.replace("ResponseValue", ParametersFromExcel.get("ExpectedResponseValues").toString())+"\n";
				}
			}
           // System.out.println(newContent);
            //String newContent = oldContent.replaceAll(TempTestCaseName, TCName[1].toString()); 
            //newContent = newContent.replaceAll(TempTestCaseName1, TCName[0].toString());
            //TempTestCaseName = TestCaseNameFromExcel;
            
            //Rewriting the input text file with newContent             
            writer = new FileWriter(fileToBeModified);             
            writer.write(newContent);

          
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
				//Closing the resources
                if(reader!=null &&writer!=null) {
					reader.close();

					writer.close();
				}
            } 
            catch (IOException e) 
            {
                e.printStackTrace();
            }
        }
    }
     

public static Set<Object> ReadTestCases1() throws FilloException{
	 HashMap<String,Object> excelMap= new HashMap<String, Object>();
	    
	    //Set<Object> recordsetMap = new HashSet<Object> ();
	    connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/APITestData - Copy.xlsx");
	   //connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");
	   //String strQuery="Select * from Sheet3 where TCName='" +testCaseId +"'";
	    
	 
	  String strQuery="Select * from Sheet3 where Execution_Control='Yes'";
	  Recordset recordset=connection.executeQuery(strQuery);
	  
	  while(recordset.next()) {
	      ArrayList<String> ColCollection = recordset.getFieldNames();
	      int size = ColCollection.size();
	      for (int Iter = 0; Iter <= (size - 1); Iter++) {
	          String ColName = ColCollection.get(Iter);
	          String ColValue = recordset.getField(ColName);          
	          excelMap.put(ColName, ColValue); 
	          if(ColName.toString().equals("TCName")) {
	        	  recordsetMap.add(ColValue);  
	        	  
	          }
	        
	      }
	  }
	return recordsetMap;
}

public static HashMap<String, Object> ReadTestCasesUsingName(Set<Object> TestCaseNameFromExcel) throws FilloException{
	
	String dup = null;
	int testcaseSize =0;
	
	ArrayList<Object> TestCases= new ArrayList<Object>(TestCaseNameFromExcel);
	
	testcaseSize = TestCases.size();
	
	System.out.println(testcaseSize);
	
	 for (int i = 0; i < testcaseSize; i++) {
		 
     	if(testcaseSize>0) {
     		
     		dup = TestCases.get(i).toString();
     		System.out.println(TestCases.get(i).toString());
	connection = fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/APITestData - Copy.xlsx");
    String strQuery="Select * from Sheet3 where TCName='" +TestCases.get(i).toString()+"'";
    
    
	Recordset recordset=connection.executeQuery(strQuery);
 
  while(recordset.next()) {

      ArrayList<String> ColCollection = recordset.getFieldNames();
      int size = ColCollection.size();
      for (int Iter = 0; Iter <= (size - 1); Iter++) {
          String ColName = ColCollection.get(Iter);
          String ColValue = recordset.getField(ColName);          
          valueMap.put(ColName, ColValue); 
          //System.out.println(valueMap);       
      }
      //APIName = valueMap.get("API").toString();
      //requestType = valueMap.get("RequestType").toString();
      //executionType = valueMap.get("Execution_Type").toString();      
     
  }
     	}
}
return valueMap;
}


public static HashMap<String, Object> readTestCaseValues(Set<Object> TestCaseNameFromExcel) throws FilloException{
	
	
	  int testcaseSize =0;
	  
	  ArrayList<Object> TestCases= new ArrayList<Object>(TestCaseNameFromExcel);
	  
	  testcaseSize = TestCases.size();
	 
	  for (int i = 0; i < testcaseSize; i++) {
			 
		  String tcName = TestCases.toString();
	     	if(testcaseSize>0) {
	     		connection = fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
	     		  String strQuery="Select TCName from Sheet1 where TCName='" +TestCases.get(i).toString().substring(0, 5)+"'";  
	     		  
	     		 Recordset recordset=connection.executeQuery(strQuery);
	     		 recordsetSize = recordset.getCount();
	     		 
	     		 
	     		 for(int j=0;j<recordsetSize;j++) {
	     			 int l=j+2;
	     			connection = fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
	     			String strQuery1="Select * from Sheet1 where TCName='" +TestCases.get(i).toString().substring(0, 5)+"'";
	     			
	     			Recordset recordset1=connection.executeQuery(strQuery1);
	     				     			 
	     			while(recordset1.next()) {

		     			      ArrayList<String> ColCollection = recordset1.getFieldNames();
		     			      int size = ColCollection.size();
		     			      for (int Iter = 0; Iter <= (size - 1); Iter++) {
		     			          String ColName = ColCollection.get(Iter);
		     			          String ColValue = recordset1.getField(ColName);          
		     			          fieldMap.put(ColName, ColValue); 
		     			      }
	     			 }
	     			
	     	 }
	      }
	/*for (int i = 0; i < testcaseSize; i++) {
		 
     	if(testcaseSize>0) {
     		
    connection = fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
    String strQuery="Select * from Sheet1 where TCName='" +TestCases.get(i).toString().substring(0, 5)+"'";
    */
    
	
	      
	      //APIName = fieldMap.get("API").toString();
	      //responseCode = fieldMap.get("ExpectedResponseCode").toString();
	      //responseValue = fieldMap.get("ExpectedResponseValues").toString();
	     	}   
	return fieldMap;
}

public static HashMap<String, Object> ReadTestCases(String TestCaseName) throws NoSuchMethodException, InvocationTargetException, NoSuchFieldException, Exception {
	OrchesInputFlag = 0;
	//GenerateReqFromParser
	//Version = public variable
	//parserReq - public variable
	//Key 
	
	//*******************Generating POJO from Swagger file
		//GeneratePojoFromSwagger();

	//************************
    HashMap<String,Object> excelMap= new HashMap<String, Object>();
    
    Set<Object> recordsetMap = new HashSet<Object> ();
	connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
   //connection= fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/"+Workbook+".xlsx");
   String strQuery="Select * from Sheet1 where TCName='" +TestCaseName +"'";
    
 
  //String strQuery="Select * from Sheet3 where Execution_Control='Yes'";
  Recordset recordset=connection.executeQuery(strQuery);
  System.out.println(recordsetMap);
  while(recordset.next()) {

      ArrayList<String> ColCollection = recordset.getFieldNames();
      int size = ColCollection.size();
      for (int Iter = 0; Iter <= (size - 1); Iter++) {
          String ColName = ColCollection.get(Iter);
          String ColValue = recordset.getField(ColName);          
          excelMap.put(ColName, ColValue); 
          if(ColName.toString().equals("TCName")) {
        	  recordsetMap.add(ColValue);      	  
        	  
          }
        
      }
      //System.out.println(recordsetMap.size());
      APIName = excelMap.get("API").toString();
      environment = excelMap.get("Env").toString();
      requestType = excelMap.get("RequestType").toString();
      scope = excelMap.get("Scope").toString();
      CurrentTestCaseName = excelMap.get("TCName").toString();

	 // generateExpectedResponse(CurrentTestCaseName);

	  // CurrentTestCaseName =TestCaseName;
      Genericglue.scenario.log("\r\n---------Current Running Test Case --------- " +CurrentTestCaseName+" ---------"+ "\r\n");
      Genericglue.scenario.log("\r\n---------Current Running API Name --------- " +APIName+" ---------"+ "\r\n");
      
    //************Read Swagger file using Swagger parser	
    	readAPISpec(APIName);
    //**************Write Payload in File*********************
    	WriteReqInFile();
      //*****************************
      //Generate API Random Test Data
     // GenerateAPIData();
    	///*********** no need for GET and DELETE
	  generateHeaderValues();
	  NegativeScenario_coverfor_Headers();

    	if(!requestType.matches("GET|DELETE")) {
    	GenerateAPIDataUsingParser();
    	}
      //*****************************
      //***************Triggering request
      NegativeScenario_coverfor_body(APIName);
      response = userhitsrequestwithAPI(environment, scope, APIName, requestType, Genericglue.scenario);
      //Assert the Responses
		//generateExpectedResponse(CurrentTestCaseName);
      if(requestType.matches("PUT")) {

		  VerifyResponse();
	  }

      //*****************************
      OrchesInputFlag++;
  }
      recordset.close();
      connection.close();

      return excelMap;
}
	private static String generatesucessResponse(String ApiName,String scope,String reqType,String resCode) throws FilloException, FileNotFoundException


	{
		JsonParser json = new JsonParser();
		FileReader file = new FileReader(System.getProperty("user.dir") + "\\WealthDashboard.json");
		JsonElement ele = json.parse(file);
		JsonObject jobj = ele.getAsJsonObject();
		JsonObject locele = jobj.getAsJsonObject("paths").getAsJsonObject(apiDetails.get("path"));//.getAsJsonObject(requestType);//.getAsJsonObject("responses");
		JsonObject locele1 = locele.getAsJsonObject(reqType).getAsJsonObject("responses").getAsJsonObject(resCode);
		String description = locele1.get("description").toString();
		return description;
	}

	private static void generateExpectedResponse(String ApiName,String scope,String reqType,String resCode) throws FilloException {

		try {
		//connection=fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/APITestData - Copy.xlsx");

/*				String Query3 = "UPDATE Sheet3 set ExpectedResponseCode='401' where TCName='"+currentTestCaseName+"'";
				connection.executeUpdate(Query3);
				String Query4 = "UPDATE Sheet3 set ExpectedResponseFields='Type,Code,Details' where TCName='"+currentTestCaseName+"'";
				connection.executeUpdate(Query4);*/
				JsonParser json = new JsonParser();
				FileReader file = new FileReader(System.getProperty("user.dir") + "\\WealthDashboard.json");
				JsonElement ele = json.parse(file);
				JsonObject jobj = ele.getAsJsonObject();
				JsonObject locele =jobj.getAsJsonObject("paths").getAsJsonObject(apiDetails.get("path"));//.getAsJsonObject(requestType);//.getAsJsonObject("responses");
				JsonObject locele1=locele.getAsJsonObject(reqType).getAsJsonObject("responses").getAsJsonObject(resCode);
				String description=locele1.get("description").toString();
				Document doc=Jsoup.parse(description);
				ArrayList<String> al = new ArrayList<String>();
				Elements el = doc.getElementsByTag("td");
				el.forEach(x-> al.add(x.toString().replace("<td>","").replace("</td>","")));
				int keySize = al.size()/2;
				int n=keySize;
				for(int i=0;i<n;i++)
				{
					invalidResponseDetails.put(al.get(i),al.get(keySize));
					keySize+=1;
				}

		}
		catch(Exception e)
		{
			connection.close();
		}
		finally {

		}
	}

	public static void NegativeScenario_coverfor_body(String apiName)
	{
		try {
			String ReqPayload=null;
			mandatorybodyFIelds();

			if ((MandatoryPayloadBody.size() == 0)) {
				System.out.println("No_Mandatory_body_requiredfields_for this" + APIName);
			}
			else {
				HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName, CurrentTestCaseName);
				List<String> Neagtivebody = new ArrayList<>();
				String Arr_HeaderFields = excelmap.get("RequiredBodyfields_ExcludedForNegativeScenario").toString();
				if (!Arr_HeaderFields.equalsIgnoreCase("")) {
					if (Arr_HeaderFields.contains(",")) {
						Neagtivebody = Arrays.asList(Arr_HeaderFields.split(","));
					} else {
						Neagtivebody.add(Arr_HeaderFields);
					}
					String requestPayload = excelmap.get("Request_Payload").toString();
					JsonParser parser = new JsonParser();
					JsonElement ele = parser.parse(requestPayload);
					JsonObject jobj = ele.getAsJsonObject();
					for (String removalkey : Neagtivebody) {

						jobj.remove(removalkey);
						JsonObject jobj1=jobj.getAsJsonObject();
						ReqPayload=jobj1.toString();
					}
					DataProvider.WriteDataToExcel(APIName, "Request_Payload", ReqPayload, CurrentTestCaseName);

				}

			}

		}catch(Exception e)
		{
			System.out.println(e);
		}
	}



private static void NegativeScenario_coverfor_Headers() throws FilloException {
		HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName, CurrentTestCaseName);
		List<String> NeagtiveHeaders = new ArrayList<>();
		String Arr_HeaderFields = excelmap.get("Headerfields_ExcludedForNegativeScenario").toString();
		if (!Arr_HeaderFields.equalsIgnoreCase("")) {
			if (Arr_HeaderFields.contains(",")) {
				NeagtiveHeaders = Arrays.asList(Arr_HeaderFields.split(","));
			} else {
				NeagtiveHeaders.add(Arr_HeaderFields);
			}
			for(String value :NeagtiveHeaders)
			{
				headerFieldvalues.remove(value);
			}


		}
		else {
			System.out.println("No Negtive validations present for headers");
		}
	}


	public static void generateHeaderValues() throws Exception {
		HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName,CurrentTestCaseName);
		List<Object> headerExcelvalues = new ArrayList<>();
		String Arr_HeaderFields = excelmap.get("HeaderFields&Values").toString();
			if(!Arr_HeaderFields.equalsIgnoreCase("")) {
				if (Arr_HeaderFields.contains("&")) {
					headerExcelvalues = Arrays.asList(Arr_HeaderFields.split("&"));
				} else {
					headerExcelvalues.add(Arr_HeaderFields);
				}
				int headersbySwag = header.size();
				int headersbyExcel = headerExcelvalues.size();
				if (headersbySwag == headersbyExcel) {
					MapHeadervaluesProvidedByExcel(headerExcelvalues);
				}
				else{
					throw new Exception("Provided fields and values are not matched with swagger");
				}
			}
			else
			{
				MapHeadervaluesbyGeneratingData1();
			}
	}

	private static void MapHeadervaluesProvidedByExcel(List<Object> headerExcelvalues) throws Exception {
		HashMap<String, Object> hashMap = new HashMap<>();
		for (Object obj : headerExcelvalues) {
			String temp= (String) obj;
			String[] arr_Temp=temp.split("=");
			hashMap.put(arr_Temp[0],arr_Temp[1]);
		}
		for(String headerFields:header)
		{
			Object obj=hashMap.get(headerFields);
			headerFieldvalues.put(headerFields,obj);
		}
	}
	public static void MapHeadervaluesbyGeneratingData1() {
		for(String str:header){
			if (!str.equalsIgnoreCase("Accept")&&!str.equalsIgnoreCase("Content-Type")) {
				String Datatype = headerWithDatatype.get(str);
				Object value = generateRansdomData(Datatype);
				headerFieldvalues.put(str, value);
			}
			else
			{

				headerFieldvalues.put(str,"application/json");
			}
		}
	}

	private static Object generateRansdomData(String datatype) {
		Object value = null;
		if (datatype.contains("string")) {
			value = RandomStringUtils.randomAlphabetic(5, 10);
		}
		else if(datatype.equalsIgnoreCase("integer"))
		{
			Random random = new Random();
			value = random.nextInt(56) + 65;
		}

		return value;
	}
	public static void MapHeadervaluesbyGeneratingData() {

		for(String str:header)
		{
			if(str.equalsIgnoreCase("Authorization"))
			{
				headerFieldvalues.put(str,"Authorization123456");
			}
			if(str.equalsIgnoreCase("uuid"))
			{
				headerFieldvalues.put(str,"432354678");
			}
			if(str.equalsIgnoreCase("Accept"))
			{
				headerFieldvalues.put(str,"application/json");
			}
			if(str.equalsIgnoreCase("client_id"))
			{
				headerFieldvalues.put(str,"123343");
			}
			if(str.equalsIgnoreCase("Content-Type"))
			{
				headerFieldvalues.put(str,"application/json");
			}
			if(str.equalsIgnoreCase("clientDetails"))
			{
				headerFieldvalues.put(str,"HKD");
			}







		}

	}



	public static void GenerateAPIData() throws InstantiationException, IllegalAccessException, ClassNotFoundException, FilloException, FileNotFoundException, IOException, ParseException, InterruptedException {
	  System.setProperty("ROW","1"); 
	  Class classTemp = Class.forName("io.swagger.client.model."+APIName);
	  Field[] fields = classTemp.getDeclaredFields();
	  System.out.println(fields[0].getName()); 
	  String Randomdatas = null;
      HashMap<String,String> dict=new HashMap<String,String>();
	  HashMap<String,String> secondmap=new HashMap<String,String>();
	  JSONParser parser = new JSONParser();
	  Object obj;
	  String ReqPayload = null;
	  Fillo fillo=new Fillo();
		Connection connection=fillo.getConnection(System.getProperty("user.dir")+"/metadata/Metadata.xls");
		System.out.println(System.getProperty("user.dir")+"/metadata/Metadata.xls");
		ArrayList<String> row = new ArrayList<String>();
		ArrayList<String>  data = new ArrayList<String>();
		for(int i=0;i<fields.length;i++) {
			System.out.println(fields[i].getName());
			//DataProvider.Metadataextract(fields[i].getName());
				
				  String
				  strQuery="Select * from MetaData where Business_Element_name='"+fields[i].getName()+"'"; 
				  //String strQuery="Select * from Sheet1";
				  
				  System.out.println(strQuery);
				  Recordset rs=connection.executeQuery(strQuery);
				  int rocnt = rs.getCount(); 
				  //System.out.println(rocnt); 
				  int colcnt =rs.getFieldNames().size(); 
				  //System.out.println(colcnt);		  
				  
				  data = rs.getFieldNames(); 
				  rs.moveNext();	  
				  
				  for (int j = 1; j <= colcnt-1; j++) { 
					  String Colname = data.get(j);
				  //System.out.println(Colname); 
					  String value = rs.getField(j).value();
				  //System.out.println(value); 
					  if(value == null) { dict.put(Colname, "");
				  
				  }
				  else {
					  dict.put(Colname, value);
				  
				  } 
				  }
				  if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
						Randomdatas = RandomStringWitnLength(Integer.parseInt(dict.get("COLUMN_20")), Integer.parseInt(dict.get("COLUMN_21")));
						
					}
				  secondmap.put(fields[i].getName(), Randomdatas);
					System.out.println(secondmap.get(fields[i].getName()));
					}
		System.out.println("First API MAP "+secondmap.entrySet());
		for(Entry<String, String> m : secondmap.entrySet()){  
			CommonUtility.payload(m.getKey(), m.getValue(), APIName);
		}
		//System.out.println(dict.get("Business_Element_name") + "','" + dict.get("COLUMN_20") + "','" + dict.get("COLUMN_21"));
		//for(Entry<String, String> m : secondmap.entrySet()){    
		  //  System.out.println(m.getKey()+" "+m.getValue());    
		   //}
		obj = parser.parse(new FileReader("src/test/resources/Payloads/"+APIName+".txt"));
		
		JSONObject jsonObject = (JSONObject) obj;

		//body = jsonObject.toJSONString();
		ReqPayload = jsonObject.toString();
		System.out.println("Payload body is  " +ReqPayload);
		 DataProvider.WriteDataToExcel(APIName, "Request_Payload", ReqPayload, CurrentTestCaseName);
		/*
		 * int writecount = 1; //System.out.println(dict.get("Business_Element_name") +
		 * "','" + dict.get("COLUMN_20") + "','" + dict.get("COLUMN_21"));
		 * for(Entry<String, String> m : secondmap.entrySet()){
		 * 
		 * System.out.println(m.getKey()+" "+m.getValue());
		 * DataProvider.WriteDataToExcel(APIName, "Request_Payload", ReqPayload);
		 * 
		 * writecount++;
		 * 
		 * }
		 */					


		
	  }
	  
	  public static void WriteReqInFile() {
		  try {
			  //System.out.println("src/test/resources/Payloads/"+requestType+"_"+APIName+"_"+swaggerVersion+".txt");
		      File ReqFile = new File("src/test/resources/Payloads/"+requestType+"_"+APIName+"_"+swaggerVersion+".txt");
		      if (ReqFile.createNewFile()) {
		        System.out.println("File created: " + ReqFile.getName());
		      } else {
		        //System.out.println("File already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		  try {
		      FileWriter myWriter = new FileWriter("src/test/resources/Payloads/"+requestType+"_"+APIName+"_"+swaggerVersion+".txt");
		      myWriter.write(jsonPayload);
		      myWriter.close();
		      
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	  }
	  public static void Updatepayload(String key, String value,String apiName) throws FileNotFoundException, IOException, ParseException {
			//String jsonString = null;
			
			JSONParser parser = new JSONParser();
			DataProvider readdata = new DataProvider();
			Object obj = parser.parse(new FileReader("src/test/resources/Payloads/"+requestType+"_"+apiName+"_"+swaggerVersion+".txt"));
			JSONObject jsonObject = (JSONObject) obj;
			Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());
			flattenedJsonMap.entrySet().parallelStream().forEach(S->
					{
							String jsonString = null;
							if (S.getKey().equals(key)) {
								flattenedJsonMap.replace(S.getKey(), value).toString();
								Gson gson = new Gson();
								jsonString = gson.toJson(flattenedJsonMap);
							String nestedJson = JsonUnflattener.unflatten(jsonString);
								FileWriter fw;
								try {
									fw = new FileWriter(("src/test/resources/Payloads/"+requestType+"_"+apiName+"_"+swaggerVersion+".txt"));
									fw.write(nestedJson);
									fw.flush();
									fw.close();
								}
								 catch (IOException  e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							

							} else {
							//System.out.println("Key : is not  Displaying");
							}	
							
						}
						
						);
			
		}

	  public static void GenerateAPIDataUsingParser() throws InstantiationException, IllegalAccessException, ClassNotFoundException, FilloException, FileNotFoundException, IOException, ParseException, InterruptedException {
		  
		  System.setProperty("ROW","1");
		  HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName,CurrentTestCaseName);
		  String InputField = excelmap.get("Inputfield").toString();
		  String Randomdatas = null;
	      HashMap<String,String> dict=new HashMap<String,String>();
		  HashMap<String,String> secondmap=new HashMap<String,String>();
		  JSONParser parser = new JSONParser();
		  Object obj;
		  String ReqPayload = null;
		  Fillo fillo=new Fillo();
		  Connection connection=fillo.getConnection(System.getProperty("user.dir")+"/metadata/Metadata.xls");
		  ArrayList<String> row = new ArrayList<String>();
		  ArrayList<String>  data = new ArrayList<String>();
		  Object[] PayloadKeys = payloadKeyset.toArray();
			for (int i = 0; i < PayloadKeys.length; i++) {
			    //System.out.println(i + ": " + PayloadKeys[i]);
			    
			    if(!PayloadKeys[i].equals(InputField)) {
			    	
			   
		 String sheetName=TestConfiguration.getSheetname(APIName);
		  
		  String  strQuery="Select * from "+sheetName+" where Business_Element_name='"+PayloadKeys[i]+"'";
					  //String strQuery="Select * from Sheet1";
					  
					  
					  Recordset rs=connection.executeQuery(strQuery);
					  int rocnt = rs.getCount(); 
					  //System.out.println(rocnt); 
					  int colcnt =rs.getFieldNames().size(); 
					  //System.out.println(colcnt);		  
					  
					  data = rs.getFieldNames(); 
					  rs.moveNext();	  
					  
					  for (int j = 1; j <= colcnt-1; j++) { 
						  String Colname = data.get(j);
					  //System.out.println(Colname); 
						  String value = rs.getField(j).value();
					  //System.out.println(value); 
						  if(value == null) { dict.put(Colname, "");
					  
					  }
					  else {
						  dict.put(Colname, value);
					  
					  } 
					  }
					  if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
							Randomdatas = RandomStringWitnLength(Integer.parseInt(dict.get("COLUMN_20")), Integer.parseInt(dict.get("COLUMN_21")));
							
						}					  
					  if(requestType.equals("PUT")){
							//replacing random datas in to previous api response
							Randomdatas = OrchesInputKeyAndValue.get(PayloadKeys[i]);	
							
					  secondmap.put(PayloadKeys[i].toString(), Randomdatas);
						//System.out.println(secondmap.get(PayloadKeys[i]));
						break;
						}
					  else {
						  secondmap.put(PayloadKeys[i].toString(), Randomdatas);
							//System.out.println(secondmap.get(PayloadKeys[i]));
					  }
			    }  					  
			 }
			//System.out.println("First API MAP "+secondmap.entrySet());
			for(Entry<String, String> m : secondmap.entrySet()){  
				CommonUtility.Updatepayload(m.getKey(), m.getValue(), APIName);
			}
		obj = parser.parse(new FileReader("src/test/resources/Payloads/"+requestType+"_"+APIName+"_"+swaggerVersion+".txt"));
			
			JSONObject jsonObject = (JSONObject) obj;
			ReqPayload = jsonObject.toString();
			//System.out.println("Payload body is  " +ReqPayload);
			 DataProvider.WriteDataToExcel(APIName, "Request_Payload", ReqPayload, CurrentTestCaseName);
		  }
	  
	  public static String Getpayloadbody(String apiName)throws NoSuchFieldException, FileNotFoundException, IOException, ParseException, FilloException, InterruptedException {
			HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName, CurrentTestCaseName);
			

			JSONParser parser = new JSONParser();
			Object obj = null;
			Map<Object, Object> map = new HashMap<>();

			 Object key;
			 Object value;
			 if(apiName.contains("Update")) {
				 obj = parser.parse(excelmap.get("Request_Payload").toString());
			 }
			 else {
				 obj = parser.parse(excelmap.get("Request_Payload").toString());
			 }
			JSONObject jsonObject = (JSONObject) obj;

			body = jsonObject.toString();
			System.out.println("API Payload Which is Going to Trigger with Random Generated Data " +body);
			return body;
		}
	public static void createTestcases_orchestration() throws FilloException {

		try {
			HashMap<String, Object> excelMap = new HashMap<String, Object>();
			HashMap<String, Object> excelMap1 = new HashMap<String, Object>();
			TreeMap<String,Integer> counts= new TreeMap<String,Integer>();
			int i = 0;
			connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/testData/APITestData - Copy.xlsx");
			String strQuery = "Select * from Sheet3 where Execution_Control='Yes' and Execution_Type='Orchestration'";
			Recordset recordset = connection.executeQuery(strQuery);
			while (recordset.next()) {
				ArrayList<String> ColCollection = recordset.getFieldNames();
				int size = ColCollection.size();
				for (int Iter = 0; Iter <= (size - 1); Iter++) {
					String ColName = ColCollection.get(Iter);
					String ColValue = recordset.getField(ColName);
					excelMap.put(ColName, ColValue);
				}
				String ActualtestcaseName=excelMap.get("TCName").toString();
				String	testCaseName = excelMap.get("TCName").toString();

				if(counts.containsKey(testCaseName)) {
					counts.put(testCaseName, counts.get(testCaseName)+1);
				}
				else {
					counts.put(testCaseName, 1);
				}

				testCaseName= testCaseName+"_Orchestration_"+counts.get(testCaseName);

				System.out.println(testCaseName);;
				APIName = excelMap.get("API").toString();
				environment = excelMap.get("Env").toString();
				requestType = excelMap.get("RequestType").toString();
				scope = excelMap.get("Scope").toString();
				//String Execution_Type = excelMap.get("Execution_Type").toString();
				String EndPointURL = excelMap.get("EndPointURL").toString();
				//String ExpectedResFields=excelMap.get("ExpectedResponseFields").toString();
				//String ExpectedResvalues=excelMap.get("ExpectedResponseValues").toString();
				//String Include_Headers=excelMap.get("Include_Headers").toString();
				//String HeaderFields_Values = excelMap.get("HeaderFields_Values").toString();
				//String Headerfields_ExcludedForNegativeScenario = excelMap.get("Headerfields_ExcludedForNegativeScenario").toString();
				String Inputfield=excelMap.get("Inputfield").toString();
				String InputFieldValue=excelMap.get("InputFieldValue").toString();
				//String RequiredBodyfields_ExcludedForNegativeScenario=excelMap.get("Headerfields_ExcludedForNegativeScenario").toString();
				String OrchesInputtoAllApi = excelMap.get("Orchestraction_Fields").toString();
				String ExpectedResponseFields = excelMap.get("ExpectedResponseFields").toString();
				String ExpectedResponseCode= excelMap.get("ExpectedResponseCode").toString();
				String ExpectedResponseValues=excelMap.get("ExpectedResponseValues").toString();
				//String Request_Payload=excelMap.get("Request_Payload").toString();
				//String Response_Payload=excelMap.get("Response_Payload").toString();
				connection = fillo.getConnection(System.getProperty("user.dir") + "/src/test/resources/TestcaseGenerator/TestcaseGenerator.xlsx");
				String queryOrches = "INSERT into Sheet1(Flow,TC_Parent,Execution_Type,TCName,API,RequestType,Scope,Env,EndPointURL,Inputfield,InputFieldValue,Orchestraction_Fields,ExpectedResponseFields,ExpectedResponseCode,ExpectedResponseValues,Include_Headers) VALUES('Positive','"+ActualtestcaseName+"','Orchestration','" + testCaseName +"','" + APIName + "','" + requestType + "','" + scope + "','" + environment + "','" + EndPointURL + "','" + Inputfield + "','" + InputFieldValue + "', '"+ OrchesInputtoAllApi+"','"+ExpectedResponseFields+"','"+ExpectedResponseCode+"','"+ExpectedResponseValues+"','ALL')";
				connection.executeUpdate(queryOrches);
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally {
			connection.close();

		}

	}
	  public static void VerifyResponse() throws FilloException, IOException, InterruptedException, ParseException {
		  ObjectMapper mapper = new ObjectMapper();
		   DataProvider.WriteDataToExcel(APIName, "Response_Payload", res, CurrentTestCaseName);
		   HashMap<String, Object> excelmap = DataProvider.ReadTestCasesUsingAPIName(APIName,CurrentTestCaseName);
		   res = response.getBody().prettyPrint().toString();

		   if(res.contains("contentList"))
		   {
		   		JSONParser jsonObject = new JSONParser();
		   		JSONObject json = (JSONObject)jsonObject.parse(res);
				   Map<String, Object> userData = jsonToMap(json);
			   //System.out.println(userData.get("contentList").getClass().getTypeName());	  
			   List<Object> list = (List<Object>) userData.get("contentList");	  
			   GsonBuilder gsonBuilder = new GsonBuilder();
			   Gson gson = gsonBuilder.create();		   
				String JSONObject = gson.toJson(list);		
				String firstapires = JSONObject.toString().replace("[", " ");
				res = firstapires.replace("]", " ");
				//System.out.println(res);

		   }
		   FinalResponseMap = mapper.readValue(res, new TypeReference<Map<String, Object>>() {				
           });
		   
		   String OrchesInput = excelmap.get("Orchestraction_Fields").toString();
		   if(!(OrchesInput.isEmpty()))
		   {
			   OrchesInputKeyAndValue.put(OrchesInput, FinalResponseMap.get(OrchesInput).toString()); 
		   
			/*
			 * String[] Splittedinputs = OrchesInput.split(","); OrchesInput =
			 * Splittedinputs[OrchesInputFlag]; InputValueToAllApi =
			 * FinalResponseMap.get(OrchesInput).toString();
			 */

		   
		   Genericglue.scenario.log("\r\n---------Input value to next api --------- " +OrchesInputKeyAndValue.get(OrchesInput)+" ---------"+ "\r\n");
		   }
			
		/*
		  for (String key: FinalResponseMap.keySet()) { System.out.println(key); }
		 */
			Object firstKey = FinalResponseMap.keySet().toArray()[0];
			Object valueForFirstKey = FinalResponseMap.get(firstKey);
			
			String responsefieldtoverify = excelmap.get("ExpectedResponseFields").toString();
			String responsevaluesfieldtoverify = excelmap.get("ExpectedResponseValues").toString();
			boolean responseValueMatch = false;
			boolean dynamicresponseValueMatch = false;
			if(responsefieldtoverify.equals("FullResponse")) {
				String[] ResfieldValues = responsevaluesfieldtoverify.split(",");									
					for(int j=0;j<ResfieldValues.length;j++) {
						if(ResfieldValues[j].contains("<")) {							
							//System.out.println(FinalResponseMap.keySet().toArray()[j]);
							String Dynamicresponse = ResfieldValues[j].replaceAll("[^a-zA-Z0-9]", " ").trim();
							String DynamicResponseValue = FinalResponseMap.get(Dynamicresponse).toString();
							//boolean restype = isNumeric(DynamicResponseValue);
							String restype = verifyDatatype(DynamicResponseValue);
							int reslength = getlengthofstring(DynamicResponseValue);
							HashMap<String, Object> MetadataMap = DataProvider.Metadataextract(Dynamicresponse);
							String Datatype = MetadataMap.get("XSD Datatype").toString();
							if(restype.equals(Datatype)){
								//System.out.println("Dynamic Response Field Name "+Dynamicresponse+ " And its type is  "+ restype+" And its length is "+reslength+ " Matched with Metadata sheet");
								Genericglue.scenario.log("DYNAMIC RESPONSE FIELD NAME "+Dynamicresponse+ " AND ITS TYPE IS  "+ restype+" AND ITS LENGTH "+reslength+ " MATCHED WITH METADATA SHEET");
								dynamicresponseValueMatch= true;
							}
							else {
								TestUtils.htmltable(Dynamicresponse, Datatype,restype,"FAIL", false);
								Assert.assertEquals(restype,Datatype);	
								TestUtils.htmlwrite(Genericglue.scenario);
								String FailureDetails ="DYNAMIC RESPONSE FIELD NAME "+Dynamicresponse+ " AND ITS TYPE IS  "+ restype+" AND ITS LENGTH "+reslength+ " NOT MATCHING WITH METADATA SHEET"; 
								Genericglue.scenario.log(FailureDetails);
								//System.out.println(FailureDetails);
								
								
								DataProvider.WriteDataToExcel(APIName, "FailureDetails", FailureDetails, CurrentTestCaseName);
							}
							
						}
						else {
							Object firstkeyset = FinalResponseMap.keySet().toArray()[j];
							String firstkeyvalue = FinalResponseMap.get(firstkeyset).toString();
							responseValueMatch = firstkeyvalue.equals(ResfieldValues[j].trim().toString());
							if(responseValueMatch) {
								//System.out.println("NON DYNAMIC RESPONSE FIELD NAME "+FinalResponseMap.keySet().toArray()[j]+ " AND ITS EXPECTED RESPONSE FIELD VALUE IS "+ResfieldValues[j]+ " MATCHED WITH ACTUAL RESPONSE "+FinalResponseMap.keySet().toArray()[j]);
								Genericglue.scenario.log("NON DYNAMIC RESPONSE FIELD NAME "+FinalResponseMap.keySet().toArray()[j]+ " AND ITS EXPECTED RESPONSE FIELD VALUE IS "+ResfieldValues[j]+ " MATCHED WITH ACTUAL RESPONSE "+firstkeyvalue);	
							}
								else {
									TestUtils.htmltable(FinalResponseMap.keySet().toArray()[j].toString(), firstkeyvalue,ResfieldValues[j],"FAIL", false);
									Assert.assertEquals(firstkeyvalue,ResfieldValues[j]);								  
									TestUtils.htmlwrite(Genericglue.scenario);
									String FailureDetails = "NON DYNAMIC RESPONSE FIELD NAME "+FinalResponseMap.keySet().toArray()[j]+ " AND ITS EXPECTED RESPONSE FIELD VALUE IS "+ResfieldValues[j]+ " NOT MATCHING WITH ACTUAL RESPONSE "+firstkeyvalue;
									Genericglue.scenario.log(FailureDetails);
									//System.out.println(FailureDetails);
									DataProvider.WriteDataToExcel(APIName, "FailureDetails", FailureDetails, CurrentTestCaseName);
									
								}
						}
					}
					
				
				if(responseValueMatch&&dynamicresponseValueMatch) {
					DataProvider.WriteDataToExcel(APIName, "Status", "PASS", CurrentTestCaseName);
				}
				else {
					DataProvider.WriteDataToExcel(APIName, "Status", "FAIL", CurrentTestCaseName);
				}
			}
			else {
				
		    String[] ResfieldNames = responsefieldtoverify.split(",");
			for(int i=0;i<=ResfieldNames.length-1;i++) {
				String[] ResfieldValues = responsevaluesfieldtoverify.split(",");

				
					if(ResfieldValues[i].contains("<")) {
						String Dynamicresponse = ResfieldValues[i].replaceAll("[^a-zA-Z0-9]", " ").trim();
						String DynamicResponseValue = FinalResponseMap.get(Dynamicresponse).toString();
						//boolean restype = isNumeric(DynamicResponseValue);
						int reslength = getlengthofstring(DynamicResponseValue);
						String restype = verifyDatatype(DynamicResponseValue);
					
						HashMap<String, Object> MetadataMap = DataProvider.Metadataextract(Dynamicresponse);
						String Datatype = MetadataMap.get("XSD Datatype").toString();
						if(restype.equals(Datatype)){
							dynamicresponseValueMatch = true;
							//System.out.println("Dynamic Response Field Name "+Dynamicresponse+ " And its type  "+ restype+" And its length is "+reslength+ " Matched with Metadata sheet");
							
							Genericglue.scenario.log("DYNAMIC RESPONSE FIELD NAME "+Dynamicresponse+ " AND ITS TYPE IS  "+ restype+" AND ITS LENGTH "+reslength+ " MATCHED WITH METADATA SHEET");
						}
						else {
							TestUtils.htmltable(Dynamicresponse, Datatype,restype,"FAIL", false);
							Assert.assertEquals(restype,Datatype);	
							TestUtils.htmlwrite(Genericglue.scenario);						
							String FailureDetails ="DYNAMIC RESPONSE FIELD NAME "+Dynamicresponse+ " AND ITS TYPE IS  "+ restype+" AND ITS LENGTH "+reslength+ " NOT MATCHING WITH METADATA SHEET";
							Genericglue.scenario.log(FailureDetails);
							//System.out.println(FailureDetails);
							DataProvider.WriteDataToExcel(APIName, "FailureDetails", FailureDetails, CurrentTestCaseName);
						}
						
						
					}
					else {


						responseValueMatch = FinalResponseMap.get(ResfieldNames[i].trim()).equals(ResfieldValues[i].trim());
						if(responseValueMatch) {
							Genericglue.scenario.log("NON DYNAMIC RESPONSE FIELD NAME "+ResfieldNames[i]+ " AND ITS EXPECTED RESPONSE FIELD VALUE IS "+ResfieldValues[i]+ " MATCHED WITH ACTUAL RESPONSE "+FinalResponseMap.get(ResfieldNames[i].trim()));
						//System.out.println("Non Dynamic Response Field Name "+ResfieldNames[i]+ " And its Expected Response Field Value is "+ResfieldValues[i]+ " Matched with Actual resonse "+FinalResponseMap.get(ResfieldNames[i]));
						}
						else {
							String FailureDetails = "NON DYNAMIC RESPONSE FIELD NAME "+ResfieldNames[i]+ " AND ITS EXPECTED RESPONSE FIELD VALUE IS "+ResfieldValues[i]+ " NOT MATCHING WITH ACTUAL RESPONSE "+FinalResponseMap.get(ResfieldNames[i].trim());
							Genericglue.scenario.log(FailureDetails);
							TestUtils.htmltable(ResfieldNames[i].toString(), FinalResponseMap.get(ResfieldNames[i]),ResfieldValues[i],"FAIL", false);
							TestUtils.htmlwrite(Genericglue.scenario);
							Assert.assertEquals(FinalResponseMap.get(ResfieldNames[i]),ResfieldValues[i]);					
													
							//String FailureDetails = "Non Dynamic Response Field Name "+ResfieldNames[i]+ " And its Expected Response Field Value is "+ResfieldValues[i]+ " Not Matching with Actual resonse "+FinalResponseMap.get(ResfieldNames[i]);
							DataProvider.WriteDataToExcel(APIName, "FailureDetails", FailureDetails, CurrentTestCaseName);
							
						}
							
					}
				
				
				
			}
			if(responseValueMatch&&dynamicresponseValueMatch) {
				DataProvider.WriteDataToExcel(APIName, "Status", "PASS", CurrentTestCaseName);
			}
			else {
				DataProvider.WriteDataToExcel(APIName, "Status", "FAIL", CurrentTestCaseName);
			}
			
			}
		 
		  
			
	 }
	  public static void GenerateMappings() {
		//To Copy and paste the directory
			String source = "C:\\Users\\senthilsy\\Downloads\\mappings\\";
			File srcDir = new File(source);
			String destination = System.getProperty("user.dir")+ "\\mappings";
			File destDir = new File(destination);
		if(srcDir.isDirectory()) {
		//srcDir.setLastModified(System.currentTimeMillis());
		File[] listFile = srcDir.listFiles();
		for(File file : listFile) {
		file.setLastModified(System.currentTimeMillis());
		}
		}
		try {
		FileUtils.copyDirectory(srcDir, destDir);
		} catch (IOException e) {
		e.printStackTrace();
		}
		}
	  
	  public static boolean isAlphaNumeric(String responsevalue) {
		  responsevalue.matches("[a-zA-Z0-9]+");
		return true;
		  
	  }
	  public static int getlengthofstring(String responsevalue) {
		  
		  int reslength = responsevalue.length();
		return reslength;
		  
	  }
	  public static boolean isNumeric(String strNum) {
		    if (strNum == null) {
		        return false;
		    }
		    try {
		        double d = Double.parseDouble(strNum);
		    } catch (NumberFormatException nfe) {
		        return false;
		    }
		    return true;
		}
	  public static String verifyDatatype(String value) {
		  if(value.matches(("^[A-Za-z]+"))) {			  
		  return "string";
		  }//else if(value.matches(("^[A-Za-z0-9]+"))) {
			 // System.out.println("alphanumeric");
		  //return "ALPHAMUMERIC";
		//  }
	  else if(value.matches(("^[0-9]+"))) {			  
		  return "Integer";
		  }else {
		  return "SPECIAL_CHARACTERS";
		  }
		  }
	  public static Map<String, Object> jsonToMap(JSONObject json) throws JSONException {
		    Map<String, Object> retMap = new HashMap<String, Object>();		    
		    retMap = toMap(json);
		  
		    return retMap;
		}
	  
	  public static Map<String, Object> toMap(JSONObject object) throws JSONException {
		    Map<String, Object> map = new HashMap<String, Object>();
		    Object value;

		    Iterator<String> keysItr = object.keySet().iterator();
		    while(keysItr.hasNext()) {
		        String key = keysItr.next();
		        value = object.get(key);
		        
		        if(value instanceof JSONArray) {
		            value = toList((JSONArray) value);
		            
		         // put every value list to Map
		            
		        }
		        
		        else if(value instanceof JSONObject) {
		            value = toMap((JSONObject) value);
		        }
		        map.put(key, value);
		        
		        
		    }
		    return map;
		}

		public static List<Object> toList(JSONArray array) throws JSONException {
			Map<String, Object> map = new HashMap<String, Object>();
		    List<Object> list = new ArrayList<Object>();
		    for(int i = 0; i < array.size(); i++) {
		        Object value = array.get(i);
		        if(value instanceof JSONArray) {
		            value = toList((JSONArray) value);
		        }

		        else if(value instanceof JSONObject) {
		            value = toMap((JSONObject) value);
		        }
		        
		        list.add(value);
		    }
		    //System.out.println(list);
		    
		   
		    return list;
		}
//
//	public static  void  logPrintOnReport() throws InterruptedException {
//		 req = requestStream.toString();
//         res = responseStream.toString();
//                
//        scenario.log("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n");
//  
//        scenario.log(req);
//      
//        scenario.log("\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n");
//        
//        scenario.log("\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n");
//      
//        scenario.log(res);
//     
//       
//        scenario.log("\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
//       
//       
//        requestStream.reset();
//       
//        responseStream.reset();
//
//		
//	}
//	



public static void storeLog() throws IOException, InterruptedException
{
	
	
   
   

//	Genericglue.fw.append("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n"
//    +req
//    +"\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n"
//    +"\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n"
//    +res
//    +"\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
//	Thread.sleep(2000);
//	Genericglue.fw.flush();
	
	
	/*
	Genericglue.fw.write("\r\n" + "----------------------------------------Request Data----------------------------------------" + "\r\n"
    +req
    +"\r\n" + "----------------------------------------End Request Data-----------------------------------" + "\r\n");
	Genericglue.fw.append("\r\n" + "----------------------------------------Response Data----------------------------------------" + "\r\n"
    +res
    +"\r\n" + "----------------------------------------End Response Data-----------------------------------" + "\r\n");
	Thread.sleep(2000);
	fw.flush();
	fw.close(); */
    
}

public static void main(String args[]) throws FilloException, ParseException, FileNotFoundException, IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
	//StoreValue();
	//RandomStringWitnLength();
//	RandomNumber();
//ReadMappingFileWrite("userContext", "Valid","");
//writeJsonstringtofile("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest");
	//writetoexcelusingapache();
	//Field[] fields = RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest.class.getDeclaredFields();
	//System.out.println(fields[0].getName());
	//System.out.println(fields[1].getName());
		/*
		 * String response = "HTTP/1.1 200 OK\r\n" +
		 * "Content-Type: application/json\r\n" +
		 * "Matched-Stub-Id: 2115b596-fad2-457b-9687-9cfcc857a320\r\n" +
		 * "Vary: Accept-Encoding, User-Agent\r\n" + "Content-Encoding: gzip\r\n" +
		 * "Transfer-Encoding: chunked\r\n" + "\r\n" +
		 * "{\"contentList\": [{\"sequenceNumber\": \"naser\",\"customerAssociatedTags\": null,\"photoImageUrl\": \"https://host.domain.com/PersonalisedContent/PersistREsources/image.jpg\",\"contentSource\": \"Citi\",\"contentTitle\": \"{{randomValue length=20 type='ALPHABETIC'}}\",\"typeOfContent\": \"{{randomValue length=8 type='ALPHABETIC'}}\",\"contentCategory\": \"{{randomValue length=8 type='ALPHABETIC'}}\",\"contentPublishedDate\": \"{{randomValue type='DATE'}}\",\"contentId\": \"{{randomValue length=10 type='NUMERIC'}}\",\"favouriteFlag\": true,\"uniqueReferenceId\": \"{{jsonPath request.body '$.uniqueReferenceId'}}\"}]}"
		 * ; String[] spillitedresponse = response.split("\\[");
		 * System.out.println(spillitedresponse[1]);
		 */
	//GenerateAPIData("io.swagger.client.model."+"RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest");
	//readAPISpec("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest");
	//WriteReqInFile();
	//GenerateMappings();
	//verifyDatatype("6774982374867");
	/*String testCase = "fddhjddkjdsdkdj 'TCName'";
	String result = "";
	String[] list = {"TC_01", "TC_02" , "TC_03"};
	for(int i=0; i<list.length;i++) {
		result += testCase.replace("TCName" , list[i]) + "\n";
		
	}
	System.out.println(result);*/
	String oldcontent = "@All\r\n" + 
			"Feature: APICases\r\n" + 
			"\r\n" + 
			"  \r\n" + 
			"  @APICases\r\n" + 
			"  Scenario: To Verify All the API cases runs in One click\r\n" + 
			"  Given Run APIcases using Swagger File for 'TCName'";
	String[] newcontent = oldcontent.split("@");
	System.out.println(newcontent[0]);
	System.out.println(newcontent[1]);
	System.out.println("@"+newcontent[2]);
	}


}