package ab.common;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

import javax.ws.rs.GET;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.math3.random.RandomData;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.extension.responsetemplating.ResponseTemplateTransformer;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
//import com.swagger.parser.SwaggerInflector;

import io.swagger.inflector.examples.ExampleBuilder;
import io.swagger.inflector.examples.models.Example;
import io.swagger.inflector.processors.JsonNodeExampleSerializer;
import io.swagger.models.Model;
import io.swagger.models.Response;
import io.swagger.models.Swagger;
import io.swagger.parser.SwaggerParser;
import io.swagger.util.Json;

public class WiremockTest {
	static Fillo fillo = new Fillo();
	static Connection connection;
	public static boolean success = false;
	public static boolean invalid = false;
	public static boolean unauthorized = false;
	public static WireMockServer wireMockServer;
	public static HashMap result = new HashMap();
	public static String reqToResParam = "uniqueReferenceId";
	public static String requestBodyPattern = "\"bodyPatterns\" : [";
	public static String queryStringPattern = "\"queryParameters\" : {";
	public static String responseTemplate = "{\r\n" + "  \"request\" : {\r\n" + "    \"urlPath\" : \"{{URI}}\",\r\n"
			+ "    \"method\" : \"{{METHOD}}\",\r\n" + " {{REQUEST}} \r\n" + "\r\n" + "	},\r\n"
			+ "  \"response\" : {\r\n" + "    \"status\" : 200,\r\n" + "	\"body\" : \"{{RESPONSE}}\",\r\n"
			+ "	\"headers\": {\r\n" + "            \"Content-Type\": \"application/json\"\r\n" + "        },\r\n"
			+ "	\"transformers\": [\"response-template\"]\r\n" + "  }\r\n" + "}";
	public static String[] dynamicFields = { "uniqueReferenceId", "sequenceNumber", "contentId", "nextChallengeId" };

	public static void main(String[] args) throws JsonProcessingException, FilloException {
		//HashMap map = generatedSwaggerResponses(
			//	"C:\\Users\\syednaseru\\Download_C_Drive\\Download_C_Drive\\swagger-codegen\\WealthDashboard.json");
		//HashMap map = generatedSwaggerResponses(
				//"C:\\Users\\syednaseru\\Downloads\\TWA-8499.json");
		File folder = new File(System.getProperty("user.dir") + "/swaggers");
		File[] listOfFiles = folder.listFiles();
		for (File file : listOfFiles) {
			if (file.isFile() && file.getName().endsWith(".json")) {
				
				HashMap map = generatedSwaggerResponses(file.getAbsolutePath());

			}
		}
		//C:\Users\syednaseru\Downloads\TWA-8499.json
		/*
		HashMap firstEntry = (HashMap) map
				.get("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardFinancialReadinessLevel");
		System.out.println(firstEntry.toString());
		String RequestType = "POST";
		String Headerfields_ExcludedForNegativeScenario = "";
		wireMockServer = new WireMockServer(options().port(8083).extensions(new ResponseTemplateTransformer(false)));
		if (Headerfields_ExcludedForNegativeScenario.isEmpty()) {
			wireMockServer.start();
			wireMockServer.stubFor(get(urlEqualTo("/some/thing"))
					.willReturn(aResponse().withStatus(200).withStatusMessage("Everything was just fine!")
							.withHeader("Content-Type", "text/plain").withBody((String) firstEntry.get("200"))));

			wireMockServer.saveMappings();
			wireMockServer.stop();

		}
*/
	}

	public static HashMap generatedSwaggerResponses(String swaggerPath) throws JsonProcessingException, FilloException {
		Swagger swagger = new SwaggerParser().read(swaggerPath, null, false);
		String operationId = "null";
		String simpleRef = null;
		String basePath = swagger.getBasePath();
		Map<String, Response> responses = null;
		//result = new HashMap();
		SimpleModule simpleModule = new SimpleModule().addSerializer(new JsonNodeExampleSerializer());
		Json.mapper().registerModule(simpleModule);
		String requestTemplate = "";
		Configuration configuration = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
				.mappingProvider(new JacksonMappingProvider()).build();
		String[] strs = { "uniqueReferenceId", "sequenceNumber", "customerAssociatedTags", "contentSource",
				"contentTitle", "contentPublishedDate", "contentId" };
		List list = Arrays.asList(strs);
		List dynamicParamList = Arrays.asList(dynamicFields);
		Set<String> paths = swagger.getPaths().keySet();
		Iterator pathIterator = paths.iterator();
		while (pathIterator.hasNext()) {
			List<io.swagger.models.parameters.Parameter> parameters;
			String jsonTemplate = responseTemplate;
			String path = pathIterator.next().toString();
			System.out.println(path);
			String apiPath = basePath + path;
			String method = getMethod(path, swaggerPath);
			jsonTemplate = jsonTemplate.replace("{{METHOD}}", method);
			jsonTemplate = jsonTemplate.replace("{{URI}}", apiPath);

			System.out.println(method);
			if (method.contentEquals("POST")) {
				parameters = swagger.getPaths().get(path).getPost().getParameters();
				responses = swagger.getPaths().get(path).getPost().getResponses();
				operationId = swagger.getPaths().get(path).getPost().getOperationId();
			} else if (method.contentEquals("PUT")) {
				parameters = swagger.getPaths().get(path).getPut().getParameters();
				responses = swagger.getPaths().get(path).getPut().getResponses();
				operationId = swagger.getPaths().get(path).getPut().getOperationId();
			} else if (method.contentEquals("GET")) {
				parameters = swagger.getPaths().get(path).getGet().getParameters();
				responses = swagger.getPaths().get(path).getGet().getResponses();
				operationId = swagger.getPaths().get(path).getGet().getOperationId();
			} else {
				parameters = swagger.getPaths().get(path).getDelete().getParameters();
				responses = swagger.getPaths().get(path).getDelete().getResponses();
				operationId = swagger.getPaths().get(path).getDelete().getOperationId();
			}
			if(operationId == null) {
				operationId = "";
			}
			// System.out.println(responses.keySet().toString());
			System.out.println("sheet name is: " + getSheetname(operationId));
			if (!getSheetname(operationId).isEmpty()) {
				Iterator<String> respCodeItr = responses.keySet().iterator();
				HashMap respCodeMap = new HashMap();
				while (respCodeItr.hasNext()) {
					String responseCodeKey = respCodeItr.next();
					if (!(responses.get(responseCodeKey).getResponseSchema() == null)) {
						if (!responseCodeKey.matches("200")) {
							// System.out.println(responses.get(responseCodeKey).getDescription());

							Model schema = responses.get(responseCodeKey).getResponseSchema();

							String reference = schema.getReference();
							simpleRef = reference.replaceFirst(".*/", "");
							// System.out.println("reference is " + simpleRef);
							Map<String, Model> definitions = swagger.getDefinitions();
							Model retrieveCustomer = definitions.get(simpleRef);

							Example example = ExampleBuilder.fromModel(simpleRef, retrieveCustomer, definitions,
									new HashSet<String>());
							// System.out.println("Response body is " + Json.pretty(example));
							Set<String> keyset = retrieveCustomer.getProperties().keySet();
							// System.out.println(keyset.toString());

							Document doc = Jsoup.parse(responses.get(responseCodeKey).getDescription());
							HashMap errorMap = new HashMap();

							Element table = doc.select("table").get(0); // select the first table.
							Elements rows = table.select("tr");
							Element row = rows.get(0);
							Element row1 = rows.get(1);
							Elements cols = row.select("td");
							Elements cols1 = row1.select("td");
							// System.out.println(cols.get(0).text());
							errorMap.put(cols.get(0).text().toLowerCase(), cols1.get(0).text());
							errorMap.put(cols.get(1).text().toLowerCase(), cols1.get(1).text());
							errorMap.put(cols.get(2).text().toLowerCase(), cols1.get(2).text());

							// System.out.println(errorMap.toString());
							Iterator<String> itr = keyset.iterator();

							while (itr.hasNext()) {
								String tmp = itr.next();
								if (errorMap.get(tmp) == null) {
									errorMap.put(tmp, "");
								}
							}

							// System.out.println(errorMap.toString());
							String json = new ObjectMapper().writeValueAsString(errorMap);
							// System.out.println(json);
							// respCodeMap.put(responseCodeKey, json.replace("\"", "\\\""));
							respCodeMap.put(responseCodeKey, json);

							// System.out.println(result.toString());
						} else {
							Model schema = responses.get("200").getResponseSchema();

							String reference = schema.getReference();
							simpleRef = reference.replaceFirst(".*/", "");
							// System.out.println("reference is " + simpleRef);
							Map<String, Model> definitions = swagger.getDefinitions();
							Model retrieveCustomer = definitions.get(simpleRef);

							Example example = ExampleBuilder.fromModel(simpleRef, retrieveCustomer, definitions,
									new HashSet<String>());
							// System.out.println("Response body is " + Json.pretty(example));
							Set<String> keyset = retrieveCustomer.getProperties().keySet();
							// System.out.println(keyset);
							String responseString = Json.pretty(example).toString();
							String finalResponse = responseString;
							// JsonNode updatedJson =
							// (JsonNode)JsonPath.using(configuration).parse(responseString).set("$.contentList[0].sequenceNumber",
							// "naser1234").json();
							DocumentContext doc = null;
							Iterator listIterator;
							if (getSheetname(operationId).contentEquals("RetrieveCustomerWorkbench")) {
								listIterator = list.iterator();
							} else {
								listIterator = retrieveCustomer.getProperties().keySet().iterator();
							}
							while (listIterator.hasNext()) {

								String param = listIterator.next().toString();
								// System.out.println(param);
								// if(param.contentEquals(reqToResParam)) {

								// }
								if (isDynamicResponseField(param)) {
									HashMap hashMap = Metadataextract(param, getSheetname(operationId));
									String randomValue = getWiremockProperty(hashMap.get("COLUMN_20").toString(),
											getDatatype(hashMap.get("JSONDatatype").toString()));
									String jsonPath = "$." + hashMap.get("Json element name").toString();
									// System.out.println(randomValue);
									// System.out.println(jsonPath);
									if (getDatatype(hashMap.get("JSONDatatype").toString()).contains("INTEGER")) {
										String tmpString = JsonPath.parse(responseString).read(jsonPath).toString()
												+ ",";
										// doc = JsonPath.parse(responseString).set(jsonPath, randomValue);
										finalResponse = finalResponse.replace(tmpString, randomValue + ",");
									} else {	
										String tmpString = "\""
												+ JsonPath.parse(responseString).read(jsonPath).toString() + "\"";
										// doc = JsonPath.parse(responseString).set(jsonPath, randomValue);
										finalResponse = finalResponse.replace(tmpString, "\"" + randomValue + "\"");
									}
								}
								// finalResponse = finalResponse.replaceAll("\"", "");

								// responseString = doc.json().toString();
							}
							// System.out.println("String respnse is: "+finalResponse.trim().replace("\"",
							// "\\\""));
							// System.out.println("String respnse is: " +
							// finalResponse.trim().replace("\\s", ""));
							// finalResponse = finalResponse.trim().replace("\"", "\\\"");
							finalResponse = finalResponse.trim();
							String[] records = finalResponse.split("\\n");
							String finalMapping = "";
							for (String record : records) {
								finalMapping += record.trim().replaceAll("\\r", "").trim();

								// System.out.println("record is "+ finalMapping);
							}
							respCodeMap.put(responseCodeKey, finalMapping.replaceAll("//", "/"));

						}
					} else {
						respCodeMap.put(responseCodeKey, "");
					}

				}
				result.put(operationId, respCodeMap);
			}
			// System.out.println(result.toString());

		}
		System.out.println(result.toString());

		return result;
	}

	public static String getSheetname(String operationId) {
		if (operationId.contentEquals("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsights")) {
			return "RetrieveCustomerWorkbench";
		} else if (operationId
				.contentEquals("UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallenges")) {
			return "UpdateCustomerWorkbench";
		} else if (operationId
				.contentEquals("RetrieveCustomerWorkbenchOperatingSessionWealthDashboardFinancialReadinessLevel")) {
			return "financialReadinessLevel";
		}
		else if (operationId
				.contentEquals("RetrieveApplicationDemographicsDetails")) {
			return "RetrieveApplicationDemographics";
		}else {
			return "";
		}
		//RetrieveApplicationDemographicsDetails
	}

	public static boolean isDynamicResponseField(String param) {
		boolean result = false;
		for (int count = 0; count < dynamicFields.length; count++) {
			if (dynamicFields[count].contentEquals(param)) {
				result = true;
				break;
			}

		}
		return result;
	}

	public static HashMap<String, Object> Metadataextract(String testCaseId, String sheetName) throws FilloException {

		String path = System.getProperty("user.dir");
		// System.out.println(path);
		HashMap<String, Object> excelMap = new HashMap<String, Object>();

		// connection=
		// fillo.getConnection(System.getProperty("user.dir")+"/src/test/resources/testData/ProductDirectory.xlsx");
		connection = fillo.getConnection(
				"C:\\Users\\syednaseru\\166317-cplnr-jee-rmkb-financept-functest\\metadata\\Metadata.xls");
		// System.out.println(System.getProperty("user.dir")+"/metadata/Metadata.xls");
		String strQuery = "Select * from " + sheetName + " where Business_Element_name='" + testCaseId + "'";
		// System.out.println(strQuery);
		// String strQuery="Select * from Sheet1";
		Recordset recordset = connection.executeQuery(strQuery);

		while (recordset.next()) {
			ArrayList<String> ColCollection = recordset.getFieldNames();
			int size = ColCollection.size();
			for (int Iter = 0; Iter <= (size - 1); Iter++) {
				String ColName = ColCollection.get(Iter);
				String ColValue = recordset.getField(ColName);
				excelMap.put(ColName, ColValue);
			}
		}
		// System.out.println(excelMap);
		recordset.close();
		connection.close();

		return excelMap;
	}

	public static String getDatatype(String type) {
		if (type.contains("string")) {
			return "ALPHANUMERIC";
		} else if (type.contains("number")) {
			return "INTEGER";
		} else {
			return "ALPHABETIC";
		}
	}

	public static String getWiremockProperty(String length, String type) {
		//return "{{randomValue length=" + length + " type='" + type + "'}}";
		if(type.contentEquals("ALPHANUMERIC")) {
			return RandomStringUtils.randomAlphanumeric(Integer.parseInt(length)).toString();
		}else if(type.contentEquals("ALPHABETIC")) {
			return RandomStringUtils.randomAlphabetic(Integer.parseInt(length)).toString();
		}else {
			return RandomStringUtils.randomNumeric(Integer.parseInt(length)).toString();
		}
		
	}

	public static String getMethod(String path , String swaggerPath) {
		Swagger swagger = new SwaggerParser().read(
				swaggerPath,
				null, false);
		//C:\Users\syednaseru\Downloads\TWA-8499.json
		//C:\\Users\\syednaseru\\Download_C_Drive\\Download_C_Drive\\swagger-codegen\\WealthDashboard.json
		if (swagger.getPaths().get(path).getPost() != null) {
			return "POST";
		} else if (swagger.getPaths().get(path).getPut() != null) {
			return "PUT";
		} else if (swagger.getPaths().get(path).getGet() != null) {
			return "GET";
		} else if (swagger.getPaths().get(path).getDelete() != null) {
			return "DELETE";
		} else {
			return "PATCH";
		}
	}

	public static void addWiremockMappings(String method, String uri, String request, String response,
			String responseCode) throws JsonProcessingException, FilloException {

		if (!wireMockServer.isRunning()) {
			wireMockServer.start();
		}
		if (method.contentEquals("POST")) {
			wireMockServer.stubFor(post(uri).withRequestBody(equalToJson(request, true, true))
					.willReturn(aResponse().withStatus(Integer.parseInt(responseCode)).withBody(response)));
		} else if (method.contentEquals("PUT")) {
			wireMockServer.stubFor(put(uri).withRequestBody(equalToJson(request, true, true))
					.willReturn(aResponse().withStatus(Integer.parseInt(responseCode)).withBody(response)));
		}
	}

	public static void addWiremockMappings(String method, String uri, HashMap queryParams, String response,
			String responseCode) throws JsonProcessingException, FilloException {
		if (!wireMockServer.isRunning()) {
			wireMockServer.start();
		}
		if (method.contentEquals("GET")) {
			wireMockServer.stubFor(get(uri).withQueryParams(queryParams)
					.willReturn(aResponse().withStatus(Integer.parseInt(responseCode)).withBody(response)));
		} else if (method.contentEquals("DELETE")) {
			wireMockServer.stubFor(delete(uri).withQueryParams(queryParams)
					.willReturn(aResponse().withStatus(Integer.parseInt(responseCode)).withBody(response)));
		}
	}

}
