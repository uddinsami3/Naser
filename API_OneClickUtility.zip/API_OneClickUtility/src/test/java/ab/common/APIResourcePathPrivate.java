package ab.common;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import ab.common.APIResourcePathPrivate.Data;


public interface APIResourcePathPrivate {
	
	

    @Retention(RetentionPolicy.RUNTIME)
    public @interface Data{

        String name();


    }
    
    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications")
    String ApplicationADD = null;
    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications")
    String UATApplicationADD = null;
    
    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications/{applicationId}")
    String ApplicationUpdate = null;

    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications/{applicationId}/backgroundScreening")
    String ApplicationBGS = null;
    
    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications/{applicationId}")
    String ApplicationUpdateBeforeIPA = null;
    
    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications/{applicationId}/inPrincipleApprovals")
    String ApplicationIPA = null;

    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications/{applicationId}/offerAcceptance")
    String ApplicationOfferAcceptance = null;
    
    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications/{applicationId}")
    String ApplicationUpdateBeforeFinal = null;
    
    @Data (name = "/rcegateway/private/v1/onboarding/unsecuredProducts/applications/{applicationId}/submission")
    String ApplicationFinalSubmit = null;
    
    @Data (name = "/private/v1/investments/mutualFunds/productSearch")
    String ProductDirectory = null;
    
    
}
