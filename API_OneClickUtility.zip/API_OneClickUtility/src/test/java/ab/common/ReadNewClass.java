package ab.common;

import java.util.Date;

import org.jeasy.random.EasyRandom;
import org.jeasy.random.EasyRandomParameters;
import org.jeasy.random.TypePredicates;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsonschema.JsonSchema;

import io.github.benas.randombeans.EnhancedRandomBuilder;
import io.github.benas.randombeans.api.EnhancedRandom;
import io.github.benas.randombeans.randomizers.range.DateRangeRandomizer;
import io.github.benas.randombeans.randomizers.range.IntegerRangeRandomizer;
import io.github.benas.randombeans.randomizers.time.LocalDateRandomizer;


public class ReadNewClass {
	public static LocalDate localDate;

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, JsonProcessingException {
		// TODO Auto-generated method stub
		System.out.println("");
		readClass("ContentList");
	}
	public static void readClass(String className) throws ClassNotFoundException, InstantiationException, IllegalAccessException, JsonProcessingException {
		
		EasyRandomParameters parameters = new EasyRandomParameters();
		//parameters.dateRange(java.time.LocalDate.of(1970, 1, 1), java.time.LocalDate.MAX);
		parameters.excludeType(TypePredicates.ofType(LocalDate.class));
		//System.out.println(parameters.getStringLengthRange());
		System.out.println(java.time.LocalDate.MIN.toString());
		System.out.println(java.time.LocalDate.MAX.toString());
		java.time.LocalDate localDate = null;
		java.time.LocalDate date1 = localDate.parse("1992-01-01");
		java.time.LocalDate date2 = localDate.parse("2021-01-01");
		
		
		Class classTemp = Class.forName("io.swagger.client.model." + className);
		EasyRandom easyRandom = new EasyRandom(parameters);
		ObjectMapper mapper = new ObjectMapper();
		//String jsonString = mapper.writeValueAsString(classTemp);
		
		//String jsonString = mapper.writeValueAsString(easyRandom.nextObject(classTemp));
	      //System.out.println(jsonString.replaceAll("-", ""));
		//System.out.println(easyRandom.nextObject(classTemp));
		//Object obj =classTemp.newInstance();
		
		
	      
	      EnhancedRandom enhancedRandom = EnhancedRandomBuilder.aNewEnhancedRandomBuilder()
	    	         .seed(123L)
	    	         .objectPoolSize(100)
	    	         .stringLengthRange(4, 10)
	    	         .collectionSizeRange(1, 10)
	    	         .scanClasspathForConcreteTypes(true)
	    	         .randomize(Integer.class, new IntegerRangeRandomizer(0, 10000000))
	    	         .dateRange(date1, date2)
	    	         .build();
	      String jsonString = mapper.writeValueAsString(enhancedRandom.nextObject(classTemp, "contentPublishedDate"));
	      //contentPublishedDate
	      
	      System.out.println(jsonString.replaceAll("null", "\"1992-01-01\""));
	}
}
