package ab.glue;

import java.util.HashMap;
import java.util.Map;

public class ProductDirectory {

	public static Map<String, Object> apiHeader() {

		Map<String, Object> headerMap = new HashMap<String, Object>();
		headerMap.put("channelId", "HBK");
		headerMap.put("businessCode", "GCB");
		headerMap.put("countryCode", "HK");
		headerMap.put("Content-Type", "application/json");
		headerMap.put("i-cif", "22410");
		headerMap.put("Accept", "application/json");
		
		return headerMap;

	}

	public static Map<String, Object> queryHeader() {
		Map<String, Object> queryMap = new HashMap<String, Object>();

		return queryMap;
	}

	public static Map<String, Object> pathHeader() {
		Map<String, Object> pathHeader = new HashMap<String, Object>();
		return pathHeader;
	}

}
