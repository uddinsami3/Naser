package ab.glue;

import java.util.HashMap;
import java.util.Map;

public class loanDetail {
	
	public static Map<String, Object> apiHeader( ) {
        
        Map<String,Object> headerMap = new HashMap<String,Object>();
        headerMap.put("Cookie", Genericglue.cookie);
        
       // headerMap.putAll(TestConfiguration.header());
        return headerMap;

    }
    public static Map<String, Object> queryHeader( )
    {
        Map<String,Object> queryMap = new HashMap<String,Object>();
        queryMap.put("relationshipNumber", Genericglue.getData.get("relationshipNumber"));
        queryMap.put("fromDate", Genericglue.getData.get("fromDate"));
        queryMap.put("toDate", Genericglue.getData.get("toDate"));
        queryMap.put("sinceInitialFlag", Genericglue.getData.get("sinceInitialFlag"));
//        queryMap.put("levInd", Genericglue.getData.get("levInd"));
        
        return queryMap;
    }
    public static Map<String, Object> pathHeader( )
    {
        Map<String,Object> pathHeader = new HashMap<String,Object>();
        return pathHeader;
    }

}
