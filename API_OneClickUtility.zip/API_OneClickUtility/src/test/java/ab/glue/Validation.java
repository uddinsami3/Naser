package ab.glue;

import java.util.HashMap;
import java.util.Map;

public class Validation {

	public static Map<String, Object> apiHeader() {

		Map<String, Object> headerMap = new HashMap<String, Object>();
		headerMap.put("Content-Type", Genericglue.getData.get("Content-Type"));
		headerMap.put("Cookie", Genericglue.getData.get("Cookie"));
		// headerMap.putAll(TestConfiguration.header());
		return headerMap;

	}

	public static Map<String, Object> queryHeader() {
		Map<String, Object> queryMap = new HashMap<String, Object>();
//		queryMap.put("channelId", Genericglue.getData.get("channelId"));
//		queryMap.put("x-userID", Genericglue.getData.get("x-userID"));
//		queryMap.put("uuid", Genericglue.getData.get("uuid"));
//		queryMap.put("countryCode", Genericglue.getData.get("countryCode"));
//		queryMap.put("levInd", Genericglue.getData.get("levInd"));
//
		return queryMap;
	}

	public static Map<String, Object> pathHeader() {
		Map<String, Object> pathHeader = new HashMap<String, Object>();
		return pathHeader;
	}

}
