package ab.glue;

import java.util.HashMap;
import java.util.Map;

import ab.common.CommonUtility;
import ab.common.TestConfiguration;

public class RelationShips {

	public static Map<String, Object> apiHeader( ) {
        //TestConfiguration.header();
        Map<String,Object> headerMap = new HashMap<String,Object>();
        headerMap.put("Cookie", Genericglue.cookie);
        
        headerMap.put("Accept", Genericglue.getData.get("Accept")); 
        headerMap.put("Accept-Encoding", Genericglue.getData.get("Accept-Encoding"));
        headerMap.putAll(TestConfiguration.header());
        return headerMap;

    }
    public static Map<String, Object> queryHeader( )
    {
        Map<String,Object> queryMap = new HashMap<String,Object>();
        return queryMap;
    }
    public static Map<String, Object> pathHeader( )
    {
        Map<String,Object> pathHeader = new HashMap<String,Object>();
        pathHeader.put("cloakedCustomerID", CommonUtility.cloakedCust);
        return pathHeader;
    }
	
	
}
