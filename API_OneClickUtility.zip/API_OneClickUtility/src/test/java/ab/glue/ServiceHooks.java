package ab.glue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Base64;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.citi.Automation.capabilities.DesiredCap;

import com.citi.dataDriven.Xls_Reader;
//import com.citi.reports.ExtendReportCucumber;

import com.citi.ui.utils.TestUtils;
import com.codoid.products.exception.FilloException;

import ab.common.CommonUtility;
import ab.common.TestConfiguration;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class ServiceHooks {

	public static Scenario scenario;

	// Logger log = LoggerHelper.getLogger(ServiceHooks.class);

	@Before
	public void getScenarioName(Scenario scenario) throws IOException, InterruptedException, FilloException {
		// ExtendReportCucumber.beforeclass();
		ServiceHooks.scenario = scenario;
		// ExtentReport.getScenarioName(scene);

		//Xls_Reader.readPreReqMethod();
		// ScreenShotClass.message = scene;

	}

	
	@AfterStep
	public void takesScreenshot(Scenario scenario) {

	}

//	public void tearDown(Scenario scenario) throws IOException {
//		scenario.write("Welcome to end of report");
//		
//		final byte[] screenshot =  ((TakesScreenshot) DesiredCap.webdriver).getScreenshotAs(OutputType.BYTES);
//		scenario.embed(screenshot, "image/png","");
//		
//	    scenario.write("taking screen shot");

//		
// 	String screenshotName = scenario.getName().replaceAll(" ", "_");
//    	           byte[] screenshot = ((TakesScreenshot)DesiredCap.webdriver).getScreenshotAs(OutputType.BYTES);
//	            
//	            	File sourcePath = ((TakesScreenshot) DesiredCap.webdriver).getScreenshotAs(OutputType.FILE); 
//	            	File targetLocation = new File("target/test-report/extent-report/screenshots/" + screenshotName + ".png"); 
//	            	FileUtils.copyFile(sourcePath, targetLocation); 
//	            	scenario.embed(targetLocation, "image/png","");
//	            	

	// }

	public static void teardown(Scenario scenario) throws InterruptedException, IOException {
		Thread.sleep(2000);
		if (scenario.isFailed()) {
			try {
				String screenshotName = scenario.getName().replaceAll(" ", "_");
				byte[] screenshot = ((TakesScreenshot) DesiredCap.webdriver).getScreenshotAs(OutputType.BYTES);
				File screenshot_with_scenario_name = ((TakesScreenshot) DesiredCap.webdriver)
						.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(screenshot_with_scenario_name,
						new File("target/test-report/extent-report/screenshots/" + screenshotName + ".png"));

				System.out.println("testing pring the screenshot" + screenshotName);

				File destinationPath = new File(
						"target/test-report/extent-report/screenshots/" + screenshotName + ".png");

				// Reporter.addScreenCaptureFromPath(destinationPath.toString());
				// Reporter.addScenarioLog(screenshotName);

				scenario.attach(screenshot, "image/png", "");

			} catch (IOException somePlatformsDontSupportScreenshots) {
				System.err.println(somePlatformsDontSupportScreenshots.getMessage());
			}
		}
	}

	@After
	public void updateExcelStatus(Scenario scenario) throws FilloException, InterruptedException {

		// ExtentReport.updateExcelStatus(scenario);

		if (DesiredCap.webdriver == null) {
			return;
		}
		Thread.sleep(2000);
		DesiredCap.webdriver.quit();
		DesiredCap.webdriver = null;

	}

}
