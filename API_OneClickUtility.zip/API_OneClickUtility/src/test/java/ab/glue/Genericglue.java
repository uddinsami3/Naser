package ab.glue;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.codoid.products.exception.FilloException;
import com.github.wnameless.json.flattener.JsonFlattener;

import ab.common.CommonUtility;
import ab.common.TestConfiguration;
import ab.utils.DataProvider;
import ab.utils.Dbvalidation;
import ab.utils.OrcaleDBConnection;
import ab.utils.TestUtils;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Random;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import io.swagger.client.model.RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest;
import io.swagger.client.model.UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallengesRequest;

public class Genericglue {

	Response response;
	RequestSpecification request;
	public static Map<String, Object> getData;
	DataProvider readdata = new DataProvider();
	TestUtils ts = new TestUtils();
	HashMap<String, String> parseXML = new HashMap<String, String>();
	public static Scenario scenario;
	public static String testCaseID;
	static String sheetName;
	static String workbook;
	public static FileWriter fw;
	public static String featureName;
	public static String  ColName;

	public static String cookie;
	public static Set<Cookie> cookiee;
	WebDriver driver = null;
	public static String  CurrentTestCaseName;

	@Before
	public void beforeClass(Scenario scenario) throws Exception {

		this.scenario = scenario;
		parseXML = ts.parseStringXML();
		String scenarioId = scenario.getId();
		System.out.print(scenarioId);

		int start = scenarioId.indexOf("Features");
		int end = scenarioId.indexOf(".feature");
		System.out.print("wtryeye" + start);

		System.out.print("twtwtw" + end);

		String[] featureNameRes = scenarioId.substring(start, end).split("Features/");

		featureName = featureNameRes[1];

		String logFolder = "src/test/resources/APILog/" + featureName + "_" + TestUtils.date();
		File dir = new File(logFolder);
		if (!dir.exists()) {
			// noinspection ResultOfMethodCallIgnored
//			dir.mkdirs();

		}
		
		
//		fw = new FileWriter(logFolder + "/" + scenario.getName() + TestUtils.Time() + ".txt");
	}
//	@Before
//	public static void logFolderCreation() throws IOException
//	{
//
//		  String logFolder = "src/test/resources/APILog/"+featureName+"_"+TestUtils.date();
//			File dir = new File(logFolder);
//		    if (!dir.exists()) {
//		        //noinspection ResultOfMethodCallIgnored
//		        dir.mkdirs();
//
//		   }
//		    fw = new FileWriter(logFolder+"/"+scenario.getName()+TestUtils.Time()+".txt");
//	}

	// Common method
	public void explicitWait(WebDriver driver, By element) {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));
	}

	public boolean isLinkPresent(WebDriver driver) {
		try {

			return true;
		} catch (Exception e) {

			return false;
		}
	}

	public boolean isAlertPresent(WebDriver driver) {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception e) {

			return false;
		}
	}

	public void clientSearchUAT() throws InterruptedException {
//		System.setProperty("webdriver.chrome.driver", "src/test/resources/Drivers/chromedriver");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NP26736\\AppData\\Local\\SeleniumDriver\\chromedriver.exe");
		ChromeOptions opt = new ChromeOptions();
		opt.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200", "--ignore-certificate-errors");
		driver = new ChromeDriver();
		//driver = new ChromeDriver();
		Thread.sleep(4000);
		driver.get("https://eclipse.uat2a.citigroup.net/");

//		if (isLinkPresent(driver)) {
//			driver.findElement(By.xpath("//*[@id='details-button']")).click();
//			Thread.sleep(2000);
//			driver.findElement(By.xpath("//*[@id='proceed-link']")).click();
//		}

		Thread.sleep(10000);

		String MainWindow = driver.getWindowHandle();
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		while (i1.hasNext()) {
			String ChildWindow = i1.next();

			if (!MainWindow.equalsIgnoreCase(ChildWindow)) {
				driver.switchTo().window(ChildWindow);
			}
		}
		driver.findElement(By.xpath("//*[@id='USER_ID']")).sendKeys("NP26736");
		driver.findElement(By.xpath("//*[@id='PASSWORD']")).sendKeys("Maveric@5");
		Select ele = new Select(driver.findElement(By.xpath("//select[@class='form-control']")));
		ele.selectByVisibleText("Singapore");
		driver.findElement(By.xpath("//input[@name='btnSubmit']")).click();
		Thread.sleep(10000);
//		if (isAlertPresent(driver)) {
//			driver.switchTo().alert();
//			driver.switchTo().alert().accept();
//			driver.switchTo().defaultContent();
//		}
		
		driver.findElement(By.xpath("//*[@id='extrasysmenutable']/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='SP']/a")).click();
		Thread.sleep(5000);
		WebElement remark = driver.findElement(By.xpath("//*[@id='menu']/li[6]"));
		Actions actio = new Actions(driver);
		actio.moveToElement(remark).perform();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='menu']/li[6]/ul/li/a")).click();
		
		
		/*
		 * driver.findElement(By.xpath("//*[@id='sidebar-trigger']")).click();
		 * Thread.sleep(5000); JavascriptExecutor js = (JavascriptExecutor) driver;
		 * WebElement citiPlanner =
		 * driver.findElement(By.xpath("//*[@id=\"sidebar-inner\"]/ul/li[27]/a"));
		 * js.executeScript("arguments[0].scrollIntoView()", citiPlanner); //
		 * driver.findElement(By.xpath("(//*[@class='caret pull-right'])[13]")).click();
		 * Thread.sleep(4000);
		 * 
		 * driver.findElement(By.xpath("//*[@id=\"sidebar-inner\"]/ul/li[27]/a")).click(
		 * ); //
		 * driver.findElement(By.xpath("(//*[@class='caret pull-right'])[19]")).click();
		 * Thread.sleep(4000);
		 * driver.findElement(By.xpath("(//a[text()='Remarkable Advice'])[1]")).click();
		 * Thread.sleep(4000);
		 * driver.findElement(By.xpath("(//a[text()='Remarkable Advice'])[2]")).click();
		 * // Thread.sleep(4000); Thread.sleep(10000);
		 */
		Set<String> handles = driver.getWindowHandles();
		Iterator<String> itr = handles.iterator();
		String parentWindow = itr.next();
		String newWindow = itr.next();
		driver.switchTo().window(newWindow);

		driver.getTitle();
		WebElement findElement = driver.findElement(By.xpath("//iframe[@id='GenericFrame']"));
		driver.switchTo().frame(findElement);
		// normal code
		explicitWait(driver, By.xpath("//a[text()='Client #']"));
		driver.findElement(By.xpath("//a[text()='Client #']")).click();
		Thread.sleep(5000);
		explicitWait(driver, By.xpath("//input[@id='PH_ID']"));
		driver.findElement(By.xpath("//input[@id='PH_ID']")).sendKeys("688557");
		Thread.sleep(10000);
		explicitWait(driver, By.xpath("//button[@id='BUTTON_ANYCLIENT']"));
		driver.findElement(By.xpath("//button[@id='BUTTON_ANYCLIENT']")).click();
		Thread.sleep(10000);
		explicitWait(driver, By.cssSelector("svg.ic_chevron_d"));
		driver.findElement(By.cssSelector("svg.ic_chevron_d")).click();
		Thread.sleep(10000);
		explicitWait(driver, By.xpath("//*[@id='custRel']"));
		driver.findElement(By.xpath("//*[@id='custRel']")).click();
		Thread.sleep(5000);
		

	}

	public void CaptureCookie() {
		Cookie Jse = driver.manage().getCookieNamed("CP_JSESSIONID");
		Cookie SMSE = driver.manage().getCookieNamed("SMSESSION");
//		Set<Cookie> cookiee = driver.manage().getCookies();
		cookiee = driver.manage().getCookies();
		String cookieee = cookiee.toString();
		String[] co = cookieee.split(";");
		String cooky = co[0];
		String cookyy = cooky.substring(1);
//		String Js = Jse.toString();
//		String[] cook = Js.split(";");
//		String JSession = cook[0];
		cookie = cookyy + ";" + " " + ";" + SMSE;

	}

	@Given("login to the Eclipse TWA application navigate to investment graph and capture the cookie")
	public void login_to_the_Eclipse_TWA_application_navigate_to_investment_graph_capture_the_cookie()
			throws InterruptedException {
		clientSearchUAT();
		Thread.sleep(10000);
		explicitWait(driver, By.xpath("//*[@id='planMeetingBtn']"));
		driver.findElement(By.xpath("//*[@id='planMeetingBtn']")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//li[@id='rn-wealth_snapshot']")).click();
		// explicitWait(driver, By.xpath("//li[@id='investments']"));
		Thread.sleep(10000);
		driver.findElement(By.xpath("//li[@id='investments']")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id='nj-investment-tabs']/li[2]/div/a")).click();
//		driver.findElement(By.xpath("//a[contains(text(),'RETURNS(PAT)')]")).click();
//		Thread.sleep(5000);
		// CaptureCookie();
		//Cookie Jse = driver.manage().getCookieNamed("CP_JSESSIONID");
		Cookie SMSE = driver.manage().getCookieNamed("SMSESSION");
		Set<Cookie> cookiee = driver.manage().getCookies();
		String cookieee = cookiee.toString();
		String[] co = cookieee.split(";");
		String cooky = co[0];
		String cookyy = cooky.substring(1);
		//String Js = Jse.toString();
		//String[] cook = Js.split(";");
		//String JSession = cook[0];
		cookie = cookyy + ";" + SMSE;

		//driver.quit();
	}

	@Given("Read TestCaseId & SheetName from the scenario {string} and {string} and {string}")
	public void read_TestCaseId_SheetName_from_the_scenario_and_and(String testCaseID, String sheetName,
			String workbook) throws FilloException {
//		System.out.println("Dhana");
//		System.out.println(testCaseID);
//		System.out.println(sheetName);
//		System.out.println(workbook);
		getData = readdata.extractExceldata(testCaseID, sheetName, workbook);

		Genericglue.testCaseID = testCaseID;
		Genericglue.sheetName = sheetName;
		Genericglue.workbook = workbook;

	}
	@Then("Load The payload from Excel for {string}")
	public void load_The_payload_from_Excel_for(String TestCaseName) throws FilloException {
		getData = readdata.extractExceldataoverride(TestCaseName);
		Genericglue.testCaseID = TestCaseName;
	}
	/*
	 * @Given("Read TestCaseId & SheetName from the scenario {string} and {string}")
	 * public void readTestCaseIdSheetNameFromTheScenarioAnd(String
	 * testCaseID,String sheetName) throws Throwable {
	 * 
	 * getData = readdata.extractExceldata(testCaseID, sheetName);
	 * Genericglue.testCaseID =testCaseID; Genericglue.sheetName = sheetName;
	 * 
	 * }
	 */
	@When("user hits the {string} environment and {string} scope and {string} API with requestType {string} with the provided data {string} and verify response {string}")
	public void user_hits_the_environment_and_scope_and_API_with_requestType_with_the_provided_data_and_verify_response(String environment, String scope,
			String apiName, String requestType, String TCNameAndColName, String Responsefield) throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException, NoSuchFieldException, FileNotFoundException, IOException, ParseException, FilloException, Exception {
		HashMap<String,String> secondmap=new HashMap<String,String>();
		String[] OrchAPINames = apiName.split(",");
		String[] OrchReqtypes = requestType.split(",");
		String[] ResFields = Responsefield.split(",");
		for(int i=0;i<=OrchAPINames.length-1;i++) {
		apiName=OrchAPINames[i];
		requestType= OrchReqtypes[i];
		String[] TCNameAndcol = TCNameAndColName.split(",");
		String TestCaseName = TCNameAndcol[0];
		ColName = TCNameAndcol[1];
		getData = readdata.extractExceldataoverride(TestCaseName);
		Genericglue.testCaseID = TestCaseName;
		JSONParser parser = new JSONParser();
		Object obj;
		String ReqPayload = null;
		if (requestType.equals("PUT")){			
			Field[] fields = UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallengesRequest.class.getDeclaredFields();
			fields[0].getName();
			for(int j=0;j<fields.length;j++) {
				System.out.println(fields[j].getName());
				
				
			Responsefield = RandomStringWitnLength(3, 5);
			secondmap.put(fields[j].getName(), Responsefield);
			System.out.println(secondmap.get(fields[j].getName()));
				
			//prepare data for all fields, convert as kson and put it in excel in return and take from excel later 
			}
			System.out.println("OrechesAPI MAP "+ secondmap.entrySet());
			for(Entry<String, String> m : secondmap.entrySet()){  
				CommonUtility.payload(m.getKey(), m.getValue(), apiName);
			}
				obj = parser.parse(new FileReader("src/test/resources/Payloads/"+apiName+".txt"));
					
					JSONObject jsonObject = (JSONObject) obj;

					//body = jsonObject.toJSONString();
					ReqPayload = jsonObject.toString();
					System.out.println("Payload body is  " +ReqPayload);
					DataProvider.writeExcelDataOverride(Genericglue.testCaseID, "OrchesReq_Payload", ReqPayload);
			
		response = CommonUtility.userhitsrequestwithAPI(environment, scope, apiName, requestType, scenario);
		}
		else {			
			response = CommonUtility.userhitsrequestwithAPI(environment, scope, apiName, requestType, scenario);	
			String responsevalue = response.jsonPath().getString("contentList[0]."+ResFields[0]);
			HashMap<String, Object> excelmap = DataProvider.extractExceldataoverride(Genericglue.testCaseID);
			String responsefieldtoverify = excelmap.get(ResFields[0]).toString();
			int StatusCode = response.statusCode();		
			String statusCode=String.valueOf(StatusCode); 
			if(responsefieldtoverify.equals(responsevalue)) {
				System.out.println(apiName + " API Certified");
			}
			
		    System.out.println(response);
		}
		}
		//SequenceNumber
	}
	@Then("Run the TestCase for Next API for {string} with the provided {string}")
	public void run_the_TestCase_for_Next_API_for_with_the_provided(String TestCaseName, String ColumnName) throws FilloException {
		
	}

	
	@When("user hits the {string} environment and {string} scope and {string} API with requestType {string} with valid details")

	public void user_hits_the_environment_and_API_with_requestType_with_valid_details(String environment, String scope,
			String apiName, String requestType) throws Exception {
		response = CommonUtility.userhitsrequestwithAPI(environment, scope, apiName, requestType, scenario);
	}

	@When("user hits the {string} API with requestType {string} with valid details")

	/*
	 * public void userhitsrequestwithvalidvalues(String apiName, String
	 * requestType) throws Throwable {
	 * 
	 * 
	 * response = CommonUtility.userhitsrequestwithAPI(apiName, requestType,
	 * scenario);
	 * 
	 * }
	 */

	@Then("^Validate the \"([^\"]*)\" response \"([^\"]*)\" Schema$")

	public void validate_the_response_Schema(String apiName, String format) throws Throwable {
		if (format.equals("JSON")) {
			System.out.println(" JSON");
			response.then().assertThat().body(matchesJsonSchemaInClasspath(apiName + ".json"));

		}

	}

	@Then("^Verify the mandatory fields are not null in the \"([^\"]*)\" response$")

	public void verify_the_mandatory_fields_are_not_null_in_the_response(String apiName) throws Throwable {

		Object key;
		Object value;
		String body = response.body().asString();
		// JSONParser parser = new JSONParser();
		// Object obj = parser.parse(body);
		// JSONObject jsonObject = (JSONObject) obj;
		Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(body.toString());

		for (Entry<String, Object> entry : flattenedJsonMap.entrySet()) {
			System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());

			key = entry.getKey();
			value = entry.getValue();

			System.out.println("Key : " + key);

			CommonUtility.mandatoryfieldsnullorempty(key, value, apiName);
		}

	}

	@Then("^Validate that no additional fields in the \"([^\"]*)\" response$")

	public void validate_that_no_additional_fields_in_the_response(String apiName) throws Throwable {
		Object key;
		Object value;
		String body = response.body().asString();
		// JSONParser parser = new JSONParser();
		// Object obj = parser.parse(body);
		// JSONObject jsonObject = (JSONObject) obj;
		Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(body.toString());

		for (Entry<String, Object> entry : flattenedJsonMap.entrySet()) {
			System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());

			key = entry.getKey();
			value = entry.getValue();

			System.out.println("Key : " + key);

			CommonUtility.noadditionalfields(key, apiName, scenario);
		}
	}

	@Then("Verify the {string} in the json response")
	public void verify_the_errorDetail_in_the_json_response(String errorDetail) {

		// response.then().statusCode(Integer.parseInt(statusCode));
		TestUtils.softassert("details", response.body().jsonPath().getString("details"),
				getData.get(errorDetail).toString());

	}

	/*
	 * @Then("^Validate that no additional fields in the\"([^\"]*)\" response$")
	 * 
	 * public void validate_that_no_additional_fields_in_the_response(String
	 * apiName) throws Throwable { Object key; Object value; String body =
	 * response.body().asString(); // JSONParser parser = new JSONParser(); //
	 * Object obj = parser.parse(body); // JSONObject jsonObject = (JSONObject) obj;
	 * Map<String, Object> flattenedJsonMap =
	 * JsonFlattener.flattenAsMap(body.toString());
	 * 
	 * for (Entry<String, Object> entry : flattenedJsonMap.entrySet()) {
	 * System.out.println("Key : " + entry.getKey() + " Value : " +
	 * entry.getValue());
	 * 
	 * key = entry.getKey(); value = entry.getValue();
	 * 
	 * System.out.println("Key : " + key);
	 * 
	 * CommonUtility.noadditionalfields(key, apiName); }
	 */

	
	
	/*
	 * @Then("^assert that response value of \"([^\"]*)\" mandatory parameter are matching with expected value$"
	 * )
	 * 
	 * public void
	 * assert_that_response_value_of_mandatory_parameter_are_matching_with_expected_value
	 * (String apiName) throws Throwable { TestUtils.htmltable("", "", "", true);
	 * TestUtils.htmltable("CustomerNumber",response.jsonPath().getString(
	 * "vcResultList[0].customerNumber"), parseXML.get("assessmentTypeCode2"));
	 * 
	 * TestUtils.htmltable("assessmentTypeDescription",
	 * response.jsonPath().getString("vcResultList[1].assessmentTypeDescription"),
	 * parseXML.get("assessmentTypeDescription2"), false);
	 * Assert.assertEquals(response.jsonPath().getString(
	 * "vcResultList[1].assessmentTypeDescription"),parseXML.get(
	 * "assessmentTypeDescription2"));
	 * 
	 * TestUtils.htmlwrite(this.scenario);
	 * 
	 * }
	 */
	 
	 
	@Then("the {string} response should be displayed with status code as {string}")
	public void response_should_be_displayed_with_status_code_as(String string, String statusCode) {

		response.then().statusCode(Integer.parseInt(statusCode));
	}

	@Then("Verify that request of {string} parameter are matching with CI data base table column values")
	public void verify_that_request_of_parameter_are_matching_with_CI_data_base_table_column_values(String apiName)
			throws Exception {

		TestUtils.htmltable("DBFieldName", "ActualAPIValue", "ExpectedDBValue", "", true);

		if (apiName.equals("ApplicationAdd")) {
			Dbvalidation.apllicationadd(getData, response, scenario);
		} else if (apiName.equals("ApplicationUpdate")) {
			Dbvalidation.apllicationupdate(getData, response, scenario);
		}

		else if (apiName.equals("ApplicationUpdateBeforeIPA")) {
			Dbvalidation.applicationUpdateBeforeIPA(getData, response, scenario);
		}

		else if (apiName.equals("ApplicationUpdateBeforeFinal")) {
			Dbvalidation.ApplicationUpdateBeforeFinal(getData, response, scenario);
		}
		TestUtils.htmlwrite(this.scenario);

	}

	@Then("Verify the {string} and {string} in the json response")
	public void verify_the_and_in_the_json_response(String errorCode, String errorDetail) {
		System.out.println("BABU=================================");
	}

	@Given("Verify that request of ApplicationUpdate parameter are matching with CI data base table column values")
	public void verify_that_request_of_ApplicationUpdate_parameter_are_matching_with_CI_data_base_table_column_values()
			throws Exception {
		TestUtils.htmltable("DBFieldName", "ActualAPIValue", "ExpectedDBValue", "", true);
		Dbvalidation.apllicationupdate(getData, response, scenario);
		TestUtils.htmlwrite(this.scenario);
	}

	@Then("Verify that response of {string} parameter applicationId and applicationStage are matching with CI data base table column  values")
	public void verify_that_response_of_parameter_applicationId_and_applicationStage_are_matching_with_CI_data_base_table_column_values(
			String string) {

	}

	@Then("Verify that request of ApplicationUpdateBeforeIPA parameter are matching with CI data base table column values")
	public void verify_that_request_of_ApplicationUpdateBeforeIPA_parameter_are_matching_with_CI_data_base_table_column_values()
			throws Exception {
		TestUtils.htmltable("DBFieldName", "ActualAPIValue", "ExpectedDBValue", "", true);
		Dbvalidation.applicationUpdateBeforeIPA(getData, response, scenario);
		TestUtils.htmlwrite(this.scenario);
	}

	@Then("Verify that request of ApplicationUpdateBeforeFinal parameter are matching with CI data base table column values")
	public void verify_that_request_of_ApplicationUpdateBeforeFinal_parameter_are_matching_with_CI_data_base_table_column_values()
			throws Exception {
		TestUtils.htmltable("DBFieldName", "ActualAPIValue", "ExpectedDBValue", "", true);
		Dbvalidation.ApplicationUpdateBeforeFinal(getData, response, scenario);
		TestUtils.htmlwrite(this.scenario);
	}

	@Then("captured the {string} response Details")
	public void captured_the_response_Details(String string) {

		scenario.log(response.asString());
	}

	@Then("Verify the {string} response Details {string} and {string} and {string} in the response")
	public void verify_the_response_Details_and_and_in_the_response(String Fieldvalue, String Code, String Detail,
			String FieldID) {

		TestUtils.htmltable("Fieldvalue", "ActualAPIValue", "Expectedvalue", "", true);
		System.out.println(getData.get(Fieldvalue).toString());
		System.out.println(Code);
		System.out.println(Detail);
		System.out.println(FieldID);

		TestUtils.softassert(getData.get(Fieldvalue).toString(),
				response.jsonPath().getString("moreInfo.ProviderError[0].Code"), Code);
		TestUtils.softassert(getData.get(Fieldvalue).toString(),
				response.jsonPath().getString("moreInfo.ProviderError[0].Detail"), Detail);
		TestUtils.softassert(getData.get(Fieldvalue).toString(),
				response.jsonPath().getString("moreInfo.ProviderError[0].FieldID"), FieldID);
		TestUtils.htmlwrite(this.scenario);

	}
	
	@Given("To generate pojo class for {string} and write in text file")
	public void PojoClass(String apiName ) throws IOException, ClassNotFoundException {
		//To run bat file
		Process process = Runtime.getRuntime().exec("cmd /c Pojo.bat", null,
				new File("C:\\Users\\zeeshansait\\Downloads\\swagger-codegen"));
		
		//To Copy and paste the directory
		String source = "C:\\Users\\zeeshansait\\Downloads\\swagger-codegen\\Output\\src\\main\\java\\";
		File srcDir = new File(source);
		String destination = "C:\\Users\\zeeshansait\\Desktop\\API Framework Enahncements\\166317-cplnr-jee-rmkb-financept-functest (1)\\166317-cplnr-jee-rmkb-financept-functest\\src\\test\\java\\";
		File destDir = new File(destination);
		try {
			FileUtils.copyDirectory(srcDir, destDir);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		CommonUtility.WritePayload(apiName);
	} 
	public static String RandomStringWitnLength(int min, int max) {
		
		String NameRandom = RandomStringUtils.randomAlphabetic(min, max);
		System.out.println(NameRandom);
		return NameRandom;
	}
	public static int RandomNumber() {
		Random random = new Random();
		int RNo = random.nextInt(9999999-1000000) + 65;	
		System.out.println(RNo);
		return RNo;
	}
	
@Then("Run the Test Case for {string} with {string} for {string} and APIName {string} with Responsecode {string}")
public void run_the_Test_Case_for_with_for_and_APIName_with_Responsecode(String TestCaseType, String ChangeTo, String TestCaseName, String ApiName, String ResponseCode)throws FilloException, FileNotFoundException, IOException, ParseException{
//@Then("Run the Test Case for {string} with {string}")
//public void run_the_Test_Case_for_with(String string, String string2) throws FilloException {
	System.setProperty("ROW","1");
	Field[] fields = RetrieveCustomerWorkbenchOperatingSessionWealthDashboardNewsAndInsightsRequest.class.getDeclaredFields();
	fields[0].getName();
	String Randomdatas = null;
	//Dictionary<String, String> dict = new Hashtable<String, String>();
	HashMap<String,String> dict=new HashMap<String,String>();
	HashMap<String,String> secondmap=new HashMap<String,String>();
	JSONParser parser = new JSONParser();
	Object obj;
	String ReqPayload = null;
	
	Fillo fillo=new Fillo();
	Connection connection=fillo.getConnection(System.getProperty("user.dir")+"/metadata/Metadata.xls");
	System.out.println(System.getProperty("user.dir")+"/metadata/Metadata.xls");
	ArrayList<String> row = new ArrayList<String>();
	ArrayList<String>  data = new ArrayList<String>();
	for(int i=0;i<fields.length;i++) {
		System.out.println(fields[i].getName());
		//DataProvider.Metadataextract(fields[i].getName());
			
			  String
			  strQuery="Select * from MetaData where Business_Element_name='"+fields[i].getName()+"'"; 
			  //String strQuery="Select * from Sheet1";
			  
			  System.out.println(strQuery);
			  Recordset rs=connection.executeQuery(strQuery);
			  int rocnt = rs.getCount(); 
			  //System.out.println(rocnt); 
			  int colcnt =rs.getFieldNames().size(); 
			  //System.out.println(colcnt);
			  
			  
			  
			  data = rs.getFieldNames(); 
			  rs.moveNext();
			  
			  
			  for (int j = 1; j <= colcnt-1; j++) { 
				  String Colname = data.get(j);
			  //System.out.println(Colname); 
				  String value = rs.getField(j).value();
			  //System.out.println(value); 
				  if(value == null) { dict.put(Colname, "");
			  
			  }
			  else {
				  dict.put(Colname, value);
			  
			  } 
			  }
			 
	
	
	
	
		

	//rs.close();
	//connection.close();
	
	switch(TestCaseType + "|" + ChangeTo) {
	
	case"Valid|":
		System.out.println("Entering Valid Case");
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			Randomdatas = RandomStringWitnLength(Integer.parseInt(dict.get("COLUMN_20")), Integer.parseInt(dict.get("COLUMN_21")));
			
		}
		break;
	case"Invalid|MandatoryNull":
		System.out.println("Entering InValid MandatoryNull Case");
		if(dict.get("COLUMN_19").equalsIgnoreCase("MANDATORY") | dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			Randomdatas ="null";			
		}
		break;
	case"Invalid|NonMandatoryNull":
		System.out.println("Entering InValid NonMandatoryNull Case");
		if(dict.get("COLUMN_19").equalsIgnoreCase("OPTIONAL") | dict.get("JSONDatatype").equalsIgnoreCase("string")){
			Randomdatas ="null";			
		}
		break;
	case"Invalid|Min Length":
		System.out.println("Entering InValid Min Length Case");
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			int minusvalue = Integer.parseInt(dict.get("COLUMN_20")) -2;
			Randomdatas = RandomStringWitnLength(minusvalue, Integer.parseInt(dict.get("COLUMN_21")));
			
		}
		break;
	case"Invalid|Max Length":
		System.out.println("Entering InValid Max Length Case");
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			int plusvalue = Integer.parseInt(dict.get("COLUMN_21")) + 10;
			Randomdatas = RandomStringWitnLength(Integer.parseInt(dict.get("COLUMN_20")), plusvalue);
			
		}
		break;
	case"Invalid|DataTypeInt":
		System.out.println("Entering InValid DataTypeInt Case");
		if(dict.get("JSONDatatype").equalsIgnoreCase("string")) {
			dict.put("JSONDatatype","int");			
			Randomdatas =Integer.toString(RandomNumber());			
		}
		break;
	
	case"Invalid|DataTypeString":
		System.out.println("Entering InValid DataTypeString Case");
		if(dict.get("JSONDatatype").equalsIgnoreCase("Integer")) {
			dict.put("JSONDatatype","String");			
			Randomdatas = RandomStringWitnLength(Integer.parseInt(dict.get("COLUMN_20")), Integer.parseInt(dict.get("COLUMN_21")));
		}		
		break;
	
	}
	secondmap.put(fields[i].getName(), Randomdatas);
	System.out.println(secondmap.get(fields[i].getName()));
	}
	System.out.println("First API MAP "+secondmap.entrySet());
	for(Entry<String, String> m : secondmap.entrySet()){  
		CommonUtility.payload(m.getKey(), m.getValue(), ApiName);
	}
	//System.out.println(dict.get("Business_Element_name") + "','" + dict.get("COLUMN_20") + "','" + dict.get("COLUMN_21"));
	//for(Entry<String, String> m : secondmap.entrySet()){    
	  //  System.out.println(m.getKey()+" "+m.getValue());    
	   //}
	obj = parser.parse(new FileReader("src/test/resources/Payloads/"+ApiName+".txt"));
	
	JSONObject jsonObject = (JSONObject) obj;

	//body = jsonObject.toJSONString();
	ReqPayload = jsonObject.toString();
	System.out.println("Payload body is  " +ReqPayload);
 Connection connectionUpdate=fillo.getConnection(System.getProperty("user.dir").replace("\\", "/") + "/src/test/resources/testData/ProductDirectory.xlsx");
 int writecount = 1;
	//System.out.println(dict.get("Business_Element_name") + "','" + dict.get("COLUMN_20") + "','" + dict.get("COLUMN_21"));
	for(Entry<String, String> m : secondmap.entrySet()){   
		
	    System.out.println(m.getKey()+" "+m.getValue());  
	   // String InsertQuery = "INSERT INTO Sheet1("+m.getKey().replaceAll("\\s", "")+") VALUES('"
		//			+ m.getValue() + "')";
	    String UpdateQuery = "Update Sheet1 set "+m.getKey().replaceAll("\\s", "")+ "= '"+ m.getValue()+"', APIName = '"+ApiName+"', ResponseCode = '"+ResponseCode+"' , Request_Payload = '"+ReqPayload+"' where TestCaseName = '"+TestCaseName+"'";
		//String InsertQuery = "INSERT INTO Sheet1(BusinessName"+writecount+",BusinessMin"+writecount+",BusinessMax"+writecount+") VALUES('"
			//	+ m.getValue() + "','" + m.getValue() + "','" + m.getValue() + "')";
		System.out.println(writecount+"st iteration Query " + UpdateQuery);
		connectionUpdate.executeUpdate(UpdateQuery);
		writecount++; 
		
	   }
	
}

@Then("Verify the response with th provided data {string}")
public void verify_the_response_with_th_provided_data_ResponseFieldToVerify(String ResponseField) throws FilloException {
	//@Then("Verify the response")
	//public void verify_the_response() throws FilloException {
	    // Write code here that turns the phrase above into concrete actions
	String[] ResfieldNames = ResponseField.split(",");
	for(int i=0;i<=ResfieldNames.length-1;i++) {
			
		String responsevalue = response.jsonPath().getString("contentList[0]."+ResfieldNames[i]);
		HashMap<String, Object> excelmap = DataProvider.extractExceldataoverride(Genericglue.testCaseID);
		String responsefieldtoverify = excelmap.get(ResfieldNames[i]).toString();
		int StatusCode = response.statusCode();		
		String statusCode=String.valueOf(StatusCode); 
		if(responsefieldtoverify.equals(responsevalue)) {
			System.out.println(ResfieldNames[i]+" Response Matched");
		}
		else {
			System.out.println(ResfieldNames[i]+" Response Not Matched");
		}

	}
}

@Given("Run APIcases using Swagger File")
public void run_APIcases_using_Swagger_File() throws NoSuchMethodException, InvocationTargetException, NoSuchFieldException, Exception {
	
	//CommonUtility.ReadTestCases();
	//CurrentTestCaseName = "TC_01";
   
}

@Given("Run APIcases using Swagger File for {string}")
public void run_APIcases_using_Swagger_File_for(String TestCaseName) throws NoSuchMethodException, InvocationTargetException, NoSuchFieldException, Exception {
	CommonUtility.ReadTestCases(TestCaseName);
		
   
}

	@Given("{string} and ")
	public void run_APIcases_using_Swagger_File_for1(String TestCaseName) throws NoSuchMethodException, InvocationTargetException, NoSuchFieldException, Exception {
		CommonUtility.ReadTestCases(TestCaseName);


	}



@Given("Execute API {string} Request {string} Execution {string}")
public void execute_API_Request_Execution(String APIName, String RequestType, String ExecutionType) throws NoSuchMethodException, InvocationTargetException, NoSuchFieldException, Exception {
	//CommonUtility.ReadTestCasesUsingName(CommonUtility.recordsetMap);
	CommonUtility.readTestCaseValues(CommonUtility.negativerecordsetMap);
}

@Then("Validate Exceptedfield {string} with ExceptedValue {string}")
public void validate_Exceptedfield_with_Expected(String ResponseCode, String ResponseValue) throws NoSuchMethodException, InvocationTargetException, NoSuchFieldException, Exception {
	//CommonUtility.ReadTestCasesUsingName(CommonUtility.recordsetMap);
	CommonUtility.readTestCaseValues(CommonUtility.negativerecordsetMap);
}


	public static String sheetName() {
		return sheetName;

	}

	public static String testCaseID() {
		return testCaseID;

	}

	public static String workbook() {
		return workbook;

	}

	public static Map<String, Object> getDatavalue() {

		return getData;

	}
	public static void main(String args[]) throws IOException, InvalidFormatException, FilloException {
		//TestConfiguration.FeatureOverride();
		//TestConfiguration.overrideFeatureFiles(System.getProperty("user.dir")+"/src/test/resources/Project/SGTWAReport/Features");
		//TestConfiguration.setExcelDataToFeature();
		//DataProvider.extractExceldata("Case1","Sheet1","APITestData");
		//DataProvider.Metadataextract("sequenceNumber");
		DataProvider.ReadTestCases("TC_01", "APITestData - Copy");
		}

	@Given("{string} and  {string} and {string}")
	public void StepDefforGiven(String APIName,String requestType,String tcName) throws Exception {
		CommonUtility.ReadTestCases(APIName,requestType,tcName);
	}

	@Then("Validate {string} with {string} and Expected response code as {string}")
	public void StepDefforThen(String Expected_Fields, String  Expected_values, String Expected_ResposeCode) throws FilloException, IOException, ParseException, InterruptedException {
			CommonUtility.verifyResponse(Expected_Fields,Expected_values,Expected_ResposeCode);
	}
}
