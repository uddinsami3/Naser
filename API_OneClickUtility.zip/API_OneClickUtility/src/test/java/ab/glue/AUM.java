package ab.glue;

import java.util.HashMap;
import java.util.Map;

import ab.common.TestConfiguration;

public class AUM {
 
	public static Map<String, Object> apiHeader( ) {
		
        Map<String,Object> headerMap = new HashMap<String,Object>();
        headerMap.put("Cookie", Genericglue.cookie);
        headerMap.put("Content-Type", "application/json; charset=UTF-8");
        
        //headerMap.put("Accept", Genericglue.getData.get("Accept")); 
        //headerMap.put("Accept-Encoding", Genericglue.getData.get("Accept-Encoding"));
       // headerMap.putAll(TestConfiguration.header());
        return headerMap;

    }
    public static Map<String, Object> queryHeader( )
    {
        Map<String,Object> queryMap = new HashMap<String,Object>();
        
        return queryMap;
    }
    public static Map<String, Object> pathHeader( )
    {
        Map<String,Object> pathHeader = new HashMap<String,Object>();
        return pathHeader;
    }
}
