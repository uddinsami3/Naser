package ab.runnerApi;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.gherkin.model.Scenario;
import com.codoid.products.exception.FilloException;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.standalone.MappingsLoader;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import com.sun.tools.xjc.api.Mapping;

import ab.common.CommonUtility;
import ab.common.TestConfiguration;
import ab.glue.ServiceHooks;
import io.cucumber.java.Before;
import io.cucumber.junit.Cucumber;
//import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.CucumberOptions;//JUNIT
import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;
import io.cucumber.testng.TestNGCucumberRunner;

//@RunWith(Cucumber.class)
@CucumberOptions (

        features={"src/test/resources/Project/SGTWAReport/Features"},
//        features={"src/test/resources/Project/AURCPL/Features/"},
       glue = {"ab.glue"},
        //tags= "@APICases",
     //dryRun=true,
        plugin= {
				"pretty","json:target/CucumberTestReport.json","html:target/cucumber-pretty"
				,"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
				} 
       
       
        //io.qameta.allure.cucumber5jvm.AllureCucumber5Jvm
)


public class TestRunnerAPI {
	private TestNGCucumberRunner testNGCucumberRunner;
	static WireMockServer wireMockServer;
	static WireMock wireMock;
	public static String CurrentTestCaseName="TC_02";
	@BeforeSuite
	public void beforesuiterun() throws Exception {
   /*     CommonUtility.header.add("Authorization");
        CommonUtility.header.add("uuid");
       CommonUtility.scope="Public";
        CommonUtility.APIName="UpdateCustomerWorkbenchOperatingSessionWealthDashboardActionChallengesRequest";
        CommonUtility.requestType="PUT";
        CommonUtility.headerDatatype();
        CommonUtility.MapHeadervaluesbyGeneratingData1();*/


        CommonUtility.createTestcases_orchestration();
         CommonUtility.createTestcases();
        CommonUtility.ReadTestCases1();
       // CommonUtility.negativerecordsetMap.add("TC_02");
        CommonUtility.readTemplate(CommonUtility.recordsetMap);
       // CommonUtility.readTestCaseValues(CommonUtility.negativerecordsetMap);
        //CommonUtility.replaceTestCaseInFearureFile(CommonUtility.fieldMap);
		TestConfiguration.FeatureOverride();
	}
	
    @BeforeClass(alwaysRun = true)
    public void setUpClass() throws IOException, InvalidFormatException, FilloException, InterruptedException {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
       
        TestConfiguration.generateWirmockMappings(System.getProperty("user.dir")+ "\\WealthDashboard.json");
        TestConfiguration.wireMockStart();
       
       
		
		
		/*
		 * for (Object TCName:CommonUtility.recordsetMap) { CurrentTestCaseName
		 * =TCName.toString();
		 * CommonUtility.replaceTestCaseInFearureFile(CurrentTestCaseName.toString());
		 * //TestConfiguration.FeatureOverride();
		 * //TestConfiguration.setExcelDataToFeature();
		 * 
		 * CommonUtility.TCCount++; }
		 */
		 
		 
        
      
        
       /* wireMockServer = new WireMockServer(8082);
        if(!wireMockServer.isRunning()) {
        	wireMockServer.start();
        	
        	
        	/*wireMock = WireMock.create()
        			.scheme("http")
        		    .host("localhost")
        		    .port(8082)
        		    .build();*/
        	//wireMock.loadMappingsFrom(System.getProperty("user.dir"));
        //} 
  
    }
    
    @Test(groups = "cucumber", description = "Runs Cucumber Scenarios", dataProvider = "scenarios")
    public void runScenario(PickleWrapper pickleWrapper, FeatureWrapper featureWrapper) throws Throwable {
        // the 'featureWrapper' parameter solely exists to display the feature file in a test report   	
    	 
    	testNGCucumberRunner.runScenario(pickleWrapper.getPickle());
    	
    }

    /**
     * https://jar-download.com/artifacts/io.cucumber/cucumber-testng/5.0.0-RC1/source-code/io/cucumber/testng/AbstractTestNGCucumberTests.java
     * Returns two dimensional array of {@link PickleWrapper}s
     * with their associated {@link FeatureWrapper}s.
     *
     * @return a two dimensional array of scenarios features.
     */
    @DataProvider(parallel=false)
    public Object[][] scenarios() {
        if (testNGCucumberRunner == null) {
            return new Object[0][0];
        }
        return testNGCucumberRunner.provideScenarios();
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() {
        if (testNGCucumberRunner == null) {
            return; 
        }
        testNGCucumberRunner.finish();
        //wireMock.shutdown();
        //wireMockServer.stop();
        TestConfiguration.wireMockStop();
    }  
   
}