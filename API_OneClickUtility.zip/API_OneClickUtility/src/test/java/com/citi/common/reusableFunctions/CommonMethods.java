package com.citi.common.reusableFunctions;

import static org.testng.Assert.assertTrue;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.citi.Automation.capabilities.DesiredCap;

import com.citi.ui.utils.TestUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class CommonMethods {

	public static AppiumDriver driver;

	
	/*
	 * public static WebDriverWait wait = CommonMethods.newDriver();
	 * 
	 * static WebDriverWait newDriver() {
	 * 
	 * WebDriverWait wait =null;
	 * 
	 * if(DesiredCap.webdriver !=null) { return new
	 * WebDriverWait(DesiredCap.webdriver,30); } else if(DesiredCap.driver != null)
	 * {
	 * 
	 * return new WebDriverWait(DesiredCap.driver,1000); } return wait; }
	 */
	 

	public static void waitforvisibilityOfElement(By element) throws IOException {
		WebDriverWait wait = new WebDriverWait(DesiredCap.webdriver, 30);
		TestUtils.log().info("identifying the Web Element object" + element);
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));
	}

	public static void sendKeysTextBox(By by, String text) throws IOException {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + ele);
		ele.sendKeys(text);
	}

	public static void clearAndSendKeys(By by, String text) throws IOException {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + ele);
		ele.clear();
		ele.sendKeys(text);

	}

	public static void clickMethod(By by) throws IOException {

		// waitforvisibilityOfElement(by);
		// WebElement ele=DesiredCap.webdriver.findElement(by);
		/// TestUtils.log().info("identifying the Web Element object"+ele);
		// ele.click();
		try {
			waitforvisibilityOfElement(by);
			WebElement ele = DesiredCap.webdriver.findElement(by);
			TestUtils.log().info("identifying the Web Element object" + ele);
			ele.click();
		} catch (Exception e) {
			JavascriptExecutor executor = (JavascriptExecutor) DesiredCap.webdriver;
			executor.executeScript("arguments[0].click();", DesiredCap.webdriver.findElement(by));
		}

	}

	public static void radiobutttonMethod(By by) throws IOException {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		boolean radioBtnIsDisplayed = ele.isDisplayed();

		System.out.println("Is  radio button displayed: " + radioBtnIsDisplayed);

		// Checking if the Radio button is enabled on the webpage and printing the
		// status

		boolean radioBtnIsEnabled = ele.isEnabled();

		System.out.println("Is  radio button enabled: " + radioBtnIsEnabled);

		// Checking the default radio button selection status

		boolean radioBtnIsSelected = ele.isSelected();

		System.out.println("Default Radio button selection Status: " + radioBtnIsSelected);

		// Selecting radio button

		ele.click();

		// rechecking the radio button selection status and printing it..

		boolean radioBtnNewSelectionStatus = ele.isSelected();

		System.out.println("The radio Selection status after perform click() event: " + radioBtnNewSelectionStatus);
	}

	public static String getAttribute(By by, String attribute) throws IOException {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("Verifying the click object" + ele);
		return ele.getAttribute(attribute);
	}

	public static String getTest(By by) throws IOException {

		//waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + ele);
		return ele.getText();
	}

	public static void textcomparsion() {
		if (driver.getPageSource().contains("Text to check")) {

			System.out.println("Text is present");
			Assert.assertTrue(true);
		} else {

			System.out.println("Text is absent");
			Assert.assertTrue(false);
		}
	}
//	public static void sendKeysTextBoxTWA(By by, String text) throws IOException {
//		WebElement ele =  TWA_IPad_Air.driver.findElement(by);
//		ele.sendKeys(text);
//	}

	/*
	 * To send text to any field which already has some text This method will first
	 * clear the field, then it will send text This function needs two parameters
	 * Element locator i.e xpath and Text you want to pass If element isn't found,It
	 * will wait 10sec to find the element
	 */

//	public static void clearAndSendKeysTWA(By by, String text) throws IOException {
//		WebElement ele =  (waitTWA.until(ExpectedConditions.presenceOfElementLocated(by)));
//		ele.clear();
//		ele.sendKeys(text);
//	}

	/*
	 * To click on any element This function needs one parameters Element locator
	 * i.e xpath If element isn't found,It will wait 10sec to find the element
	 */

	public static void sellectmethod(By by, String text) {

	}

//	public static void clickMethodTWA(By by) throws IOException {
//		WebElement ele =  waitTWA.until(ExpectedConditions.presenceOfElementLocated(by));
//		ele.click();
//	}

	/*
	 * To Check whether the element is present or not This function needs one
	 * parameters Element locator i.e xpath If element isn't found,It will wait
	 * 10sec to find the element
	 */

	/*
	 * To Scroll in all directions This function needs four parameters x and y
	 * ordinates one integer value one character value i.e for up/down/left/right
	 */
	public static void scrollByJavaScriptExe(int x, int y, int coordinate, char c) throws IOException {
		PointOption points = new PointOption();
		TouchAction action = new TouchAction(DesiredCap.driver);

		switch (c) {
		case '-':
			action.press(points.point(x, y)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000)))
					.moveTo(points.point(x, y + c + coordinate)).release().perform();
			break;
		case '+':
			action.press(points.point(x, y)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000)))
					.moveTo(points.point(x, y + c + coordinate)).release().perform();
			break;
		case 'L':
			action.press(points.point(x, y)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000)))
					.moveTo(points.point(coordinate, y)).release().perform();
			break;
		case 'R':
			action.press(points.point(x, y)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000)))
					.moveTo(points.point(x + coordinate, y)).release().perform();
			break;
		default:
			System.out.println("Scroll cant perform on that direction");
			break;
		}

	}// ====================Old Reusable Functions================================

	public static boolean isExist(String Id) {
		try {
			DesiredCap.driver.findElement(By.id(Id)).click();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean isExistXpath(String Id) {
		try {
			DesiredCap.driver.findElement(By.xpath(Id)).click();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean isExistSend(String Id, String keysToSend) {
		try {
			DesiredCap.driver.findElement(By.id(Id)).sendKeys(keysToSend);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static void checkForTheElementIsPresentInDOM(String className) {
		List<MobileElement> inputs;
		Long startTime = System.currentTimeMillis();
		do {
			inputs = (List<MobileElement>) DesiredCap.driver.findElements(MobileBy.className(className));
			if (!inputs.isEmpty()) {
				System.out.println("FOUND!");
				break;
			} else {
				System.out.println("NoT Found..!!");
			}
		} while ((System.currentTimeMillis() - startTime) / 1000 < 100); // 100
																			// sec
																			// wait
	}

	public static void clearForWaitByID(String value) throws InterruptedException {
		Thread.sleep(4000);
		DesiredCap.driver.findElement(By.id(value)).clear();
	}

	public static void clcikByID(String value) {
		try {
			DesiredCap.driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			DesiredCap.driver.findElement(By.id(value)).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void clickByXpath(String value) {
		try {
			DesiredCap.driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			DesiredCap.driver.findElement(By.xpath(value)).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void clickForWaitByXpath(String value) throws InterruptedException {
		try {
			WebDriverWait wait = new WebDriverWait(DesiredCap.driver, 60);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(value))).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Set<String> findDuplicates(List<String> listContainingDuplicates) {
		final Set<String> setToReturn = new HashSet<String>();
		final Set<String> set1 = new HashSet<String>();
		for (String yourInt : listContainingDuplicates) {
			if (!set1.add(yourInt)) {
				setToReturn.add(yourInt);
			}
		}
		return setToReturn;
	}

	public static boolean sortOrder(List<String> value) {
		String previous = "";
		value = new ArrayList<String>();
		for (final String current : value) {
			value.add(current);
			if (current.compareTo(previous) < 0)
				return false;
			previous = current;
		}
		return true;
	}

	public static void clickByClassName(String elements, int index) throws InterruptedException {
		List<MobileElement> elementClick = DesiredCap.driver.findElementsByClassName(elements);
		elementClick.get(index).click();
	}

	public static void scrolliOS(String text) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<Object, Object> scrollObject = new HashMap<>();
		scrollObject.put("predicateString", "value == '" + text + "'");
		scrollObject.put("direction", "down");
		js.executeScript("mobile: scroll", scrollObject);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.id(text)).click();

	}

	public static String softassert(String actual, String expected) throws Throwable {
		// String str="Special Customer Assessment";
		SoftAssert sa = new SoftAssert();
		/*
		 * waitforvisibilityOfElement(by); WebElement
		 * ele=DesiredCap.webdriver.findElement(by); String actual= ele.getText();
		 */
		System.out.println(actual);
		sa.assertEquals(actual, expected);
		if (actual.equalsIgnoreCase(expected)) {
			System.out.println("Assertion passed");
		} else {
			System.out.println("Assertion failed");
		}
		return actual;
	}

	public static String softassertNotEquals(String actual, String expected) throws Throwable {
		// String str="Special Customer Assessment";
		SoftAssert sa = new SoftAssert();
		/*
		 * waitforvisibilityOfElement(by); WebElement
		 * ele=DesiredCap.webdriver.findElement(by); String actual= ele.getText();
		 */
		System.out.println(actual);
		sa.assertNotEquals(actual, expected);
		if (actual.equalsIgnoreCase(expected)) {
			System.out.println("Assertion passed");
		} else {
			System.out.println("Assertion failed");
		}
		return actual;
	}

	public static String softassertContains(String actual, String expected) throws Throwable {
		// String str="Special Customer Assessment";
		SoftAssert sa = new SoftAssert();
		/*
		 * waitforvisibilityOfElement(by); WebElement
		 * ele=DesiredCap.webdriver.findElement(by); String actual= ele.getText();
		 */
		System.out.println(actual);
		sa.assertEquals(actual, expected);
		if (actual.contains(expected)) {
			System.out.println("Assertion passed");
		} else {
			System.out.println("Assertion failed");
		}
		return actual;
	}

	public static void mouseClickable(By by) throws Throwable {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		System.out.println("Success");
		Actions action = new Actions(DesiredCap.webdriver);
		System.out.println("Success");
		action.moveToElement(ele).click().build().perform();
		System.out.println("Success");
	}

	public static void scrollDown() throws Throwable {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
	}

	public static String subString(String str, int x, int y) throws Throwable {

		return str.substring(x, y);

	}

	public static void dropDown(By by, int x) throws IOException {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		Select s = new Select(ele);
		s.deselectByIndex(x);

	}

	public static void drop_downindex(By by, int x) throws Throwable {
		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		Select s = new Select(ele);
		// String text = ele.getText();
		// s.selectByVisibleText(text);
		s.selectByIndex(x);
	}
	public static void drop_downtext(By by, String text) throws Throwable {
		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		Select s = new Select(ele);
		// String text = ele.getText();
		 s.selectByVisibleText(text);
		//s.selectByIndex(x);
	}
	public static void moveToElementClick(By by) throws IOException {
		//waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + ele);
		Actions acc = new Actions(DesiredCap.webdriver);
		acc.moveToElement(ele).perform();
		//ele.click();

	}

	public static void doubleClick(By by) throws IOException {
		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + ele);
		Actions acc = new Actions(DesiredCap.webdriver);
		acc.doubleClick(ele).perform();
		ele.click();

	}

	public static void actionsClick(By by) throws IOException {
		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + ele);
		Actions acc = new Actions(DesiredCap.webdriver);
		acc.click(ele);

	}

	public static void robotClass() throws IOException, Exception {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);

	}

	public static void disabledDragDrop(By by, By by1) throws IOException {

		waitforvisibilityOfElement(by);
		/*
		 * WebElement source=DesiredCap.webdriver.findElement(by);
		 * TestUtils.log().info("identifying the Web Element object"+source); WebElement
		 * dest=DesiredCap.webdriver.findElement(by);
		 * TestUtils.log().info("identifying the Web Element object"+dest); Actions
		 * acc=new Actions(driver); acc.dragAndDrop(source,dest).perform();
		 */

		WebElement source = DesiredCap.webdriver.findElement(by);
		JavascriptExecutor js = (JavascriptExecutor) DesiredCap.webdriver;
		js.executeScript("document.getElementById('dropAreaAssign').className='active';");
		WebElement destination = DesiredCap.webdriver.findElement(by1);
		System.out.println(source.getText());

		// Using Action class for drag and drop
		Actions act = new Actions(DesiredCap.webdriver);
		act.dragAndDrop(source, destination).build().perform();
		// System.out.println(destination.getText()+" "+destination.isDisplayed()+"
		// "+destination.isEnabled());

	}

	public static void dropDown(By by, String x) throws IOException {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		Select s = new Select(ele);
		s.selectByVisibleText(x);
	}

	public static void advancedDropDown(By by, String x) throws IOException {
		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);

	}

	public static void dropDownByValue(By by, String x) throws IOException {

		waitforvisibilityOfElement(by);
		WebElement ele = DesiredCap.webdriver.findElement(by);
		Select s = new Select(ele);
		s.selectByValue(x);
	}
	public static void dropDownByValuelist(By by, String string ) throws IOException {
		// TODO Auto-generated method stub
		WebElement ele = DesiredCap.webdriver.findElement(by);
				Select selectDrp=new Select(ele);
				 List<WebElement> listDropDown= selectDrp.getOptions();
				 //System.out.println("size"+listDropDown.size());
				 for(WebElement selVal:listDropDown) {			
					 if(selVal.getText().equals(string)) {
						 selVal.click();
						 break;
					 }
				 }
	}

	public static void javascriptClick(By by) throws IOException {

		WebElement btnclk = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + btnclk);
		JavascriptExecutor js = (JavascriptExecutor) DesiredCap.webdriver;
		js.executeScript("arguments[0].click();", btnclk);
	}

	public static void scrollDown(By by) throws IOException {
		waitforvisibilityOfElement(by);
		WebElement btnDown = DesiredCap.webdriver.findElement(by);
		TestUtils.log().info("identifying the Web Element object" + btnDown);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true)", btnDown);
	}


}
