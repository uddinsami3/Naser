package snippet;

public class Snippet {
	{
	  "providerInfo": [
	    {
	      "code": "string",
	      "detail": "string",
	      "fieldId": "string"
	    }
	  ],
	  "vcResult": [
	    {
	      "vcCode": "string",
	      "vcShortDescription": "string",
	      "vcLongDescription": "string"
	    }
	  ],
	  "questionDetails": [
	    {
	      "questionIndicator": "string",
	      "questionLabel": "string",
	      "questionSequenceNumber": "string",
	      "mandatoryIndicator": "string",
	      "onlineIndicator": "string",
	      "questionToolTips": "string",
	      "responseDetails": [
	        {
	          "responseId": "string",
	          "responseType": "string",
	          "responseLabel": "string",
	          "responseSequenceNumber": "string",
	          "selectionIndicator": "string",
	          "responseDynamicText": "string"
	        }
	      ]
	    }
	  ]
	}
	
}

